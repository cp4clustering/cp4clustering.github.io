#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stack>    
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


/*
	Class for the split Constraint
	Using matrix of dissimilarity: dd[i][j]
	Input: 
		x - Variables G
		y - Smin: lower bound of Split.
		z - Smax: upper bound of Split.
*/
class separationConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x; // G
		Float::FloatView y; // Smin
		Float::FloatView z; // Smax
		stack<int> changedPoints;
		int changeS;			
	
	 class ViewAdvisor : public Advisor {
	  public:
		Int::IntView x;
		Float::FloatView y; // Smin
		Float::FloatView z; // Smax

		int index;

		ViewAdvisor(Space& home, Propagator& p, 
		            Council<ViewAdvisor>& c, Int::IntView x0, int index0, Float::FloatView y0) 
		  : Advisor(home,p,c), x(x0), index(index0), y(y0) {
		  x.subscribe(home,*this);
		  y.subscribe(home,*this);

		}
		ViewAdvisor(Space& home, bool share, ViewAdvisor& a)
		  : Advisor(home,share,a), index(a.index) {
		  x.update(home,share,a.x);
		  y.update(home,share,a.y);

		}
		void dispose(Space& home, Council<ViewAdvisor>& c) {
		  x.cancel(home,*this);
		  y.cancel(home,*this);

		  Advisor::dispose(home,c);
		}
	  };

	  Council<ViewAdvisor> c;


	public:
		// posting
		separationConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0, Float::FloatView z0) 	
			: Propagator(home), x(x0), y(y0), z(z0), c(home), changeS(0)  {

			for (int i=x.size(); i--; )
			  (void) new (home) ViewAdvisor(home,*this,c,x[i], i, y);
		    (void) new (home) ViewAdvisor(home,*this,c,x[0], -1, y);

			home.notice(*this,AP_DISPOSE);
		}
		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0, Float::FloatView y0, Float::FloatView z0) {
			(void) new (home) separationConstraint(home,x0,y0,z0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			c.dispose(home);
			(void) Propagator::dispose(home);
			return sizeof(*this);
		}

		// copying
		separationConstraint(Space& home, bool share, separationConstraint& p) 
			: Propagator(home,share,p), changeS(0) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
				z.update(home, share, p.z);
			    c.update(home,share,p.c);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) separationConstraint(home,share,*this);
		}

		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}


		  // advise function
		  virtual ExecStatus advise(Space&, Advisor& a, const Delta& d) {
				if (static_cast<ViewAdvisor&>(a).index >= 0) {
							changedPoints.push(static_cast<ViewAdvisor&>(a).index);		// always add point i to stack, even if i is not fixed
				}
				else { // index = -1, S.max has changed
					changeS = 1;	
				}
				// always active the propagateur			
				return ES_NOFIX;
		  }


		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
			if (changeS) {   // Smin is changed, so I have to add all fixed points to the stack changedPoints
				changeS = 0;

				if (z.max() <= y.min()) return ES_FAILED;
				while ( !changedPoints.empty() ) // let the stack be empty
					changedPoints.pop();
				for (int i = 0; i < n; i++)
					if (x[i].assigned())
						changedPoints.push(i);				
			}
		
			while (!changedPoints.empty()) {

 				int i = changedPoints.top();
				changedPoints.pop();
 
				for (int j = 0; j < n; j++) {
					if (dd[i][j] <= y.min())  {
						for (int c = 0; c < k; c++) {
							if (  (x[i].in(c)) & (!x[j].in(c)) )
								GECODE_ME_CHECK( x[i].nq (home, c) );
							if (  (x[j].in(c)) & (!x[i].in(c)) )
								GECODE_ME_CHECK( x[j].nq (home, c) );
 						}
					}

					if (x[j].assigned()) 
						if (x[i].assigned()) 
							if (x[i].val() != x[j].val()) {
 						  		  	GECODE_ME_CHECK(z.lq(home, dd[i][j]));   
									if (dd[i][j] <= y.min())
										return ES_FAILED;
							}
				}
			}
			return ES_FIX;

		}
};

	void separationConstraint(Home home, IntVarArgs x, FloatVar y, FloatVar z) {
		// constraint post function
		ViewArray<Int::IntView> vx(home, x);
		Float::FloatView vy(y);
		Float::FloatView vz(z);
			if (separationConstraint::post(home, vx, vy, vz) != ES_OK)
				home.fail();
	}

