


double dist(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return sqrt(d);
}


double distSquare(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return d;
}



int distInt(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  d = sqrt(d);
  d *= 100;

  return (int) d;
}

double give_time(){
  struct rusage ru;
  struct timeval tim;
  getrusage(RUSAGE_SELF, &ru);
  tim = ru.ru_utime;
  return (double)tim.tv_sec+(double)tim.tv_usec/1000000.0;
}



void readDataMatrix(int n, ifstream &fin, double &maxD, double &minD) {
	maxD = 0;
	minD = 100000000;
	for (int i = 0; i < n; i++) 
		for (int j = 0; j < n; j++) {
			fin >> dd[i][j];
			
			if (i != j) {
				if (maxD < dd[i][j]) maxD = dd[i][j];
				if (minD > dd[i][j]) minD = dd[i][j];
			}
      }	// end of read file
}

void readData(int n, int nA, ifstream &fin, vector<double> *a) {
    double temp;
    for (int i = 0; i < n; i++) 
      for (int j = 0; j < nA; j++) {
				fin >> temp;
				a[i].push_back(temp); 		
      }	// end of read file

}


// read real class of points
void readRealClass(int n, int nA, string fileName, vector<double> *a, int *realClass) {

	//	cout << fileName.c_str() << endl << endl;
    
      ifstream finClass(fileName.c_str(),ios::in);	// read filel	
      for (int i = 0; i < n; i++) {
				finClass >> realClass[i];
	  }
    
}



void initCommonVariables(int n) {

	if ((obj == 3) || (obj == 4) || (obj == 14)) {
		// creat VariancePartiel
	    VariancePartiel = new double*[n];
	   for (int i=0; i<n; i++)
	        VariancePartiel[i] = new double[n];
	
	    dSort = new double[n * (n - 1)/2];
		// creat pX, pY
	    pX = new int[n * (n - 1)/2];
	    pY = new int[n * (n - 1)/2];
	}

	a = new vector<double>[n]; // b : matrix of attributes,  b[i][j] : attribute j of point i
	center = new vector<double>[n]; // center of k groups
	saveSepa = new double[n];
	saveDiam = new double[n];
	badParetoSolution = new int[n];
	for (int i = 0; i < n; i++)
		badParetoSolution[i] = 0;

	//creat positionG
	positionG = new int[n]; // for ex: G[i] = 0, 1, 5 => postion[0] = 0; position[1] = 1; position[5] = 2;
	positionG[0] = 0;

	// creat dd[n][n]
    dd=new double*[n];
    for (int i=0; i<n; i++)
        dd[i] = new double[n];

	//___________ end_______________

	// creat order
    order = new int[n];
    for (int i = 0; i < n; i++)
      order[i] = i;

	//___________ end_______________
	// creat realClass
    realClass = new int[n];

	//___________ end_______________


	// creat int *sClass; // size of each class
	sClass = new int[n];
	// creat finalClass
	finalClass = new int[n];
	for (int i = 0; i < n; i++)
		finalClass[i] = 0;
	// creat bestV;
	bestV = new double[n+1];	
	for (int i = 0; i < n+1; i++)
		bestV[i] = 0;

	// creat finalOrder
	finalOrder = new int[n];


	wcss = new double[n+1];
}




int pivot(double a[], int pX[], int pY[], int first, int last) 
{
    int  p = first;
    double pivotElement = a[first];
 
    for(int i = first+1 ; i <= last ; i++)
    {
        if(a[i] <= pivotElement)
        {
            p++;
            swap(dSort[i], dSort[p]);
			swap(pX[i], pX[p]);
			swap(pY[i], pY[p]);

        }
    }
 
    swap(a[p], a[first]);
	swap(pX[p], pX[first]);
	swap(pY[p], pY[first]);

    return p;
}

void quickSort( double a[], int pX[], int pY[], int first, int last ) 
{
    int pivotElement;
 
    if(first < last)
    {
        pivotElement = pivot(a, pX, pY, first, last);
        quickSort(a, pX, pY, first, pivotElement-1);
        quickSort(a, pX, pY, pivotElement+1, last);
    }
}
 
 


void sortD() {
	// creat dSort



	int count = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j <n; j++) {
			pX[count] = i;
			pY[count] = j;
			count++;
		}

	count = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j <n; j++) {
			dSort[count] = dd[i][j] * dd[i][j];
			count++;
		}


	quickSort(dSort, pX, pY, 0, count-1);

}


void reOrderPointFPF(int n, int k, int nA, vector<double> *a, int *realClass) {

    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD;
				totalDist[j] += tempD;
      }

	double distToP[n];
	for (int i = 0; i < n; i++)
		distToP[i] = totalDist[i];

	// here we use FPF to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
//	for (int p = 0; p < 10*k; p++) {  // WE DONT NEED ORDER ALL

	  // now we find point for position p
	  // FIRST, calcul F(i) off all point from i to n
	  int position = 0;
	  double maxF = 0;		
	  for (int i = p; i < n; i++) {
			double f = 0; // f(i)				
			double minDist = 100000;

			f = distToP[i];
		
		
		if (f > maxF) {		// select the point that is has  max of  minDist
			maxF = f;
			position = i;
		}
	  }
	
	
	//	cout << maxF	 << " " << distToP[position] << endl;

	  if (p < position) {
		  swap(a[p], a[position]);
		  swap(order[p], order[position]);
		  swap(totalDist[p], totalDist[position]);
		  swap(realClass[p], realClass[position]);	
		  swap(distToP[p], distToP[position]);	  
	  }
		  // now: update distToP of point p+1 to n
	  for (int c = p+1; c < n; c++) {
		 double tempD = dist(a[p], a[c]);
		 if (distToP[c] > tempD)
			distToP[c] = tempD;
	  }


	}

	// calcal D[x][y] = distance between point x and y, distance is integer

		if (output)
	cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;

}


void reOrderPointFPF_lastK(int n, int k, int nA, vector<double> *a, int *realClass) {

// chi xay dung k head ban dau

    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD;
				totalDist[j] += tempD;
      }

	double distToP[n];
	for (int i = 0; i < n; i++)
		distToP[i] = totalDist[i];

	// here we use FPF to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL

	  // now we find point for position p
	  // FIRST, calcul F(i) off all point from i to n
	  int position = 0;
	  double maxF = 0;		
	  for (int i = p; i < n; i++) {

			double f = 0; // f(i)				
			double minDist = 100000;

		if (p > k)
			for (int zz = 1; zz <= k; zz++)
				f += dist(a[i], a[p-zz]);
		else
		f = distToP[i];
		
		
		if (f > maxF) {		// select the point that is has  max of  minDist
			maxF = f;
			position = i;
		}
	  }
	
	
	//	cout << maxF	 << " " << distToP[position] << endl;

	  if (p < position) {
		  swap(a[p], a[position]);
		  swap(order[p], order[position]);
		  swap(totalDist[p], totalDist[position]);
		  swap(realClass[p], realClass[position]);	
		  swap(distToP[p], distToP[position]);	  
	  }
		  // now: update distToP of point p+1 to n
	  for (int c = p+1; c < n; c++) {
		 double tempD = dist(a[p], a[c]);
		 if (distToP[c] > tempD)
			distToP[c] = tempD;
	  }


	}

	// calcal D[x][y] = distance between point x and y, distance is integer
		if (output)
	cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;

}



void reOrderPointVariance(int n, int k, int nA, vector<double> *a, int *realClass) {

    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD * tempD;
				totalDist[j] += tempD * tempD;
      }

	// here we use FPF to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
		// now we find point for position p
		// FIRST, calcul F(i) off all point from i to n
		int position = 0;
		double maxF = 0;		
		for (int i = p; i < n; i++) {
			double f = 0; // f(i)				
			double minDist = 0;
			//double maxDist = 0;
			int p1 = n;  // p1 = 3 * k ??
			if (p < p1) p1 = p;
			for (int j = 0; j < p1; j++) { 
				minDist += dist(a[i],a[j]) * dist(a[i],a[j]) ;
		}

		// minDist = min distance from a point to  [point 0, point 1, ... point p-1 ] 
		if (p == 0)   // special case
			f = totalDist[i]; 
		else
			f = minDist;
		if (f > maxF) {		// select the point that is has  max of  minDist
			maxF = f;
			position = i;
		}
	  }
	  swap(a[p], a[position]);
	  swap(order[p], order[position]);
	  swap(totalDist[p], totalDist[position]);
	  swap(realClass[p], realClass[position]);
	}

	// calcal D[x][y] = distance between point x and y, distance is integer
		if (output)
	cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;
}


void reOrderPointPoid(int n, int k, int nA, vector<double> *a, int *realClass)  {
    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD;
				totalDist[j] += tempD;
      }

	// here we use our Function to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL

	// now we find point for position p

		// FIRST, calcul F(i) off all point from i to n
		int position = 0;
		double maxF = 0;		

		for (int i = p; i < n; i++) {
			double f = 0; // f(i)				
			double minDist = 100000;
			double maxDist = 0;

			int p1 = n;
			if (p < p1) p1 = p;

			for (int j = 0; j < p1; j++) {  // f(i) = Sum d(i, j) * min/max * (n-p)/p
				double distTemp = dist(a[i], a[j]);
				f += distTemp;	
				if (distTemp < minDist) minDist = distTemp;
				if (distTemp > maxDist) maxDist = distTemp;
			}

			if (p >= 1)
				f = f * (((minDist/maxDist)/p) * (n-p)-1);

			f += totalDist[i];	

			if (f > maxF) {
				maxF = f;
				position = i;
			}
		}
		swap(a[p], a[position]);
		swap(order[p], order[position]);
		swap(totalDist[p], totalDist[position]);
		swap(realClass[p], realClass[position]);
	}
		if (output)
	cout << "Reading + ReOrganisation DATA (WEIGHT FUNCTION) in \t:  " << give_time() - startAll << endl;
}

void reOrderPointRANDOM(int n, vector<double> *a, int *realClass)  {
	for (int i = 0; i < 10000; i++) {
	  int x = rand() % n;
      int y = rand() % n;
	  swap(a[x], a[y]);
	  swap(order[x], order[y]);
	  swap(realClass[x], realClass[y]);
	}
		if (output)
	cout << "Randomly reorder point \n";

}

void reOrderPointRevert(int n, vector<double> *a, int *realClass)  {
	for (int i = 0; i < n/2; i++) {
	  swap(a[i], a[n-i-1]);
	  swap(order[i], order[n-i-1]);
	  swap(realClass[i], realClass[n-i-1]);
	}
		if (output)
	cout << "Revert reorder point \n";

}



void calculD(int n, int nSmall, int order, double &maxD, double &minD,  vector<double> *a) {

	// now we take nSmall instead of n. So we will consider only point n-nSmall to point n-1.
	maxD = 0;
	minD = -1;
	
/*	if (order==1)
		for (int i = n-nSmall; i < n; i++)
		  for (int j = n-nSmall; j < n; j++) {
				
					dd[i - n + nSmall][j - n + nSmall] = dist(a[i], a[j]);
					if (dd[i- n + nSmall][j- n + nSmall] > maxD)	
		  			maxD = dd[i- n + nSmall][j- n + nSmall];  // max distance between two points
					if (minD == -1 || (i!=j && dd[i- n + nSmall][j- n + nSmall]<minD)) 
						if (dd[i- n + nSmall][j- n + nSmall] != 0)	// minD > 0
						  minD = dd[i- n + nSmall][j- n + nSmall]; // min distance between two points
		  }

	if (order==0)
*/
		for (int i = 0; i < nSmall; i++)
		  for (int j = 0; j < nSmall; j++) {
				
					dd[i][j] = dist(a[i], a[j]);
					if (dd[i][j] > maxD)	
		  			maxD = dd[i][j];  // max distance between two points
					if (minD == -1 || (i!=j && dd[i][j]<minD)) 
						if (dd[i][j] != 0)	// minD > 0
						  minD = dd[i][j]; // min distance between two points
		  }
		if (output)
	cout << maxD << " " << minD << endl;
}


double calculDiameterFPF(int n, int k) {
    int group[n];
    int head[k];
    head[0] = 0;
	double diamHeuristic = 0;

    for (int i = 0; i < n; i++) 
      group[i] = head[0];
    

    for (int c = 1; c < k; c++) {
      // find furthest point
      double maxDtoHead = 0;
      int point = 0;
      for (int i = 0; i < n; i++) 
			if (dd[i][group[i]] > maxDtoHead) {
				maxDtoHead = dd[i][group[i]];
				point = i;
			}
 	   	head[c] = point; 
    	for (int i = 0; i < n; i++)
			if (dd[i][group[i]] > dd[i][point]) {
	  		group[i] = point;
			}				
    }

 
    for (int i = 0; i < n; i++)
      for (int j = i+1; j < n; j++)
		if (group[i] == group[j])
	  	if (diamHeuristic < dd[i][j])
	  	  diamHeuristic = dd[i][j];
    

	return diamHeuristic;
}



double RandIndex(int n, int *realClass1, int* GR) {
// calcul RAND_INDEX	IT IS NOT CORRECT ANYMORE WITH NSMALL AND NBIG
	int a = 0; int b = 0; int c = 0; int d = 0; int z = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++) {
			z++;

			if ((realClass1[i] == realClass1[j]) && (GR[i] == GR[j]))
				a++;
			if ((realClass1[i] != realClass1[j]) && (GR[i] != GR[j]))
				b++;
			if ((realClass1[i] == realClass1[j]) && (GR[i] != GR[j])) {
//			cout << i << " " << j << endl;

				c++;
			}
			if ((realClass1[i] != realClass1[j]) && (GR[i] == GR[j]))  {
				d++;
			}	
			
		}
	double Rand;
	Rand = (double) (a + b)/(a+b+c+d);
	return Rand;
}




void buildFinalOrder(int n) {
// Use strategy from previous solution - FIRST FAIL. I have finalClass[i], I need to build finalOrder[i]
	// so Order[1] will be points the is very far to other points in the same group

	double v[n][n]; // v[i][c]: total distance carre from i to other points in the group c
	for (int i = 0; i < n; i++) {
		finalOrder[i] = i;
		for (int c = 0; c < n; c++)
			v[i][c] = 0;
	}

	// now I calcul v[i]
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++) {
			v[i][  finalClass[j] ] += dd[i][j] * dd[i][j];
			v[j][  finalClass[i] ] += dd[i][j] * dd[i][j];				
		}

	for (int i = 0; i < n; i++)
		sClass[i] = 0;	// size of class

	for (int i = 0; i < n; i++)
		sClass[  finalClass[i] ]++;
	

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			if (v[i][j] > 0)
				v[i][j] = v[i][j]; // sClass[j];

	double vmin[n]; //  variance from a point to its groups
	for (int i = 0; i < n; i++)
		vmin[i] = v[i][ finalClass[i] ]; // should I divide ?? I think NO

	
	double borderIndex[n];
	for (int  i = 0; i < n; i++)
		borderIndex[i] = 10000000;


	// calcul borderIndex: the ratio of variance between point i to other group and to its group
	for (int i = 0; i < n; i++) 
		for (int j = 0; j < n; j++)
			if ((v[i][j] > 0) && (j != finalClass[i])) // calcul ratio class j and class of i			
				if (borderIndex[i] >  v[i][j]) { // this ratio may < 1
					borderIndex[i] = v[i][j];
				}

	// now I reorder I follow borderIndex
//	for (int i = 0; i < n; i++)
	//	borderIndex[i] = vmin[i];

	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++)
			if (borderIndex[i] > borderIndex[j]) {
				swap(borderIndex[i], borderIndex[j]);
		//		swap(finalOrder[i], finalOrder[j]);
			}
//	for (int i = 0; i < n; i++)
//		cout << finalOrder[i] << " " << borderIndex[ i ] << endl;

}

void FindMaxSeparateur(){

   int selected[n], ne; //ne for no. of edgesintfalse=0,true=1,min,x,y;


    for (int i = 0; i <n;i++)
       selected[i] = false;

    selected[0]=true;
    ne=0;
	int x, y;
	
	double arc[n];
    while (ne < n-1){
       double min = 1000000000;

       for (int i = 0; i < n;i++)
          if (selected[i] == true) 
	         for(int j = 0; j<n;j++)
	            if(selected[j] == false)
	               if (min > dd[i][j]) {
		               min = dd[i][j];
        		       x=i;
		               y=j;
               }
       selected[y]=true;
//	   cout << x << " " << y << " " << dd[x][y] << endl;
	   arc[ne] = dd[x][y];
       ne=ne+1;
    }

	for (int i = 0; i < n-1; i++)
		for (int j = i+1; j < n-1; j++)
			if (arc[i] < arc[j])
				swap(arc[i], arc[j]);
//	for (int i = 0; i < n-1; i++)
//		cout << arc[i] << endl;
//s	cout  << endl; 
	if (k > 1) {
		cout << "_________________________\nBest Separateur: " << arc[k-2] << " " << endl;
		Separateur_UB = arc[k - 2];
	}

}


void findAllSeparateur(){

	allSeparation = new double[n];

   int selected[n], ne; //ne for no. of edgesintfalse=0,true=1,min,x,y;


    for (int i = 0; i <n;i++)
       selected[i] = false;

    selected[0]=true;
    ne=0;
	int x, y;
	
	double arc[n];
    while (ne < n-1){
       double min = 1000000000;

       for (int i = 0; i < n;i++)
          if (selected[i] == true) 
	         for(int j = 0; j<n;j++)
	            if(selected[j] == false)
	               if (min > dd[i][j]) {
		               min = dd[i][j];
        		       x=i;
		               y=j;
               }
       selected[y]=true;
//	   cout << x << " " << y << " " << dd[x][y] << endl;
	   arc[ne] = dd[x][y];

	   allSeparation[ne] = dd[x][y];
       ne=ne+1;

    }

	for (int i = 0; i < n-1; i++)
		for (int j = i+1; j < n-1; j++)
			if (arc[i] < arc[j])
				swap(arc[i], arc[j]);
//	for (int i = 0; i < n-1; i++)
//		cout << arc[i] << endl;
//s	cout  << endl; 

	for (int i = 0; i < ne; i++)
		for (int j = i+1; j < ne; j++)
			if (allSeparation[i] > allSeparation[j])
				swap(allSeparation[i], allSeparation[j]);

	cout << "_________________________\nAll Separation are : " ;
//	for (int i = 0; i < ne; i++)
//		cout << allSeparation[i] << " ";

}


void printAMAT() {
	ofstream fOut3("AMAT.DAT",ios::out);	// read file
	fOut3 << n << endl;
	for (int i = 0; i < n; i++) { 
		for (int j = 0; j < n; j++) {
//			dd[i][j] = dist(a[i], a[j]);
  			fOut3 << dd[i][j]*dd[i][j]   << " ";
		}
		fOut3 << endl;
	}
	fOut3.close();
}

void deleteBadParetoSolution() {
	for (int i = 0; i < nSolution; i++)
		if (!badParetoSolution[i])
			for (int j = 0; j < nSolution; j++)
				if (i != j)	 
					if 	(((saveSepa[i] >= saveSepa[j]) && (saveDiam[i] <= saveDiam[j]))				
					|| ((saveSepa[i] >= saveSepa[j]) && (saveDiam[i] <= saveDiam[j])))				
						badParetoSolution[j] = 1;
}




