#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


/*
	Wcss Constraint
	- Using matrix of dissimilarity dd[][]
	- Constraint is activated when a variable G[i] is instanciated

*/
class wcssConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x;
		Float::FloatView y;

	public:
		// posting
		wcssConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0), y(y0)  {
			x.subscribe(home,*this,Int::PC_INT_VAL);
		}

		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0, Float::FloatView y0) {
			(void) new (home) wcssConstraint(home,x0,y0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			x.cancel(home,*this,Int::PC_INT_VAL);

			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		wcssConstraint(Space& home, bool share, wcssConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) wcssConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}








		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
			int q = 0; // number of unassigned point;
			int p = 0; // number of fixed point;		

			std::vector<int> setP[k]; 	// set of fixed points	
			std::vector<int> setQ;	// set of non-fixed points


			// get the set of assigned and unassigned points			
			for (int i = 0; i < n; i++)
				if (x[i].assigned()) {
					p++;
					setP[x[i].val()].push_back(i);
				}
				else  {
					q++;
					setQ.push_back(i);
				}


			// get the size of each cluster
			double sizeCluster[k]; // number of point in a cluster
			for (int c = 0; c < k; c++)
				sizeCluster[c] = setP[c].size();


			// declaration of borne[k][q+1], borne[c][m]: minimum wcss of cluster Cc if we have m points 
			double borne[k][q+1];
			for (int c = 0; c < k; c++)
				for (int m = 0; m <= q; m++)
					borne[c][m] = 0;

			// calculatation of V1 of each cluster
			double V1[k]; // V1[c] = V1 of cluster Cc
			for (int c = 0; c < k; c++) {
				V1[c] = 0;
				for (int i = 0; i < setP[c].size(); i++)
					for (int j = i+1; j < setP[c].size(); j++) {
						V1[c] += dd[ setP[c][i] ][ setP[c][j] ] * dd[ setP[c][i] ][ setP[c][j] ] ;
					}

			}

			// Calculation of distance from each non fix point to each cluster Cc
			double v2[q][k]; // v2[i][c] = sum of distance from i to every points in cluster Cc. V2[i][c] = max if c is not in the domain of i
			for (int i = 0; i < q; i++)
				for (int c = 0; c < k; c++) 	{
					// now check every points in cluster Cc
					if (x[ setQ[i] ].in(c)) {
						v2[i][c] = 0;
						for (int j = 0; j < setP[c].size(); j++) 
							v2[i][c] += dd[ setQ[i] ] [ setP[c][j] ] * dd[ setQ[i] ] [ setP[c][j] ];
					}
					else 
						v2[i][c] = 10000000000000;
				}
				
			// Calculation of distance between non fix points

			// dQQ: distance between non assigned points
			std::vector<double> dQQ[q];  // dQQ[i][j] = sum of distance from j-1 points to i. We know that dQQ[i] has q elements
			for (int i = 0; i < setQ.size(); i++)
				for (int j = 0; j < setQ.size(); j++)
					dQQ[i].push_back( dd[ setQ[i] ][ setQ[j] ] * dd[ setQ[i] ][ setQ[j] ]/2);

			for (int i = 0; i < q; i++) 
				 std::sort (dQQ[i].begin(), dQQ[i].end());		


			for (int i = 0; i < q; i++)
				for (int j = 1; j < q; j++)	
					dQQ[i][j] += dQQ[i][j-1];


		
			// calculation of Table borne[k][q+1]
			for (int c = 0; c < k; c++)
				for (int m = 0; m <= q; m++) { // borne if we add m points to cluster Cc
					std::vector<double> v23; // v23 of each points
					
					for (int i = 0; i < q; i++)
						if (m > 1)
							v23.push_back ( v2[i][c] + dQQ[i][m-1] );
						else
							v23.push_back ( v2[i][c] );

					std::sort (v23.begin(), v23.end());  
		
					double v123 = V1[c];
					for (int  i = 0; i < m; i++)
						v123 += v23[i];

					if (m + sizeCluster[c] > 0)
						borne[c][m] = v123 / (m + sizeCluster[c]);
					else
						borne[c][m] = 0;
				}

			// calculation of k-1 column borneMulti[k][q+1]: borneMulti[c][m] = C1+C2+...+Cc if we add m points
			double borneMulti[k][q+1];
			for (int i = 0; i <= q; i++)
				borneMulti[0][i] = borne[0][i]; // first column is the same

			for (int c = 1; c < k; c++)	{
				for (int m = 0; m <= q; m++) {
					borneMulti[c][m] = 10000000000000;
					for (int i = 0; i <= m; i++) { // if we get i points from cluster Cc and m-i points from previous clusters C1,C2,..,Cc-1
						if (borneMulti[c][m] > (borne[c][i] + borneMulti[c-1][m-i]) )					
							borneMulti[c][m] = borne[c][i] + borneMulti[c-1][m-i];				
					}
				}			
			}
		
			GECODE_ME_CHECK(y.gq(home, borneMulti[k-1][q]));
	










/*


			double t[q+1][k]; // t[i][c] = minimum wcss of cluster c if we add i point .    Now t contain only V1 and V2, not V3
			for (int i = 0; i <= q; i++)
				for (int j = 0; j < k; j++)
					t[i][j] = 0;

			double totalSumCluster[k]; //totalSumCluster[i] = total sum of distance of pair of point in cluster i
			for (int i = 0; i < k; i++) totalSumCluster[i] = 0;

 			for (int i = 0; i < n; i++)
				if (x[i].assigned())
					for (int j = i+1; j < n; j++)
						if (x[j].assigned())
							if (x[i].val() == x[j].val())
								totalSumCluster[ x[i].val() ] += dd[i][j] * dd[i][j];		// It is V1
	
		



			double distanceToCluster[q+1][k]; //  distanceToCluster[i][j] = total squared distance from a point to cluster j. We need to sorted this sum.
			for (int i = 0; i <= q; i++)
				for (int c = 0; c < k; c++)
					distanceToCluster[i][c] = 0;


			q = 0;
			for (int i = 0; i < n; i++)
				if (!x[i].assigned()) {

					for (int j = 0; j < n; j++)
						if (x[j].assigned())  
							if (x[i].in( x[j].val() ))						
								distanceToCluster[q][ x[j].val() ] += dd[i][j] * dd[i][j];										

					q++;
				}





			for (int i = 0; i < q; i++)
				for (int c = 0; c < k; c++)
					if (distanceToCluster[i][c] == 0)				// if distanceToCluster[i] = 0, it means that:   c is not in domain of i  or cluster[c] is EMPTY					
						if (sizeCluster[c] > 0)
						distanceToCluster[i][c] = 10000000000000;


	


			// distQQ: distance between non assigned points

			std::vector<double> distQQ[q]; 
			int q1 = 0; 
			for (int i = 0; i < n; i++) {
				if (!x[i].assigned()) {
					for (int j = 0; j < n; j++) 
						if (!x[j].assigned()) 
							distQQ[q1].push_back( dd[i][j] * dd[i][j]/2 );
					q1++;
				}
			}
			

			for (int i = 0; i < q; i++)
				 std::sort (distQQ[i].begin(), distQQ[i].end());  	// distQQ[ i ][ j ]: distance from point i to point j


			for (int i = 0; i < q; i++) 
				for (int j = 1; j < q; j++)
					distQQ[i][j] = distQQ[i][j] + distQQ[i][j-1];  // distQQ[ i ][ j ]: min sum distance from j point to point i



			for (int i = 0; i <= q; i++) {		// t[i][c] = minimum wcss of cluster c if we add i point 
				for (int c = 0; c < k; c++) {
					double x = 0; int y = 0;

					std::vector<double> v23; 

					for (int j = 0; j < q; j++)
						if (i > 1)
							v23.push_back ( distanceToCluster[j][c] + distQQ[j] [ i - 1]  );					
						else
							v23.push_back ( distanceToCluster[j][c] );					
	

			
					std::sort (v23.begin(), v23.end());  


					x = totalSumCluster[c];
					for (int j = 0; j < i; j++)
						x += v23[j];

					y = i + sizeCluster[c];
					

					if (y > 0) {
						t[i][c] = x/y;
					}
					else 
						t[i][c] = 0;

//					if (sizeCluster[c] == 0) // this group is empty, so of course total distance to this cluster is 0
//						t[i][c] = 0;

				}
			}		



//			for (int i = 0; i <= q; i++)
//				for (int c = 0; c < k; c++)
//					cout << borne[c][i] - t[i][c] << " " << i << " " << c << " " << borne[c][i] << " " << t[i][c] <<  endl; 
		// WHY some times it is not equal
				


			// from table t[i][c] -> calculate bound[0..q][ to all cluster]
			double bound[q+1][2];
			for (int i = 0; i <= q; i++) {	
				bound[i][0] = t[i][0];		// first column = first cluster
				bound[i][1] = 0;
			}
			
			for (int c = 1; c < k; c++) {
					for (int i = 0; i <= q; i++) {
						bound[i][1] = 10000000000000;
						for (int j = 0; j <= i; j++)
							if (bound[i][1] > bound[j][0] + t[i - j][c]) {  // if we take j point from    c-1 clusters and   i-j point from cluster c then what?					
								bound[i][1] = bound[j][0] + t[i - j][c];
							}
					}
  
				// now bound[1] become bound[0]
				for (int i = 0; i <= q; i++) 
					bound[i][0] = bound[i][1];
			}

			// bound[i][1]: bound if we add i point to all clusters
		




	//		for (int i = 0; i <= q; i++)
	//			cout << bound[i][1] - borneMulti[k-1][i] << " "   << bound[i][1] << " " << borneMulti[k-1][i] << endl;
			// Why borneMulti is better in some case	


			GECODE_ME_CHECK(y.gq(home, bound[q][1]));

	//		return ES_OK;
//	return ES_OK;


		// FILTERING 
//_____________________________________________________________________________________________________________

			double dToCluster[n][k];
			for (int i = 0; i < n; i++)
				for (int c = 0; c < k; c++)
					dToCluster[i][c] = 0;
			for (int i = 0; i < n; i++)						// i can make it better: save all fix points to a set. all non fix point to a set
				if (!x[i].assigned())
					for (int j = 0; j < n; j++)
						if (x[j].assigned())
							if (x[i].in(x[j].val()))
								dToCluster[i][ x[j].val() ] += dd[i][j] * dd[i][j];
			q--;





			for (int c = 0; c < k; c++) { // check if value c is consistency.  We will consider c is the last clusters
				sizeCluster[c]++;
				

				// Build bound[i][0] = bound if we add i point to every clusters except cluster c;

 				for (int i = 0; i <= q; i++) {
					bound[i][0] = 0;

					for (int j = i; j <= q+1; j++)		// j points to every clusters - (j-i) point from cluster C_c
						if (bound[i][0] < (bound[j][1] - t[j-i][c]))
							bound[i][0] = bound[j][1] - t[j-i][c];
				}
					





				int qq = 0;

				for (int i = 0; i < n; i++)
					if (!x[i].assigned())
						if (x[i].in(c)) {

							totalSumCluster[c] += dToCluster[i][c];
		
							double tt[n];

							for (int i1 = 0; i1 <= q; i1++) {		// t[i][j] = minimum wcss of cluster j if we add i point .    Now t contain  V1 and V2, AND V3
								int y = 0;

	


								//	x = totalSumCluster[c] + distanceToCluster[i1][c];		// MAYBE MAKE IT BETTER. I think I don't need because we filter furthest points

									y = i1 + sizeCluster[c];
//									t[i1][c] = x/y;
								
									if (y > 0)
										tt[i1] = (t[i1][c] * (y-1)  + dToCluster[i][c] )/ y;	 // t[i1][c] = if we add point x and y-1 point to cluster Cc
									else
										tt[i1] = 0;


							}		

							// we have bound[0..q][0], now take care min 
							qq++;
	
							double minV3 = 10000000000000;
							for (int j = 0; j <= q; j++)
								if (minV3 > bound[j][0] + tt[q - j])  				
									minV3 = bound[j][0] + tt[q - j];
								
	

							if (minV3 >= y.max())
								GECODE_ME_CHECK(x[i].nq(home, c));
							



							totalSumCluster[c] -= dToCluster[i][c];

		
						}
			
				sizeCluster[c]--;
		}




*/



			// Filtering

			for (int c = 0; c < k; c++) {	// we filter value c in each points

				// First, build the column borneExcept[0..q]: borneExcept[m] = borne if we add m points to cluster C1->Ck except cluster Cc
				double borneExcept[q];
				for (int i = 0; i < q; i++) {	// i from 0 to q-1
					borneExcept[i] = 0;
					for (int j = i; j <= q; j++)
						if (borneExcept[i] < (borneMulti[k-1][j] - borne[c][j-i]))	// k-1 is the last columnm
							borneExcept[i] = borneMulti[k-1][j] - borne[c][j-i];
				}


 			

				//for (int i = 0; i < q; i++)
				//	cout << borneExcept[i] - bound[i][0] << " ";    Why boundEcept is better


				// Filtering points
				for (int i = 0; i < q; i++)
					if (x[ setQ[i] ].in(c))  {	// if c is in the domain of points x[ setQ[i] ]
						// calculation bound if we add point setQ[i] and others m points			

						double borneM[q+1]; // borne[m+1] if we add point i and other m points to cluster Cc
						for (int m = 0; m < q; m++) { // m from 0 to q-1
							double xx = borne[c][m] * (sizeCluster[c] + m) + v2[i][c] + 2 * dQQ[i][m]; 
							double yy = sizeCluster[c] + m + 1; // size of cluster if we add point i and m points
							borneM[m+1] = xx/yy;	
						}

						double minBorne = 10000000000000; // borne if we add Total q point = point i + m point to Cc + q-m points to others
						for (int m = 0; m < q; m++)
							if (minBorne > (borneM[1+m] + borneExcept[q-m-1]))
								minBorne = borneM[1+m] + borneExcept[q-m-1];
		
						if (minBorne >= y.max())
								GECODE_ME_CHECK(x[ setQ[i] ].nq(home, c));


					}



			}




		return ES_OK;


	





	}

};

	void wcssConstraint(Home home, IntVarArgs x, FloatVar y) {
		// constraint post function
    ViewArray<Int::IntView> vx(home, x);
    Float::FloatView vy(y);
		if (wcssConstraint::post(home, vx, vy) != ES_OK)
			home.fail();
	}

