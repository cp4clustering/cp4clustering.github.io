#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class paretoConstraint : public Propagator {
	protected:
		Float::FloatView x;
		Float::FloatView xmin;
		Float::FloatView y;
		Float::FloatView ymax;

	public:
		// posting
		paretoConstraint(Home home, Float::FloatView x0, Float::FloatView x1, Float::FloatView y0, Float::FloatView y1) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0), xmin(x1), y(y0), ymax(y1)  {

		 // need change
			x.subscribe(home,*this,Float::PC_FLOAT_BND);
			xmin.subscribe(home,*this,Float::PC_FLOAT_BND);

			y.subscribe(home,*this,Float::PC_FLOAT_BND);
			ymax.subscribe(home,*this,Float::PC_FLOAT_BND);


		}
		static ExecStatus post(Home home, 
			                     Float::FloatView x0, Float::FloatView x1, Float::FloatView y0, Float::FloatView y1) {
			(void) new (home) paretoConstraint(home,x0,x1,y0,y1);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
//	need change
			x.cancel(home,*this,Float::PC_FLOAT_VAL);
			xmin.cancel(home,*this,Float::PC_FLOAT_VAL);

			y.cancel(home,*this,Float::PC_FLOAT_VAL);
			ymax.cancel(home,*this,Float::PC_FLOAT_VAL);


			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		paretoConstraint(Space& home, bool share, paretoConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);
				xmin.update(home, share, p.xmin);
				y.update(home, share, p.y);
				ymax.update(home, share, p.ymax);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) paretoConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}
		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {

			// x : Diametre, y : Separateur
			// nSol = nombre des solutions trouve
			
			
			for (int i = 0; i < nSolution; i++) {

				if (xmin.min() >= saveDiam[i]) 
					GECODE_ME_CHECK(y.gq(home, saveSepa[i] + 0.00000000001));
				
				
				if (ymax.max() <= saveSepa[i]) 
					GECODE_ME_CHECK(x.lq(home, saveDiam[i] - 0.00000000001));



				

				
			}
			

									
		  return ES_OK;
		}
};

	void paretoConstraint(Home home, FloatVar x, FloatVar xmin, FloatVar y, FloatVar ymax) {
		// constraint post function
	    Float::FloatView vx(x);
	    Float::FloatView vxmin(xmin);

	    Float::FloatView vy(y);
	    Float::FloatView vymax(ymax);

		if (paretoConstraint::post(home, vx, vxmin, vy, vymax) != ES_OK)
			home.fail();
	}

