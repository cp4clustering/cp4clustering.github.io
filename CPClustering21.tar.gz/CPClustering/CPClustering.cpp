#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 

#include "common/commonVariables.cpp"


#include "common/branchDiameter.cpp"
#include "common/branchWCSD.cpp"
#include "common/branchWCSS.cpp"

#include "common/diameterConstraint.cpp"
#include "common/separationConstraint .cpp"
#include "common/wcsdConstraint.cpp"
#include "common/wcssConstraint.cpp"
#include "common/paretoConstraint.cpp"

#include "common/commonFunction.cpp"
#include "common/clusterOptions.cpp"



using namespace Gecode;
using namespace std;



class Cluster : public Script {
protected:
  const ClusterOptions& options;
  IntVarArray G; // G[i]: 1..k,  G[i]: class of i
  FloatVar Wcsd; // Wcsd (formule avec ou sans Division est dans la 
  FloatVar Wcss; // Wcss 

  FloatVar Dmax;
  FloatVar Dmin;

  FloatVar Smin;
  FloatVar Smax;

  double Diameter_max;	
  double Separateur_min;

public:

	Cluster(const ClusterOptions& opt) : 
	options(opt),
	G(*this, n, 0, opt.k()-1), 
	Wcsd(*this, 0, Float::Limits::max) ,
	Wcss(*this, 0, Float::Limits::max) ,

	Dmax(*this, 0, Float::Limits::max) ,
	Dmin(*this, 0, Float::Limits::max) ,
	Smin(*this, 0, Float::Limits::max) ,
	Smax(*this, 0, Float::Limits::max) ,

	Diameter_max(Float::Limits::max),
	Separateur_min(0.0000000000000001)
	{


		//______________________________________________________________________________________________________________________________//
		//										PARTITION CONSTRAINT		 															//
		//______________________________________________________________________________________________________________________________//


		// PRECEDE 
		IntArgs t(opt.k()); // array [0..k-1]
		for (int i = 0; i < opt.k(); i++)
			t[i] = i;
		precede(*this, G, t);

		// COUNT: at least kmin group
		count(*this, G, opt.kmin()-1, IRT_GQ, 1);



		//______________________________________________________________________________________________________________________________//
		//										USER CONSTRAINT		 															//
		//______________________________________________________________________________________________________________________________//

		// Must-link cannot link constraints from file
		ifstream fmlcl(opt.c().c_str(),ios::in);	// read file
		if (output)
			cout << opt.c() << endl;
		int x = 0; int y = 0; int z = 0;
		int neworder[n];
		for (int i = 0; i < n; i++)
			neworder[order[i]] = i;
		while (!fmlcl.eof())  {
				fmlcl >> x >> y >> z;
				x = neworder[x];		// point x in new order
				y = neworder[y];
				if (z == 1)		// post must-link constraint	
					rel(*this, G[x], IRT_EQ, G[y]);
				if (z == -1)	// post cannot-link constraint
					rel(*this, G[x], IRT_NQ, G[y]);
				z = 0;
		}


		//USER CONSTRAINT: CONTRAINT OF Diameter
		if (bound_DiameterMax > 0) {
			rel(*this, Dmax, FRT_LQ, bound_DiameterMax);
			if (obj != 8)
				diameterConstraint(*this, G, Dmax, Dmin);
		}


		//USER CONSTRAINT: CONTRAINT OF Separation
		if (bound_SplitMin > 0) {
			rel(*this, Smin, FRT_GQ, bound_SplitMin);
			if (obj != 9)
				separationConstraint(*this, G, Smin, Smax);	
		}






		//___________________________________COUNTING CONSTRAINT: SIZE OF EACH GROUP_______________________________________________________
		if (opt.sizeMin()) {
			for (int j = 0; j < n; j++)
				count(*this, G, G[j], IRT_GQ, opt.sizeMin());
		}

		if (opt.sizeMax())
			for (int c = 0; c < k; c++) 
				count(*this, G, c, IRT_LQ, opt.sizeMax());
		//----------------------------------END COUNTING CONSTRAINT: SIZE OF EACH GROUP----------------------------------



		// USER CONSTRAINT: CONSTRAINT OF DENSITY: Epsilon + Minpoint
			if (opt.epsilon() * opt.minpoint() > 0) {
				for (int i = 0; i < n; i++) { // we need to check point 0
					int npoint = 0; 
					for (int j = 0; j < n; j++)
						if (dd[i][j] <= opt.epsilon()) 
							if (i != j) 
								npoint++; 		// number of point near point i;
					if (npoint >= 0) {
							IntVarArgs nearPoint(npoint);
							npoint = 0;
							for (int j = 0; j < n; j++)
								if (dd[i][j] <= opt.epsilon()) 
									if (i != j) 
										nearPoint[npoint++] = G[j];
					  count(*this, nearPoint, G[i], IRT_GQ, opt.minpoint()); // there are at least minpoint near G[i] at distance epsilon
					}
				}
			}
		


		//______________________________________________________________________________________________________________________________//
		//							 CONSTRAINT ON OBJECTIVE FUNCTION : 																//
		//______________________________________________________________________________________________________________________________//

		// WCSD criterion
		if (obj == 3) {
			sortD(); // sort distance for Wcsd constraint
			wcsdConstraint(*this, G, Wcsd);
		}


		// WCSS criterion
		if (obj == 4) {
			sortD(); // sort distance for Wcsd constraint
			wcssConstraint(*this, G, Wcss);
		}


		//___________________________________CONSTRAINT of SEPARATION for Pareto_____________________________________________________
		if ((obj == 1) && (bestSepa > 0)) {
			for (int i = 0; i < n; i++)
				for (int  j = i+1; j < n; j++)
				  if (dd[i][j] <= bestSepa) 
				  	rel(*this, G[i], IRT_EQ, G[j]);


			if (Diameter_UB > 0)
			for (int i = 0; i < n; i++)
				for (int  j = i+1; j < n; j++)
				  if (dd[i][j] > Diameter_UB) 
				  	rel(*this, G[i], IRT_NQ, G[j]);

		}
	


		//___________________________________CONSTRAINT of DIAMETER_____________________________________________________
		if ((obj == 2) && (bestDiam > 0)) {
			for (int i = 0; i < n; i++)
				for (int  j = i+1; j < n; j++)
				  if (dd[i][j] > bestDiam) 
				  	rel(*this, G[i], IRT_NQ, G[j]);



			if (bestSepa > 0) {
			for (int i = 0; i < n; i++)
				for (int  j = i+1; j < n; j++)
				  if (dd[i][j] < bestSepa) 
				  	rel(*this, G[i], IRT_EQ, G[j]);

			}

		}
		
		// Diameter criterion with diameter constraint
		if (obj == 8) 
			diameterConstraint(*this, G, Dmax, Dmin);

		// Split criterion with split constraint
		if (obj == 9) 
			separationConstraint(*this, G, Smin, Smax);

		// Pareto criterion with pareto constraint
		if (obj == 10)  {
			diameterConstraint(*this, G, Dmax, Dmin);
			separationConstraint(*this, G, Smin, Smax);
			paretoConstraint(*this, Dmax, Dmin, Smin, Smax);
		}


		if (output)
			cout << "Posting Constraints in \t:  " << give_time() - startAll << endl;
		startAll = give_time();

		if (output)
			cout << "__________________________________________________________" << endl;




		//______________________________________________________________________________________________________________________________//
		//								BRANCHING 																						//
		//______________________________________________________________________________________________________________________________//

		if (obj == 8)  
			branchDiameter::post(*this, G);

		if (obj == 9)  
			branchDiameter::post(*this, G);

		if (obj == 10)  
			branchDiameter::post(*this, G);

		if (obj == 1) 
			branchDiameter::post(*this, G);

		if (obj == 0) 
			branchDiameter::post(*this, G);

		if (obj == 2)  
			branchDiameter::post(*this, G);

		if (obj == 3) 
			branchWCSD::post(*this, G); 

		if (obj == 4) 
//			branchDiameter::post(*this, G);
			branchWCSS::post(*this, G);
	}


	
	/*
		Update function
	*/
	Cluster(bool share, Cluster& s) : Script(share, s), options(s.options), Diameter_max(s.Diameter_max), Separateur_min(s.Separateur_min) {

		G.update(*this, share, s.G);
		Dmax.update(*this, share, s.Dmax);
		Dmin.update(*this, share, s.Dmin);
		Smin.update(*this, share, s.Smin);
		Smax.update(*this, share, s.Smax);
		Wcsd.update(*this, share, s.Wcsd);
		Wcss.update(*this, share, s.Wcss);

 		if (s.status() == 1) 
			FoundSolution = 1;

		if (obj == 10) // for Pareto constraint
 			if (s.status() == 1) {
				// now we have a solution. We calcul the diameter of solution
				double diam = 0;
				double sepa = Float::Limits::max;
				for (int i = 0; i < G.size(); i++)
					for (int j = i+1; j < G.size(); j++) {
							if (G[i].val() == G[j].val()) {
								if (diam < dd[i][j])
									diam = dd[i][j];
							}
							if (G[i].val() != G[j].val()) {
								if (sepa > dd[i][j])
									sepa = dd[i][j];
							}


					}
				if (output)
					cout << "Diam =  " << diam << ", sepa = " << sepa << endl;
				saveDiam[nSolution] = diam;
				saveSepa[nSolution] = sepa;
				nSolution++;
			}	


		if ((obj == 1) || (obj == 8))
			if (s.status() == 1) {
				// now we have a solution. We calcul the diameter of solution
				double diam = 0;
				double sepa = Float::Limits::max;
				for (int i = 0; i < G.size(); i++)
					for (int j = i+1; j < G.size(); j++) {
							if (G[i].val() == G[j].val()) {
								if (diam < dd[i][j])
									diam = dd[i][j];
							}
							if (G[i].val() != G[j].val()) {
								if (sepa > dd[i][j])
									sepa = dd[i][j];
							}
					}
				s.Diameter_max = diam;
				bestDiam = diam;
				bestSepa = sepa;
				stopCondition = 0;
			}	


		if ((obj == 2) || (obj == 9))
			if (s.status() == 1) {
				// now we have a solution. We calcul the diameter of solution
				double diam = 0;
				double sepa = Float::Limits::max;	
				for (int i = 0; i < G.size(); i++)
					for (int j = i+1; j < G.size(); j++) {
							if (G[i].val() == G[j].val()) {
								if (diam < dd[i][j])
									diam = dd[i][j];
							}
							if (G[i].val() != G[j].val()) {
								if (sepa > dd[i][j]) 
									sepa = dd[i][j];
							}


					}
				s.Separateur_min = sepa;		
				bestDiam = diam;
				bestSepa = sepa;
				stopCondition = 0;
			}	
	}

  	virtual Space* copy(bool share) {
    	return new Cluster(share,*this);
  	}


	/* 
		BRANCH AND BOUND constraint: Next solution must be better than the previous
	*/
	virtual void constrain(const Space& sol) { 
		// get the solution from Space
		const Cluster& _sol=static_cast<const Cluster&>(sol);
		if (obj == 1)	{
			for (int i = 0; i < G.size(); i++)
				for (int j = i+1; j < G.size(); j++) 
					if ((dd[i][j] >= _sol.Diameter_max) && (dd[i][j] < Diameter_max)) {
						rel(*this, G[i], IRT_NQ, G[j]);
					}
			Diameter_max = _sol.Diameter_max;
		}

		if (obj == 2)	{
			for (int i = 0; i < G.size(); i++)
				for (int j = i+1; j < G.size(); j++) 
					if ((dd[i][j] <= _sol.Separateur_min) && (dd[i][j] > Separateur_min)) {
						rel(*this, G[i], IRT_EQ, G[j]);
					}
			Separateur_min = _sol.Separateur_min;
		}

		if (obj == 3) 
			rel(*this, Wcsd < _sol.Wcsd.min());

		if (obj == 4) 
			rel(*this, Wcss < _sol.Wcss.min());

		if (obj == 14) 
			rel(*this, Wcss < _sol.Wcss.min());


		if (obj  == 8) 
			rel(*this, Dmax < _sol.Diameter_max);

		if (obj  == 9) 
			rel(*this, Smin > _sol.Separateur_min);
	}


	/* 
		Print solution
	*/
	virtual void print(ostream& os) const {	
		ofstream fObj("result.txt",ios::out);	// write result to class.txt
		double diam = 0; double sepa = Float::Limits::max;
		if (output)
			os << G << endl;

		int checkAllG = 0;
		while ((checkAllG < n) && G[checkAllG].assigned()) checkAllG++;   // check if we have a solution or still in the search

		if ((obj == 1) || (obj == 2) || (obj == 3) || (obj == 4) ||(obj == 8) || (obj == 9) )  {
			int GR[n];	
			for (int i = 0; i < n; i++)
				GR[i] = -1;
			for (int i = 0; i < n; i++) {
			  GR[order[i]] = G[i].val();
			  finalClass[i] = G[i].val();
			}	

			ofstream fOut(classResult.c_str(),ios::out);	// read file
			
			//ofstream fOut("class.txt",ios::out);	// write result to class.txt
			for (int i = 0; i < G.size(); i++)
			  fOut << GR[i] << endl;		
	
			fOut.close();
			if (output)
				os << "Size of groups: ";
			for (int c = 0; c < k; c++) {
			  int sum = 0;
			  for (int i = 0; i < G.size(); i++)
					if (G[i].val() == c)
			 			 sum++;
				if (output)
			  		os << sum << " ";
			}
			if (output)
				os << endl;		

		
			for (int i = 0; i < G.size(); i++)
				for (int j = i+1; j < G.size(); j++) {
						if (G[i].val() == G[j].val()) 
							if (diam < dd[i][j])
								diam = dd[i][j];
						if (G[i].val() != G[j].val()) 
							if (sepa > dd[i][j]) {
								sepa = dd[i][j];
							}
					
				}
		if (output)
			cout << "Diam =  " << diam << " ,Sepa = " << sepa <<  endl;
		}
		if (obj == 3)
			if (output)
				os << "WCSD: " << Wcsd.min() << " " << Wcsd.max() << endl;
		if (obj == 4) 
			if (output)
				os << "WCSS: " << Wcss.min() << " " << Wcss.max() << endl;
	
		if (obj == 14) 
			if (output)
				os << "WCSS: " << Wcss.min() << " " << Wcss.max() << endl;
		if (output)
		    cout << "This solution is found AFTER: " << give_time() - startAll << endl;
		timebestSol = give_time() - startAll;

		if ((obj == 1) || (obj == 8) || (obj == 11))
			fObj << diam;
		if ((obj == 2) || (obj == 9) || (obj == 12))
			fObj << sepa;
		if ((obj == 3) || (obj == 13))
			fObj << Wcsd.max();
		if ((obj == 4) || (obj == 14))
			fObj << Wcss.max();


	}




	//____________________________________LNS______________________________________________________________
	// obj == 14
	
	 bool master(const CRI& cri) {
		if (output)  {
			cout << "___MASTER___" << endl;
			cout << "restart = " << cri.restart() <<endl;
		}
		if (cri.last() != NULL)
			constrain(*cri.last());
		return true;
	}

/*	void slave(const CRI& cri) {	
		cout << "___SLAVE____" << endl;
		cout << "restart = " << cri.restart() <<endl;
		cout << "fail() = "  << cri.fail() << endl;

		if (cri.restart() == 0)
			first();
		else 
			next(static_cast<const Cluster&>(*cri.last()));

	}
*/

	void first(void) {
		if (output)
			cout << "___ FIRST *******************" << endl;
		sortD(); // sort distance for Wcsd constraint
		wcssConstraint(*this, G, Wcss);
//		branchDiameter::post(*this, G);
		branchWCSS::post(*this, G);
		
	}


	void next(const Cluster& b) {	
		if (output)
			cout << "___ NEXT *******************" << endl;
		timeval t1;	
		gettimeofday(&t1, NULL);
		srand(t1.tv_usec * t1.tv_sec); 


		for (int i = 0; i < 3*n/10; i++) {
			int x = rand() % n;
			rel(*this, G[x], IRT_EQ, b.G[x].val());
		}

		wcssConstraint(*this, G, Wcss);
//		branchDiameter::post(*this, G);		
		branchWCSS::post(*this, G);

	}











};

//______________________________________________________________________________________________________________________________//
//										END  CLASS CLUSTER			 															//
//______________________________________________________________________________________________________________________________//









	// read data() + init
	void init(const ClusterOptions& opt) {
		output = opt.output();
		obj = opt.obj();
		startAll = give_time();
		ifstream fin(opt.f().c_str(),ios::in);	// read file
		classResult = opt.r();
		// n: number of points, k: number of clusters, nA: number of attributes
	 	k = opt.k();  nA = opt.a(); obj = opt.obj();
		fin >> n; 	// no need
		initCommonVariables(n);		

		if (opt.datatype() == 0)
			readData(n, nA, fin, a);	// read all attributs of points to A
		if (opt.datatype() == 1)
			readDataMatrix(n, fin,maxD, minD);	// read all attributs of points to A
		for (int i = 0; i < k; i++)
			center[i] = a[i];
		int realClass[n];
		readRealClass(n, nA, opt.f() + "Class", a, realClass); 		// input: iris.txt => real class:  iris.txtClass		
		n = opt.n();
		if (output)
			cout << "DONE Reading Data  \n";

		// for time of calcul
		timeval t1;	
		gettimeofday(&t1, NULL);



		//_________________________________RE ORDERING POINT________________________________________________

		if (opt.datatype() == 0) // only when data is read in normal form
			switch (opt.order()) {
				case 0:
					if (output)
						cout << "No Ordering Points" << endl;
					break;
				case 1:
					reOrderPointFPF_lastK(n, k, nA, a, realClass); // these functions are in commonFunction.cpp
					break;
				case 2:
					reOrderPointFPF(n, k, nA, a, realClass);
					break;
				case 3:
					reOrderPointRANDOM(n, a, realClass);
					break;	
				case 4:
					reOrderPointVariance(n, k, nA, a, realClass);
					break;
			}
			startAll = give_time();



		//________________________________CALCUL MATRIX OF DISTANCE_____________________________________________
		if (opt.datatype() == 0) {
			calculD(n, n, 0, maxD, minD, a); // ORDER_FIRST if we take first n points or ORDER_LAST if we take last n point
		}
//		cout << "Calcul Matrix of Dissimilarity in \t: " << give_time() - startAll << endl;
		startAll = give_time();

		//________________________________CALCUL DIAMETER FPF_____________________________________________	
		diamHeuristic = calculDiameterFPF(n, k);
		diamHeuristicKmin = calculDiameterFPF(n, opt.kmin());
//		cout << "Diameter heuristic FPF = " << diamHeuristic << " " << diamHeuristicKmin << ", in \t: " << give_time() - startAll << endl;
		startAll = give_time();
		//--------------------------------END CALCUL DIAMETER FPF----------------------------------
		bound_DiameterMax = opt.diam();
		bound_SplitMin = opt.s();
	}




	
	/*		
		Pareto criterion which uses  only the optimization of  Diameter 
	*/
	void paretoB1(const ClusterOptions& opt) {
		ofstream fObj("result.txt",ios::out);	

		double maxRatio  = 0;
		double lastDiam, lastSepa;
		findAllSeparateur();
		int count = 0;
		for (int i = 0; i < n-1; i++) {
			if ( (allSeparation[i] > 0) && (allSeparation[i] >= bestSepa) ) {
				count++;
				bestSepa = allSeparation[i];

				if (bound_SplitMin < bestSepa)	
					bound_SplitMin = bestSepa;

				obj = 8;	
				if (output) {
					cout << "_________________________________________\n";
					cout << "FINDING OPTIMAL Diameter with constraint of Separateur " << endl;
				}
				Script::run<Cluster,BAB,ClusterOptions>(opt);	
				if (output)
					cout << "RATIO: " << bestDiam/bestSepa << " , Diam = " << bestDiam << " , Sepa = " << bestSepa << " , (allSeparation = " << allSeparation[i] << ")" << endl;

				saveSepa[ nSolution ] = bestSepa;
				saveDiam[ nSolution ] = bestDiam;
				nSolution++;
				if (maxRatio < bestSepa/bestDiam) {
					maxRatio = bestSepa/bestDiam;
					lastDiam = bestDiam;
					lastSepa = bestSepa;
				}
			}
		} 
		deleteBadParetoSolution();
		for (int i = 0; i < nSolution; i++)
			if (!badParetoSolution[i]) {
				if (output)
					cout << "Solution " << i << " : " << saveSepa[i] << " / " << saveDiam[i] << endl;
				fObj << saveDiam[i] << " " << saveSepa[i] << endl;
			}
		if (output)
			cout << "FINAL RATIO: " << lastSepa/lastDiam <<  "  = "  << lastSepa << " / " << lastDiam << endl;
		
}


	/*
		Pareto criterion with the optimization of Diameter and Split 
		the only different between B2 and B3 is the time limit. In B3, there is time limit for each run
	*/
	void paretoB23(ClusterOptions& opt) {
		ofstream fObj("result.txt",ios::out);	
		double maxRatio  = 0;
		double lastDiam, lastSepa;

		findAllSeparateur();
		while (!stopCondition) 
		{	
			stopCondition = 1;
			opt.time(0);
			obj = 8;	
			if (output) {
				cout << "_________________________________________\n";
				cout << "FINDING OPTIMAL Diameter with constraint of Separateur " << endl;
			}


			bound_DiameterMax = 0;
			bound_SplitMin = bestSepa;
	
			Script::run<Cluster,BAB,ClusterOptions>(opt);	
			saveSepa[ nSolution ] = bestSepa;
			saveDiam[ nSolution ] = bestDiam;
		

			nSolution++;

			if (!stopCondition) {
				obj  = 9;
				if (opt.obj() == 7)  	
					opt.time(10000);
				if (output) {
					cout << "_________________________________________\n";
					cout << "FINDING OPTIMAL Separation with constraint of Diameter " << endl;
					cout << bestSepa << " " << bestDiam << endl;
				}

				bound_DiameterMax = bestDiam+0.0000000000000001;
				bound_SplitMin = 0;

				Script::run<Cluster,BAB,ClusterOptions>(opt);	
				saveSepa[ nSolution ] = bestSepa;
				saveDiam[ nSolution ] = bestDiam;
				nSolution++;
			}
		}


		deleteBadParetoSolution();
		for (int i = 0; i < nSolution; i++)
			if (!badParetoSolution[i]) {
				if (output)
					cout << "Solution " << i << " :  $(" <<  saveDiam[i] << ", " << saveSepa[i] << ")$" << endl;
				fObj << saveDiam[i] << " " << saveSepa[i] << endl;
				if (maxRatio < saveSepa[i]/saveDiam[i]) {
					maxRatio = saveSepa[i]/saveDiam[i];
					lastDiam = saveDiam[i];
					lastSepa = saveSepa[i];
				}

			}
		if (output) {
			cout << "FINAL RATIO: " << lastSepa/lastDiam <<  "  = "  << lastSepa << " / " << lastDiam << endl;
			cout << endl ;
		}

	}

int main(int argc, char* argv[]) {
	double start2 = give_time();
	ClusterOptions opt;
	opt.solutions(0);	// find all solutions
	opt.parse(argc,argv);
	opt.c_d(50); 
	opt.a_d(50);  // if c_d = a_d = 0: No recomputation, we save all nodes' information
	init(opt);	// read and init Data
//	opt.time(10000);
	
	if (obj == 14) {
		opt.restart(RM_CONSTANT );
		opt.restart_scale(1000);
		Script::run<Cluster,BAB,ClusterOptions>(opt);	
	}

	if (obj == 11) {
		opt.solutions(1);
		obj = 1;
	}
	if (obj == 12) {
		opt.solutions(1);
		obj = 1;
	}
	if (obj == 13) {
		obj = 3;
		opt.solutions(1);
	}
	if ((obj <= 4) || (obj == 8) || (obj == 9)) 		// Diameter, Separation, WCSD, WCSS
		Script::run<Cluster,BAB,ClusterOptions>(opt);	
	// Pareto with Pareto Constraints
	if (obj == 10) {
		Script::run<Cluster,BAB,ClusterOptions>(opt);	
		if (output)
			cout << "Pareto Solutions : \n";
		deleteBadParetoSolution();
		for (int i = 0; i < nSolution; i++)
			if (!badParetoSolution[i])
				if (output)
					cout << "Solution " << i << " :  $(" <<  saveDiam[i] << ", " << saveSepa[i] << ")$" << endl;
	}
	if (obj == 5)	// B1	: Pareto with B1
		paretoB1(opt);

	if ((obj == 6) || (obj == 7)) {	// B2 and B3
			paretoB23(opt);
	}
printAMAT();	

		//cout << "SEARCHING TIME : " << give_time() - startAll << endl;
		cout << "Total time: "<< give_time() - start2 << endl;


	return 0;
}

