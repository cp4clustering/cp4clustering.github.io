#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;





class branchWCSS : public Brancher {
protected:
  /// Views of the brancher
  ViewArray<Int::IntView> x; // I
  /// Next variable to branch on
  mutable int start;
  /// %Choice
  class Choice : public Gecode::Choice {
  public:
    /// Position of variable
    int pos;
    /// Value of variable
    int val;
    /** Initialize choice for brancher \a b, position \a pos0, 
     *  and value \a val0.
     */
    Choice(const Brancher& b, int pos0, int val0)
      : Gecode::Choice(b,2), pos(pos0), val(val0) {}
    /// Report size occupied
    virtual size_t size(void) const {
      return sizeof(Choice);
    }
    /// Archive into \a e
    virtual void archive(Archive& e) const {
      Gecode::Choice::archive(e);
      e << pos << val;
    }
  };
 
  /// Construct brancher
  branchWCSS(Home home, ViewArray<Int::IntView>& xv) 
    : Brancher(home), x(xv), start(0) {}
  /// Copy constructor
  branchWCSS(Space& home, bool share, branchWCSS& b) 
    : Brancher(home, share, b), start(b.start) {
    x.update(home, share, b.x);
  }
public:
  /// Check status of brancher, return true if alternatives left
  virtual bool status(const Space&) const {
    for (int i=start; i<x.size(); i++)
      if (!x[i].assigned()) {
        start = i; return true;
      }
    return false;
  }

  /// Return choice
  virtual Gecode::Choice* choice(Space&) {






    int n = x.size(); // there is n point
    unsigned int minSize = 100000, i = 0;
    
    for (int j = start; j < n; j++)  	// search all point that are not assigned (not instantiated)
      if ((!x[j].assigned()) && (minSize > x[j].size())) {   // choice the first point that has Min Size of Domain
				minSize = x[j].size();
				i = j;
      }


	// I will choice point that increase min variance
	double distanceToCluster[n][k];
	for (int i = 0; i < n; i++)
		for (int c = 0; c < k; c++)
			distanceToCluster[i][c] = 0; // distance from a point to a cluster

	for (int i = 0; i < n; i++)
		if (!x[i].assigned())
			for (int j = 0; j < n; j++)
				if (x[j].assigned())
					if (x[i].in( x[j].val() )) {
						distanceToCluster[i][ x[j].val() ] += dd[i][j] * dd[i][j];
					}


	double totalSumCluster[k]; //totalSumCluster[i] = total sum of distance of pair of point in cluster i
	for (int i = 0; i < k; i++) totalSumCluster[i] = 0;

	for (int i = 0; i < n; i++)
		if (x[i].assigned())
			for (int j = i+1; j < n; j++)
				if (x[j].assigned())
					if (x[i].val() == x[j].val())
						totalSumCluster[ x[i].val() ] += dd[i][j] * dd[i][j];		// It is V1



	double sizeCluster[k]; // number of point in a cluster
	for (int i = 0; i < k; i++) sizeCluster[i] = 0;

	for (int i = 0; i < n; i++)
		if (x[i].assigned()) 
			sizeCluster[ x[i].val() ]++;

	if (!FoundSolution) {
		double bestDelta = 100000000;
		int a, b;

		for (int i = 0; i < n; i++)
			if (x[i].size() == minSize ) {
				for (int c = 0; c < k; c++) {
					if (x[i].in(c)) {
						double V3 = (distanceToCluster[i][c] + totalSumCluster[c] )/ (sizeCluster[c] + 1);
						double oldV3 = 0;
						if (sizeCluster[c] > 0) oldV3 =  totalSumCluster[c] / sizeCluster[c];
						double delta = V3 - oldV3;
						if (bestDelta > delta) {
							bestDelta = delta;
							a = i;
							b = c;
						}

					
	 				}
				}

			}

		return new Choice(*this,a,b);



	}

	double maxDelta = -1;
	int aa, bb;
	for (int i = 0; i < n; i++)
		if (x[i].size() >= minSize ) {
			double bestDelta = 100000000;
			int a, b;
			for (int c = 0; c < k; c++) {
				if (x[i].in(c)) {
					double V3 = (distanceToCluster[i][c] + totalSumCluster[c] )/ (sizeCluster[c] + 1);
					double oldV3 = 0;
					if (sizeCluster[c] > 0) oldV3 =  totalSumCluster[c] / sizeCluster[c];
					double delta = V3 - oldV3;
					if (bestDelta > delta) {
						bestDelta = delta;
						a = i;
						b = c;
					}

					
 				}
			}

			if (maxDelta < bestDelta) {
				maxDelta = bestDelta;
				aa = a;
				bb = b;
			}
		}

    return new Choice(*this,aa,bb);


  }

  /// Return choice
  virtual Choice* choice(const Space&, Archive& e) {
    int pos, val;
    e >> pos >> val;
    return new Choice(*this, pos, val);
  }
  /// Perform commit for choice \a _c and alternative \a a
  virtual ExecStatus commit(Space& home, const Gecode::Choice& _c, unsigned int a) {
    const Choice& c = static_cast<const Choice&>(_c);
    if (a == 0)
      return me_failed(x[c.pos].eq(home, c.val)) ? ES_FAILED : ES_OK;
    else 
      return me_failed(x[c.pos].nq(home, c.val)) ? ES_FAILED : ES_OK;
  }
  /// Copy brancher
  virtual Actor* copy(Space& home, bool share) {
    return new (home) branchWCSS(home, share, *this);
  }
  /// Post brancher
  static void post(Home home, const IntVarArgs& x) {
    ViewArray<Int::IntView> xv(home, x);
    (void) new (home) branchWCSS(home, xv);
  }
  /// Delete brancher and return its size
  virtual size_t dispose(Space&) {
    return sizeof(*this);
  }
};
