#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 

#include "common/commonVariables.cpp"

#include "common/branchDiameter.cpp"
#include "common/branchSeparation.cpp"

#include "common/branchMix.cpp"
#include "common/branchKmeans.cpp"

//#include "common/branchVarianceDivision.cpp"
#include "common/branchVariance.cpp"


//#include "common/varianceConstraintDivision.cpp"
#include "common/varianceConstraint.cpp"
#include "common/kMeansConstraint.cpp"

#include "common/commonFunction.cpp"
#include "common/clusterOptions.cpp"
//#include "common/IGConstraint.cpp"
#include "common/symmetryConstraint.cpp"
#include "common/diameterConstraint.cpp"

using namespace Gecode;
using namespace std;


double timebestSol;


double bestD = 0;

class Cluster : public Script {
protected:
  const ClusterOptions& options;
  IntVarArray G; // G[i]: 1..k,  G[i]: class of i
  FloatVar variance; // variance (formule avec ou sans Division est dans la 
  FloatVar DS;
public:
  enum {
    ORDER_NONE, ORDER_POID, ORDER_FPF, ORDER_RANDOM
  };
  enum {
    ORDER_FIRST, ORDER_LAST // take first n point or take last n point
  };

  Cluster(const ClusterOptions& opt) : 
  options(opt),
  G(*this, opt.n(), 0, opt.k()-1), 
  variance(*this, 0, Float::Limits::max) ,
  DS(*this, 0, Float::Limits::max)

//  I(*this, opt.k(), 0, opt.n()-1)
 
  {

//______________________________________________________________________________________________________________________________//
//								READ DATA + RE-ORDER POINTS + CALCUL MATRIX D + CALCUL DIAMETER FPF								//
//______________________________________________________________________________________________________________________________//



	int ORDER_first_last = ORDER_FIRST;
    double maxD, minD; // max and min Distance between points
    startAll = give_time();
    ifstream fin(opt.f().c_str(),ios::in);	// read file

    int n; // n: number of points, k: number of clusters, nA: number of attributes
    int k = opt.k(); int nA = opt.a();	nClass = k; objectiveFunction = opt.obj();

    fin >> n; 	// we will clustering last nSmall objects from n objects. But we always have to reorder n point. 
//	n = opt.n();
    vector<double> a[n];
	nSmall = opt.n();
	nBig = n;
	initCommonVariables(nBig);		// nBIG: total number of points in database. nSmall: number of point we wanna to cluster


//	readPreviousResult(); // read  previous result for lower bound of variance (or diameter?). but sometimes we cannot add user-constraints


	if (opt.datatype() == 0)
		readData(n, nA, fin, a);	// read all attributs of points to A
	if (opt.datatype() == 1)
		readDataMatrix(n, fin,maxD, minD);	// read all attributs of points to A
	
    int realClass[n];
	readRealClass(n, nA, opt.f() + "Class", a, realClass); 		// input: iris.txt => real class:  iris.txtClass
//----------------------------------END  READ DATA FROM FILE AND INIT VARIABLES----------------------------------


//_________________________________INIT RANDOMIZE___________________________________________________
	timeval t1;	
	gettimeofday(&t1, NULL);
	srand(t1.tv_usec * t1.tv_sec); 
	
	for (int i = 0; i < 0; i++) {
	  int x = rand() % n;
      int y = rand() % n;
	  swap(a[x], a[y]);

	}


//	cout << "Randomly reorder point \n";


	nBig = nSmall;	
	n = nSmall;


//_________________________________RE ORDERING POINT________________________________________________

if (opt.datatype() == 0) // only when data is read in normal form
	switch (opt.order()) {
		case ORDER_NONE:
//			cout << "No Ordering Points" << endl;
			break;
	    case ORDER_POID:
			reOrderPointPoid(n, k, nA, a, realClass); // these functions are in commonFunction.cpp
			break;
		case ORDER_FPF:
			reOrderPointFPF(n, k, nA, a, realClass);
			break;
		case ORDER_RANDOM:
			reOrderPointRANDOM(n, a, realClass);
			break;	
		case 4:
			reOrderPointVariance(n, k, nA, a, realClass);
			break;
    }
    startAll = give_time();

    
//----------------------------------END RE ORDERING POINT----------------------------------


//________________________________CALCUL MATRIX OF DISTANCE_____________________________________________

	if (opt.datatype() == 0) {
		calculD(n, nSmall, ORDER_first_last, maxD, minD, a); // ORDER_FIRST if we take first n points or ORDER_LAST if we take last n point
	}
	n = nSmall;
//--------------------------------END CALCUL MATRIX OF DISTANCE----------------------------------
//    cout << "Calcul Matrix of Dissimilarity in \t: " << give_time() - startAll << endl;
    startAll = give_time();

//________________________________CALCUL DIAMETER FPF_____________________________________________	

	double diamHeuristic = calculDiameterFPF(n, k);
	double diamHeuristicKmin = calculDiameterFPF(n, opt.kmin());

//    cout << "Diameter heuristic FPF = " << diamHeuristic << " " << diamHeuristicKmin << ", in \t: " << give_time() - startAll << endl;
    startAll = give_time();
//--------------------------------END CALCUL DIAMETER FPF----------------------------------
    



//______________________________________________________________________________________________________________________________//
//								POSTING CONSTRAINT	: BASIC CONSTRAINT + USER CONSTRAINTS										//
//______________________________________________________________________________________________________________________________//


// _______________________________POST BASIC CONSTRAINT_______________________________________________
	// CONSTRAINT OF DOMAIN OF DIAMETER OR SEPARATION
	bestD = maxD;

// _______________________________POST BASIC CONSTRAINT_______________________________________________
	// CONSTRAINT OF DOMAIN OF DIAMETER OR SEPARATION
	rel(*this, DS, FRT_GQ, minD);
	rel(*this, DS, FRT_LQ, maxD);

	cout << "min max D = " << minD << " " << maxD << endl;
 
    // RELIER I et G:  G[I[c]] = I[c]
/*    for (int c = 0; c < k; c++)
	      element(*this, G, I[c], I[c]);			
	*/
	
    // G[0] = 0, I[0] = 0
//    rel(*this, I[0], IRT_EQ, 0);

  
    // #{c|I[c] = G[i]} = 1  for every i in [1..n]
//    for (int i = 0; i < n; i++)
 //     count(*this, I, G[i], IRT_EQ, 1);


// there are k groups
    for (int c = 0; c < opt.kmin(); c++)
      count(*this, G, c, IRT_GQ, 1);


// Symmetry breaking



/*	for (int i = 1; i < n; i++) {

		IntVarArgs zz(i);
		for (int j = 0; j < i; j++)
			zz[j] = G[j];

		IntVar tt(*this, 0, k);
		tt = expr(*this, max(zz) + 1);		

		rel(*this, G[i], IRT_LQ, tt);
	}
	
*/



    // G[i] <= i
//    for (int i = 0; i < n; i++)
 //     rel(*this, G[i], IRT_LQ, i);

    // I[c] < I[c'] with c < c'
//    rel(*this, I, IRT_LE);

	// CONSTRAINT On Same POINT  
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++)
			if (dcarre[i][j] == 0)  {
				rel(*this, G[i], IRT_EQ, G[j]);		    
//				cout << "Same point on " << i << " " << j << endl;
			}

// ----------------------------END POST BASIC CONSTRAINT----------------------------------
    

	

// _______________________________POST MUST-LINK CANNOT-LINK CONSTRAINTS_______________________________________________
	generateMLCL(opt.ml(), opt.cl(), n, realClass); // generate must-link and cannot-link pair to matrix mlcl[i][j]. mlcl[i][j] = 0 if cannot link, =1 if mustlink, =2 otherwise
/*	if (opt.ml() + opt.cl() > 0) {
		for (int i = 0; i < n; i++)
			for (int j = i+1; j < n; j++) {
				if (mlcl[i][j] == 1) { // must-link
					rel(*this, G[i], IRT_EQ, G[j]);
				}
				if (mlcl[i][j] == 0) { // cannot-link
					rel(*this, G[i], IRT_NQ, G[j]);
				}				
			}	
	}
*/
	if (opt.ml() + opt.cl() > 0) {
		for (int i = 0; i < n; i++)
			for (int j = i+1; j < n; j++) {
				if (mlcl[i][j] == 1) { // must-link
					rel(*this, G[i], IRT_EQ, G[j]);
					if (opt.obj() == 1)  // if we want Max Diameter
						rel(*this, DS, FRT_GQ, dd[i][j]);
				}
				if (mlcl[i][j] == 0) { // cannot-link
					rel(*this, G[i], IRT_NQ, G[j]);
					if (opt.obj() == 2)  // if we want min separation 
						rel(*this, DS, FRT_LQ, dd[i][j]);
				}				
			}	
	}

//----------------------------------END POST MUST-LINK CANNOT-LINK CONSTRAINTS----------------------------------


//___________________________________CONTRAINT OF DIAMTER with UPPER BOUND is GIVEN by FPF: this is the CASE when there is NO USER-CONSTRAINT

		if (opt.dfpf() == 1) {
				// DIAMETER FPF,   d[i, j] > diameter_Fpf => i, j in different groups
				rel(*this, DS, FRT_LQ, diamHeuristic);

				cout << "DFPF = " << diamHeuristic << endl;
				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) {			
							if (dd[i][j] > 	diamHeuristicKmin) 
								rel(*this, G[i], IRT_NQ, G[j]);
				  }
		}
//----------------------------------END CONTRAINT OF DIAMTER with UPPER BOUND is GIVEN by FPF: this is the CASE when there is NO USER-CONSTRAINT


//___________________________________CONTRAINT OF DIAMTER given BY USER_______________________________________________________

		if (opt.diam() > 0) {
				// DIAMETER FPF,   d[i, j] > diameter_Fpf => i, j in different groups
				rel(*this, DS, FRT_LQ, opt.diam());

				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) {			
							if (dd[i][j] > 	opt.diam()) 
								rel(*this, G[i], IRT_NQ, G[j]);
				  }
		}
//----------------------------------END CONTRAINT OF DIAMTER given BY USER----------------------------------

//___________________________________CONSTRAINT of SEPARATION _____________________________________________________
    if (opt.s() > 0) {
		rel(*this, DS, FRT_GQ, opt.s());
		for (int i = 0; i < n; i++)
			for (int  j = i+1; j < n; j++)
			  if (dd[i][j] < opt.s()) 
			  	rel(*this, G[i], IRT_EQ, G[j]);
	}
//----------------------------------END CONSTRAINT of SEPARATION----------------------------------



//___________________________________COUNTING CONSTRAINT: SIZE OF EACH GROUP_______________________________________________________
/*	if (opt.sizeMin())
		for (int c = 0;c < k; c++) 
			count(*this, G, I[c], IRT_GQ, opt.sizeMin());

	if (opt.sizeMax())
		for (int c = 0;c < k; c++) 
			count(*this, G, I[c], IRT_LQ, opt.sizeMax());
//----------------------------------END COUNTING CONSTRAINT: SIZE OF EACH GROUP----------------------------------
*/

//___________________________________ CONSTRAINT OF DENSITY: Epsilon + Minpoint____________________________________
		if (opt.epsilon() * opt.minpoint() > 0) {
			for (int i = 0; i < n; i++) { // we need to check point 0
				int npoint = 0; 
				for (int j = 0; j < n; j++)
					if (dd[i][j] <= opt.epsilon()) 
						if (i != j) 
							npoint++; 		// number of point near point i;
				if (npoint >= 0) {
						IntVarArgs nearPoint(npoint);
						npoint = 0;
						for (int j = 0; j < n; j++)
							if (dd[i][j] <= opt.epsilon()) 
								if (i != j) 
									nearPoint[npoint++] = G[j];
			      count(*this, nearPoint, G[i], IRT_GQ, opt.minpoint()); // there are at least minpoint near G[i] at distance epsilon
				}
			}
		}
//----------------------------------END: CONSTRAINT OF DENSITY----------------------------------


//______________________________________________________________________________________________________________________________//
//								POSTING CONSTRAINT ON OBJECTIVE FUNCTION : DIAMETER, SEPARATION, VARIANCE						//
//______________________________________________________________________________________________________________________________//

//_________________________________ objective function = 1: Minimise Maximum Diameter_________________________________
		if (opt.obj() == 1) {
				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) 			
						if (dd[i][j] >= diamHeuristic/2) 
							if (mlcl[i][j] == 2) {			// we do this only when there is no must-link or cannot-link constraint								
								BoolVar b(*this, 0, 1);
								rel(*this, DS, FRT_GQ, dd[i][j], b); // b = (Diameter >= dd(i, j)
								BoolVar same(*this, 0, 1);

								rel(*this, G[i], IRT_EQ, G[j], same);  // same = (G[i] = G[j])	
								rel(*this, same, IRT_LQ, b);			// same <= b
							}
			rel(*this, DS, FRT_GQ, diamHeuristic/2);
		}
//----------------------------------END objective function = 1: Minimise Maximum Diameter----------------------------------


//_________________________________ objective function = 2: Maximise Min Separation_________________________________
		if (opt.obj() == 2) {
				// SEPARATION

		findAllSeparateur();
		rel(*this, DS, FRT_LQ, allSeparation[n-2]);
//cout << allSeparation[n-2] << endl;


				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) 
					if (dd[i][j] <= allSeparation[n-2])			
					if (mlcl[i][j] == 2) {			// we do this only when there is no must-link or cannot-link constraint								

						
						BoolVar b(*this, 0, 1);
						BoolVar same(*this, 0, 1);
	
						rel(*this, DS, FRT_GQ, dd[i][j], b); 
						rel(*this, G[i], IRT_EQ, G[j], same);
						rel(*this, b, IRT_LQ, same);			
				  }
		}
//----------------------------------END objective function = 2: Maximise Miln Separation----------------------------------


//_________________________________ objective function = 3: Min Variance_________________________________
	
	// UPPER BOUND of VARIANCE from PREVIOUS RESULTs
	if (opt.obj() == 3) {

		sortD(n); // sort distance for variance constraint
		varianceConstraint(*this, G, variance);

	}
//----------------------------------END  objective function = 3: Min Variance----------------------------------


	if (opt.obj() == 4) {
		sortD(n); // sort distance for variance constraint
		kMeansConstraint(*this, G, variance);

	}

//    cout << "Posting Constraints in \t:  " << give_time() - startAll << endl;
    startAll = give_time();
//    cout << "__________________________________________________________" << endl;


	//IGConstraint(*this, I, G);


//______________________________________________________________________________________________________________________________//
//								BRANCHING ON I, G																				//
//______________________________________________________________________________________________________________________________//



//Symmetries syms; syms << ValueSymmetry(IntArgs::create(k,0));
//branch(*this, G, INT_VAR_SIZE_MIN(), INT_VAL_MIN(), syms);

//branch(*this, G, INT_VAR_SIZE_MAX(), INT_VAL_MIN(), syms);


	rel(*this, G[0], IRT_EQ, 0);  

	symmetryConstraint(*this, G);


//   branch(*this, G, INT_VAR_NONE(), INT_VAL_MIN()); 
//   branch(*this, G, INT_VAR_SIZE_MIN(), INT_VAL_MIN(), syms); 


	if (opt.obj() == 1)  // min Diameter max
	    branchDiameter::post(*this, G);

	if (opt.obj() == 2)  // max Separation min
	    branchDiameter::post(*this, G);
//	    branchSeparation::post(*this, G);

	if (opt.obj() == 3)  // min Variance
	//	branchVarianceDivision::post(*this, G);
//		branchVariance::post(*this, G);
//	    branchDiameter::post(*this, G);
		branchMix::post(*this, G); 


	if (opt.obj() == 4) // kmeans 
		branchKmeans::post(*this, G);

  }


  Cluster(bool share, Cluster& s) : Script(share, s), options(s.options) {
    G.update(*this, share, s.G);
 //   I.update(*this, share, s.I);
	variance.update(*this, share, s.variance);
	DS.update(*this, share, s.DS);

  }

  virtual Space* copy(bool share) {
    return new Cluster(share,*this);
  }


// BRANCH AND BOUND: Next solution must be better than the previous
  virtual void constrain(const Space& sol) { 


    const Cluster& _sol=static_cast<const Cluster&>(sol);

		if (objectiveFunction == 1) 
			rel(*this, DS < _sol.DS.min());

		if (objectiveFunction == 2) 
			rel(*this, DS > _sol.DS.max());
		
		if (objectiveFunction == 3) {
			rel(*this, variance < _sol.variance.min());

		}
		if (objectiveFunction == 4) {
			rel(*this, variance < _sol.variance.min());

		}

  }


// Print solution

  virtual void print(ostream& os) const {

	os << "___________________________________________________________________________\n";
	os << G << endl;
	int n = nSmall;


	int checkAllG = 0;
	while ((checkAllG < n) && G[checkAllG].assigned()) checkAllG++;   // check if we have a solution or still in the search

	// PRINT Rand Index, Size of Group,..
	if (checkAllG == n) { // It means we have a real solution, all variables are fixed
		int GR[nBig];	
		for (int i = 0; i < nBig; i++)
			GR[i] = -1;
		for (int i = 0; i < nSmall; i++) {
		  GR[order[i]] = G[i].val();
		  finalClass[i] = G[i].val();
		}	
//		for (int i = 0; i < nSmall; i++)
//			finalClass[i] = GR[i];
		ofstream fOut("class.txt",ios::out);	// read file
		for (int i = 0; i < G.size(); i++)
		  fOut << GR[i] << endl;		
//		  fOut << order[i] << endl;		
	
		fOut.close();
		numberK = 0;
		// Calcul size of each group
		os << "Size of groups: ";
		for (int c = 0; c < nClass; c++) {
		  int sum = 0;
			for (int i = 0; i < G.size(); i++)
				if (G[i].val() == c)
				  sum++;
		  os << sum << " ";
		  if (sum > 0) numberK++;
		}


		diam = 0;
		sepa = 1000000000;

		for (int i = 0; i < n; i++)
			for (int j = i+1; j < n; j++) 
				if (G[i].val() == G[j].val()) {
					if (dd[i][j] > diam)
						diam = dd[i][j];
				}
				else {
					if (dd[i][j] < sepa)
						sepa = dd[i][j];
				}

		os << endl;
		cout << "Diam = " << diam << " ,Sepa = " << sepa << endl;
//		cout << DS.min() << " " << DS.max() << endl;
	}




	bestResult = DS.min();
	if (objectiveFunction == 3)
	    os << "Variance: " << variance.min() << " " << variance.max() << endl;
	if (objectiveFunction == 4)
	    os << "Variance: " << variance.min() << " " << variance.max() << endl;

//    cout << "This solution is found AFTER: " << give_time() - startAll << endl;
			finalVariance = variance.min();

	timebestSol = give_time() - startAll;

//	buildFinalOrder(n);

  }
};


int main(int argc, char* argv[]) {
	double start2 = give_time();
	ClusterOptions opt;
	opt.solutions(0);
	opt.parse(argc,argv);
	opt.c_d(50); 
	opt.a_d(50);  // No recomputation, we save all nodes' information


	n = opt.n();

	opt.time(3600000); 

	Script::run<Cluster,BAB,ClusterOptions>(opt);

//	cout << "SEARCHING TIME : " << give_time() - startAll << endl;
//	cout << "TOTAL TIME : " << give_time() - start2 << endl;
	cout <<  opt.f()  << " " <<  opt.n() << " " <<  opt.k() << " " <<  diam << " " << sepa << " " << give_time() - start2 <<  " " << numberK << endl;

  // print final solution to txt file
	ofstream fOut("newModel.txt",ios::app);	// read file
//	fOut << nSmall << " " << finalVariance << " " ;
//	fOut << nSmall << " " << timebestSol << " " << give_time() - start2 << " " << finalVariance << endl;
//	for (int i = 0; i < nSmall; i++) 
//		fOut << finalClass[i] << " ";


//	cout << "total propagation " <<  countPropagation << endl;
//cout << counter1 << endl;
//cout << counter2 << endl;


//	fOut << nSmall << " " << finalVariance << " " ;
//	fOut << nSmall << " " << timebestSol << " " << give_time() - start2 << " " << finalVariance << endl;
	fOut <<  opt.f()  << " " <<  opt.n() << " " <<  opt.k() << " " <<  diam << " " << sepa << " " <<  give_time() - start2 <<  " " << numberK << endl;

	fOut.close();

	ofstream fOut3("AMAT.DAT",ios::out);	// read file
	fOut3 << nSmall << endl;
	for (int i = 0; i < nSmall; i++) {
		for (int j = 0; j < nSmall; j++)
			fOut3 << dcarre[i][j] << " ";
		fOut3 << endl;
	}


	return 0;
}

