#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class diameterConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x;
		Float::FloatView y;

	public:
		// posting
		diameterConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0), y(y0)  {
			x.subscribe(home,*this,Int::PC_INT_VAL);	// maybe when y change too
		}
		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0, Float::FloatView y0) {
			(void) new (home) diameterConstraint(home,x0,y0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			x.cancel(home,*this,Int::PC_INT_VAL);

			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		diameterConstraint(Space& home, bool share, diameterConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) diameterConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}
		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
			



				  return ES_OK;
		}
};

	void diameterConstraint(Home home, IntVarArgs x, FloatVar y) {
		// constraint post function
    ViewArray<Int::IntView> vx(home, x);
    Float::FloatView vy(y);
		if (diameterConstraint::post(home, vx, vy) != ES_OK)
			home.fail();
	}

