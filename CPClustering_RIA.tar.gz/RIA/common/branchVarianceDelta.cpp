#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;




class branchVariance : public Brancher {
protected:
  /// Views of the brancher
  ViewArray<Int::IntView> x; // I
  /// Next variable to branch on
  mutable int start;
  /// %Choice
  class Choice : public Gecode::Choice {
  public:
    /// Position of variable
    int pos;
    /// Value of variable
    int val;
    /** Initialize choice for brancher \a b, position \a pos0, 
     *  and value \a val0.
     */
    Choice(const Brancher& b, int pos0, int val0)
      : Gecode::Choice(b,2), pos(pos0), val(val0) {}
    /// Report size occupied
    virtual size_t size(void) const {
      return sizeof(Choice);
    }
    /// Archive into \a e
    virtual void archive(Archive& e) const {
      Gecode::Choice::archive(e);
      e << pos << val;
    }
  };
 
  /// Construct brancher
  branchVariance(Home home, ViewArray<Int::IntView>& xv) 
    : Brancher(home), x(xv), start(0) {}
  /// Copy constructor
  branchVariance(Space& home, bool share, branchVariance& b) 
    : Brancher(home, share, b), start(b.start) {
    x.update(home, share, b.x);
  }
public:
  /// Check status of brancher, return true if alternatives left
  virtual bool status(const Space&) const {
    for (int i=start; i<x.size(); i++)
      if (!x[i].assigned()) {
        start = i; return true;
      }
    return false;
  }

  /// Return choice
  virtual Gecode::Choice* choice(Space&) {
    int n = x.size(); // there is n point
		int minSize = 1000;
		int i = 0;  
    for (int j = start; j < n; j++)  	// search all point that are not assigned (not instantiated)
      if ((!x[j].assigned()) && (minSize > x[j].size())) {   // choice the first point that has Min Size of Domain
				minSize = x[j].size();
				i = j;
      }
					int pos = i; int val = 0;

					for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
						checkI[j] = 0;

					for (int j = 0; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
							if (x[j].assigned())
									checkI[x[j].val()] = 1;

			
					// calcul VariancePartiel from a point non assigned to a representative
					for (int j = 0; j < n; j++)
						if (checkI[j])
							for (int i = 0; i < n; i++)
								if (x[i].size() == minSize)
								VariancePartiel[i][j] = 0;	
					
							VariancePartiel[i][n] = Float::Limits::max;

 
					for (int j  = 0 ; j < n; j++)
						if (checkI[j])
							if (x[j].assigned())
								for (int i = 0; i < n; i++)
		 							if (x[i].size() == minSize)
										if (x[i].in(x[j].val())) 
											VariancePartiel[i][x[j].val()] += dcarre[i][j];
	
					
					// choice x[i] that has best Delta;
					double minV[n], maxV[n];
					for (int i = 0; i < n; i++) {
						minV[i] = 100000;
						maxV[i] = 0;
					}

					for (int j = 0; j < n; j++)
						if (checkI[j])
							for (int i = 0; i < n; i++)
								if (x[i].size() == minSize) 
									if (x[i].in(x[j].val())) {	
										if (minV[i] > VariancePartiel[i][j])
											minV[i] = VariancePartiel[i][j];
										if (maxV[i] < VariancePartiel[i][j])
											maxV[i] = VariancePartiel[i][j];
									}
								
					double minVariancePartiel = Float::Limits::max;

					// now I select i that has best delta

					double delta = 100000;
					
					for (int i = 0; i < n; i++) 
					if (x[i].size() == minSize) 
						if (delta > (maxV[i] - minV[i])) {
							delta = maxV[i] - minV[i];
							pos = i;
						}

					for (int j = 0; j < n; j++)
						if (checkI[j])	// j is representative
							if ((VariancePartiel[pos][j] > 0) &&	(VariancePartiel[pos][j] < minVariancePartiel)) {
									minVariancePartiel = VariancePartiel[pos][j];
									val = j;
							}


					// check the min of all VariancePartiel
/*					for (int j = 0; j < n; j++)
						if (checkI[j])	// j is representative
							for (int i = 0; i < n; i++)
								if (x[i].size() == minSize)
									if ((VariancePartiel[i][j] > 0) &&	(VariancePartiel[i][j] < minVariancePartiel)) {
											minVariancePartiel = VariancePartiel[i][j];
											val = j;
											pos = i;
									}
*/


    return new Choice(*this,pos,val);
  }

  /// Return choice
  virtual Choice* choice(const Space&, Archive& e) {
    int pos, val;
    e >> pos >> val;
    return new Choice(*this, pos, val);
  }
  /// Perform commit for choice \a _c and alternative \a a
  virtual ExecStatus commit(Space& home, const Gecode::Choice& _c, unsigned int a) {
    const Choice& c = static_cast<const Choice&>(_c);
    if (a == 0)
      return me_failed(x[c.pos].eq(home, c.val)) ? ES_FAILED : ES_OK;
    else 
      return me_failed(x[c.pos].nq(home, c.val)) ? ES_FAILED : ES_OK;
  }
  /// Copy brancher
  virtual Actor* copy(Space& home, bool share) {
    return new (home) branchVariance(home, share, *this);
  }
  /// Post brancher
  static void post(Home home, const IntVarArgs& x) {
    ViewArray<Int::IntView> xv(home, x);
    (void) new (home) branchVariance(home, xv);
  }
  /// Delete brancher and return its size
  virtual size_t dispose(Space&) {
    return sizeof(*this);
  }
};



