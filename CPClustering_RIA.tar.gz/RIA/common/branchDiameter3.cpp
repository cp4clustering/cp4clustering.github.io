#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;





class branchDiameter : public Brancher {
protected:
  /// Views of the brancher
  ViewArray<Int::IntView> x; // I
  /// Next variable to branch on
  mutable int start;
  /// %Choice
  class Choice : public Gecode::Choice {
  public:
    /// Position of variable
    int pos;
    /// Value of variable
    int val;
    /** Initialize choice for brancher \a b, position \a pos0, 
     *  and value \a val0.
     */
    Choice(const Brancher& b, int pos0, int val0)
      : Gecode::Choice(b,2), pos(pos0), val(val0) {}
    /// Report size occupied
    virtual size_t size(void) const {
      return sizeof(Choice);
    }
    /// Archive into \a e
    virtual void archive(Archive& e) const {
      Gecode::Choice::archive(e);
      e << pos << val;
    }
  };
 
  /// Construct brancher
  branchDiameter(Home home, ViewArray<Int::IntView>& xv) 
    : Brancher(home), x(xv), start(0) {}
  /// Copy constructor
  branchDiameter(Space& home, bool share, branchDiameter& b) 
    : Brancher(home, share, b), start(b.start) {
    x.update(home, share, b.x);
  }
public:
  /// Check status of brancher, return true if alternatives left
  virtual bool status(const Space&) const {
    for (int i=start; i<x.size(); i++)
      if (!x[i].assigned()) {
        start = i; return true;
      }
    return false;
  }

  /// Return choice
  virtual Gecode::Choice* choice(Space&) {
    int n = x.size(); // there is n point
    unsigned int minSize = 100000, i = 0;
    
    for (int j = start; j < n; j++)  	// search all point that are not assigned (not instantiated)
      if ((!x[j].assigned()) && (minSize > x[j].size())) {   // choice the first point that has Min Size of Domain
				minSize = x[j].size();
				i = j;
      }

	// I will choice point that increase max variance
	for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
			checkI[j] = 0;

	for (int j = 0; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
		if (x[j].assigned())
				checkI[x[j].val()] = 1;

			
					// calcul VariancePartiel from a point non assigned to a representative

	for (int j = 0; j < n; j++)
		if (checkI[j])
				for (int i = 0; i < n; i++)
					if (x[i].size() == minSize)
						VariancePartiel[i][j] = 0;	

	for (int i = 0; i < n; i++)			
		VariancePartiel[i][n] = Float::Limits::max;


	for (int j  = 0 ; j < n; j++)
		if (x[j].assigned())
			for (int i = 0; i < n; i++)
				if (x[i].size() == minSize)
					if (x[i].in(x[j].val())) 
						VariancePartiel[i][x[j].val()] += dcarre[i][j];
	
	for (int j = 0; j < n; j++) 
		sClass[j] = 0;
	

	for (int j = 0; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
			if (x[j].assigned()) 
				sClass[x[j].val()]++;

	// check the min of all VariancePartiel
	int val[n];
	int pos;


	// i will choice i that have DELTA min



	for (int j = 0; j < n; j++)
		if (checkI[j])
			for (int i = 0; i < n; i++)
				if (x[i].size() == minSize)
					VariancePartiel[i][j] = VariancePartiel[i][j] / sClass[j];		


	for (int i = 0; i < n; i++)
		if (x[i].size() == minSize)	{
			double minV = Float::Limits::max;			
			int posZ = 0;
			for  (Int::ViewValues<Int::IntView> z(x[i]); z(); ++z) 
				if (minV > VariancePartiel[i][z.val()]) {	
					minV = VariancePartiel[i][z.val()];
					posZ = z.val();
				}
			val[i] = posZ;

			double minD = Float::Limits::max;			
			
			for  (Int::ViewValues<Int::IntView> z(x[i]); z(); ++z)
				if (z.val() != posZ) 
					if (minD > ((VariancePartiel[i][z.val()]) / (VariancePartiel[i][posZ]))  ) {
						minD = ((VariancePartiel[i][z.val()]) / (VariancePartiel[i][posZ]));
					}
			VariancePartiel[i][n] = minD;
//			if (i == 15) cout << minD << " " << VariancePartiel[i][n] << endl;
		}
    

	double minDelta = Float::Limits::max;

								
	for (int i = 0; i < n; i++)
		if (x[i].size() == minSize)
			if (VariancePartiel[i][n] < minDelta) {
				pos = i;
				minDelta = VariancePartiel[i][n];
//				cout << VariancePartiel[i][n] << " ";
			}								

//	cout << pos << " " << VariancePartiel[pos][n] << endl;
int pos2 = pos;

//for  (Int::ViewValues<Int::IntView> z(x[pos]); z(); ++z) 
	//cout << VariancePartiel[pos][z.val()] << " |";

//cout << pos << " " << val[pos] << " " ;
//if (VariancePartiel[pos][n] < 1.1)
//cout << VariancePartiel[pos][n] << endl;
if (VariancePartiel[pos][n] > 1.05)
{
	double maxVariance = 0;
	for (int j = 0; j < n; j++)
		if (checkI[j])	// j is representative
			for (int i = 0; i < n; i++)
				if (x[i].size() == minSize)
					if ((VariancePartiel[i][j] > 0) &&	((VariancePartiel[i][j]) < VariancePartiel[i][n])) {
							VariancePartiel[i][n] = VariancePartiel[i][j];
							val[i] = j;							
					}


	for (int i = 0; i < n; i++) 
		if (x[i].size() == minSize)
				if (VariancePartiel[i][n] > maxVariance) {
								pos = i;
								maxVariance = VariancePartiel[i][n];
				}
}

//cout << VariancePartiel[pos2][n] << "___________" << pos << " " << val[pos] << " " << VariancePartiel[pos][n]  << endl;
    return new Choice(*this,pos, val[pos]);
  }

  /// Return choice
  virtual Choice* choice(const Space&, Archive& e) {
    int pos, val;
    e >> pos >> val;
    return new Choice(*this, pos, val);
  }
  /// Perform commit for choice \a _c and alternative \a a
  virtual ExecStatus commit(Space& home, const Gecode::Choice& _c, unsigned int a) {
    const Choice& c = static_cast<const Choice&>(_c);
    if (a == 0)
      return me_failed(x[c.pos].eq(home, c.val)) ? ES_FAILED : ES_OK;
    else 
      return me_failed(x[c.pos].nq(home, c.val)) ? ES_FAILED : ES_OK;
  }
  /// Copy brancher
  virtual Actor* copy(Space& home, bool share) {
    return new (home) branchDiameter(home, share, *this);
  }
  /// Post brancher
  static void post(Home home, const IntVarArgs& x) {
    ViewArray<Int::IntView> xv(home, x);
    (void) new (home) branchDiameter(home, xv);
  }
  /// Delete brancher and return its size
  virtual size_t dispose(Space&) {
    return sizeof(*this);
  }
};
