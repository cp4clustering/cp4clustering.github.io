#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class kMeansConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x;
		Float::FloatView y;

	public:
		// posting
		kMeansConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0), y(y0)  {
			x.subscribe(home,*this,Int::PC_INT_VAL);
		}
		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0, Float::FloatView y0) {
			(void) new (home) kMeansConstraint(home,x0,y0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			x.cancel(home,*this,Int::PC_INT_VAL);

			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		kMeansConstraint(Space& home, bool share, kMeansConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) kMeansConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}
		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
countPropagation++;
					int n = x.size();
					int k = nClass;
					double myV = 0;

					int nAssign=0;
					for (int i = 0; i < n; i++)
						if (x[i].assigned())
							nAssign++;


					for (int j = 0; j < k; j++) // check if class is assigned
						checkI[j] = 0;

					for (int j = 0; j < n; j++) 
							if (x[j].assigned())
									checkI[x[j].val()] = 1;					

						
					// build positionG

					int ngroup = 0;
					for (int j = 0; j < k; j++) 
						if (checkI[j])	
							ngroup++;
						

//					if (ngroup < nClass)
//						return ES_OK;
				
					

			
		
					
					double borne_min = 0;
					
					double V1 = 0; double V3 = 0;
					int sizeGroup[k];	
					for (int i = 0; i < k; i++)
						sizeGroup[i] = 0;


					double varianceGroup[k];
					for (int i = 0; i < k; i++)
						varianceGroup[i] = 0;

					for (int i  = 0; i < n; i++)
						if (x[i].assigned()) {
							sizeGroup[x[i].val()] ++;		
							for (int j = i + 1; j < n; j++)
								if (x[j].assigned())
									if (x[i].val() == x[j].val()) {
										varianceGroup[x[i].val()] += dcarre[i][j];
									} 
						}


			// calcul min Delta of each points
					for (int j = 0; j < k; j++)
						if (checkI[j])		// class j has at least 1 point
							for (int  i = 0; i < n; i++)
								if (!x[i].assigned()) 
								if (x[i].in(j))
								{
									double delta = ( varianceGroup[ j ] + VariancePartiel[i][j] ) / (sizeGroup[ j ] +1);

										delta = delta -  (varianceGroup[ j ] / sizeGroup[ j ]);
								
									if  ( delta < VariancePartiel[i][n])
											VariancePartiel[i][n] = delta;
								}


					for (int i = 0; i < k; i++) // calculation of V1
						if (sizeGroup[i] > 0)	
							V1 += varianceGroup[i] / sizeGroup[i];


					

					borne_min = V1;


					// now V3  with funtion f(p, k);   with  p > k.  if p < = k V3 = 0
					int p  = n - nAssign;



					for (int j = 0; j < k; j++)
						if (checkI[j])
							for (int i = 0; i < n; i++)
								VariancePartiel[i][j] = 0;	
				
					
					for (int i = 0; i < n; i++)	
							VariancePartiel[i][n] = Float::Limits::max;

 
					for (int i = 0; i < n; i++)
						if (!x[i].assigned())
							for (int j  = 0 ; j < n; j++)
								if (x[j].assigned())
										if (x[i].in(x[j].val())) {
											VariancePartiel[i][x[j].val()] += dcarre[i][j];
										}

	


			double f[p+1][k+1];
			int g[p+1][k+1];
			f[p][k] = 0;

			for (int i = 0; i < p; i++)
				for (int j = 0; j < k; j++)
					f[i][j] = 0;

			if (p > k) {
					
//						double dNonFix[(p-k+1)*(p-k)/2]; // all the distance of non-fixed point
						double dNonFix[(p)*(p-1)/2]; // all the distance of non-fixed point
	
						int count = 0;
						for (int i = 0; i < (n * (n-1)/2); i++)  {
//							if (count >= (p-k+1)*(p-k)/2) break;
							if (count >= (p)*(p-1)/2) break;
	
							if ((!x[ pX[i] ].assigned()) && (!x[ pY[i] ].assigned())) {						
								dNonFix[count] = dSort[i];
								count++;
							}
						}




						for (int i = 0; i <= p; i++)
							for (int j = 0; j <= k; j++) {
								f[i][j] = 0;
								g[i][j] = 0;
							}


//					for (int i = 1; i <= p-k+1; i++)  {
					for (int i = 1; i <= p; i++)  {

						g[i][1] = i * (i-1) / 2;	
						f[i][1] = 0;
						for (int j = 0; j < g[i][1]; j++)
							f[i][1] += dNonFix[j];
						f[i][1] = f[i][1] / i;
					}


					for (int c = 2; c <= k; c++)
							for (int i = c+1; i <= p-k+c; i++) {
								f[i][c]  =  f[i - 1][ c-1];		
															
								for (int j = 2; j < i; j++) {
									double	temp = f[j][1] + f[i - j][ c-1];			
									if (temp < f[i][c]) {
					
										f[i][c] = temp;
										g[i][c] = g[i - j][c - 1] + j * (j-1)/2;
									}

								}

							}



		}

						// filtrage
		

	


						for (int i = 0; i < n; i++) 
							if ((!x[i].assigned())	)	{		
							
								double delta = f[p-1][k];

		
								int zz[x[i].size()];
								int zcount = 0;

								for  (Int::ViewValues<Int::IntView> z(x[i]); z(); ++z)  // back up value of variable x[i]
										zz[zcount++] = z.val();
											
							  	for (int t = 0; t < zcount; t++)
								if (sizeGroup[ zz[t] ] > 0)							

								 {
									double temp = ( varianceGroup[ zz[t] ] + VariancePartiel[i][zz[t]] ) / (sizeGroup[ zz[t] ] +1);

							temp = temp - (varianceGroup[ zz[t] ] / sizeGroup[ zz[t] ]) ;	

									if ((borne_min + temp + f[p-1][k]) >= y.max()) 		
											GECODE_ME_CHECK(x[i].nq(home, zz[t])); 
										
								}	
							}		

			borne_min += f[p][k];	

			GECODE_ME_CHECK(y.gq(home, borne_min));
			return ES_OK;
		}
	};

	void kMeansConstraint(Home home, IntVarArgs x, FloatVar y) {
		// constraint post function
    ViewArray<Int::IntView> vx(home, x);
    Float::FloatView vy(y);
		if (kMeansConstraint::post(home, vx, vy) != ES_OK)
			home.fail();
	}

