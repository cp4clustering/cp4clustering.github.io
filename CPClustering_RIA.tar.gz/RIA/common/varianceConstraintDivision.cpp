#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 

using namespace Gecode;
using namespace std;


class varianceConstraintDivision : public Propagator {
protected:
	ViewArray<Int::IntView> x;
	Float::FloatView y;

public:
	// posting
	varianceConstraintDivision(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0) 
		: Propagator(home), x(x0), y(y0)  {
//				y.subscribe(home,*this,Int::PC_INT_DOM);
		x.subscribe(home,*this,Int::PC_INT_DOM);
	}
	static ExecStatus post(Home home, 
		                     ViewArray<Int::IntView>& x0, Float::FloatView y0) {
		(void) new (home) varianceConstraintDivision(home,x0,y0);
		return ES_OK;
	}
	// disposal
	virtual size_t dispose(Home home) {
//				y.cancel(home,*this,Int::PC_INT_DOM);
		x.cancel(home,*this,Int::PC_INT_DOM);

		(void) Propagator::dispose(home);
		return sizeof(*this);
	}
	// copying
	varianceConstraintDivision(Space& home, bool share, varianceConstraintDivision& p) 
		: Propagator(home,share,p) {
			x.update(home, share, p.x);
			y.update(home, share, p.y);
	}
	virtual Propagator* copy(Space& home, bool share) {
		return new (home) varianceConstraintDivision(home,share,*this);
	}
	// cost computation
	virtual PropCost cost(const Space&, const ModEventDelta&) const {
		return PropCost::binary(PropCost::HI);
	}
	// propagation
	virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
			int n = x.size();
			double borne_min = 0;

			int firstNonAssigned = 0;
			while ((firstNonAssigned < (nSmall - nClass)) && (x[firstNonAssigned].assigned())) firstNonAssigned++;

			// we have assigned from G[0] to G[firstNonAssigned], we need only nSmall - firstNonAssigned - 1 point left.
			if ((nSmall - 	firstNonAssigned - 1) > nClass) {
				borne_min = bestV[nSmall - 	firstNonAssigned - 1];
//						if (borne_min > 0)
//							cout << (nSmall - 	firstNonAssigned - 1) << " " <<borne_min << endl;
			}


			for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
				checkI[j] = 0;

			for (int i = 0; i < n; i++) {
				VarianceClass[i] = 0;	
				sClass[i] = 0;
			}

			for (int j = 0; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
					if (x[j].assigned()) {
						sClass[x[j].val()]++;
						checkI[x[j].val()] = 1;					
					}
				
			// build positionG
			int ngroup = 1;
			for (int j = 1; j < n; j++) 
				if (checkI[j])	{
					positionG[j] = ngroup;
					ngroup++;
				}

			if (ngroup < nClass)
				return ES_OK;
	
			for (int i = 0; i < n; i++)
				if (x[i].assigned())
					for (int j = i + 1; j < n; j++)
						if (x[j].assigned())
							if (x[i].val() == x[j].val())
								VarianceClass[x[i].val()] += dcarre[i][j];					
	
			for (int i = 0; i < n; i++)
				if (checkI[i])	
					borne_min += VarianceClass[i]/sClass[i];
			
			
		  if (borne_min > y.max()) return ES_FAILED;

  		  GECODE_ME_CHECK(y.gq(home, borne_min));   // there will be error if I do that			

		  return ES_OK;
	}
};

		void varianceConstraintDivision(Home home, IntVarArgs x, FloatVar y) {
			// constraint post function
	    ViewArray<Int::IntView> vx(home, x);
	    Float::FloatView vy(y);
			if (varianceConstraintDivision::post(home, vx, vy) != ES_OK)
				home.fail();
		}


