#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class symmetryConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x;


	public:
		// posting
		symmetryConstraint(Home home, ViewArray<Int::IntView>& x0) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0)  {
			x.subscribe(home,*this,Int::PC_INT_VAL);
		}
		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0) {
			(void) new (home) symmetryConstraint(home,x0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			x.cancel(home,*this,Int::PC_INT_VAL);

			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		symmetryConstraint(Space& home, bool share, symmetryConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);

		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) symmetryConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}
		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
countPropagation++;
					int n = x.size();
					int k = nClass;


					int maxK  = 0;	// max Class that assigend, maxK = 0 .. k-1
					for (int i = 1; i < n; i++) {
						if (x[i].assigned())
							maxK = max(maxK, x[i].val());
						else {	// filter x[i]
							for (int j = maxK+2; j < k; j++)
								if (x[i].in(j))
									GECODE_ME_CHECK(x[i].nq(home, j));
							if (x[i].in(maxK+1))
								maxK++;
						}

						if (maxK >= k-2)
						  return ES_OK;

					}


					

				  return ES_OK;
		}
};

	void symmetryConstraint(Home home, IntVarArgs x) {
		// constraint post function
    ViewArray<Int::IntView> vx(home, x);

		if (symmetryConstraint::post(home, vx) != ES_OK)
			home.fail();
	}

