#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class varianceConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x;
		Float::FloatView y;

	public:
		// posting
		varianceConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0), y(y0)  {
			x.subscribe(home,*this,Int::PC_INT_VAL);
		}
		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0, Float::FloatView y0) {
			(void) new (home) varianceConstraint(home,x0,y0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			x.cancel(home,*this,Int::PC_INT_VAL);

			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		varianceConstraint(Space& home, bool share, varianceConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) varianceConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}
		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
countPropagation++;
					int n = x.size();

					int nAssign=0;
					for (int i = 0; i < n; i++)
						if (x[i].assigned())
							nAssign++;


					for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
						checkI[j] = 0;

					for (int j = 0; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
							if (x[j].assigned())
									checkI[x[j].val()] = 1;					
						
					// build positionG

					int ngroup = 1;
					for (int j = 1; j < n; j++) 
						if (checkI[j])	{
							positionG[j] = ngroup;
							ngroup++;
						}

					if (ngroup < nClass)
						return ES_OK;
				
					

					// calcul VariancePartiel from a point non assigned to a representative
					for (int j = 0; j < n; j++)
						if (checkI[j])
							for (int i = 0; i < n; i++)		{			// need better 
								VariancePartiel[i][j] = 0;	
							}											
					
					for (int i = 0; i < n; i++)	
							VariancePartiel[i][n] = Float::Limits::max;

 
					for (int i = 0; i < n; i++)
						if (!x[i].assigned())
							for (int j  = 0 ; j < n; j++)
								if (x[j].assigned())
										if (x[i].in(x[j].val())) {
											VariancePartiel[i][x[j].val()] += dcarre[i][j];
										}

					// check the min of each VariancePartiel
					for (int j = 0; j < n; j++)
						if (checkI[j])	// j is representative
							for (int  i = 0; i < n; i++)
								if (!x[i].assigned())
									if ((VariancePartiel[i][j] > 0) &&	(VariancePartiel[i][j] < VariancePartiel[i][n]))
											VariancePartiel[i][n] = VariancePartiel[i][j];
					
					double borne_min = 0;

					for (int i = 0; i < n; i++) 
						if (x[i].assigned())	
							for (int j = i+1; j < n; j++) 
								if (x[j].assigned())
									if (x[i].val() == x[j].val())	
										borne_min += dcarre[i][j] ;


					for (int  i = 0; i < n; i++)
							if (!x[i].assigned())	{
									borne_min += VariancePartiel[i][n];
							}


					// I can make borne_Min to be better
					// First, how many point that is not fixed
					int notFix = 0;
					for (int i = 0; i < n; i++) 
						if (!x[i].assigned())
							notFix++;
					// Second, with notFix and k, we need at least how much of distance?
					int nPair = 0;
					int mSize = notFix/nClass;
					int delta = notFix - mSize * nClass;
					nPair =  ((nClass - delta) * mSize * (mSize - 1)) / 2;
					nPair += (delta * (mSize+1) * mSize) / 2;

					int nPair2 = 0;
					notFix--;
					mSize = notFix/nClass;
					delta = notFix - mSize * nClass;
					nPair2 =  ((nClass - delta) * mSize * (mSize - 1)) / 2;
					nPair2 += (delta * (mSize+1) * mSize) / 2;	

					// Third, I will not sort but take the total of nPair distance

					int count = 0;
					double V3 = 0;
					double V4 = 0;  // V4 is V3 but take only notFix - 1 point


					int countDist[n];
					for (int  i = 0; i < n; i++)
						countDist[i] = 0;
					double deltaDist[n];	// delta distance between V3 and V4 for 0, 1, 2,.. point


					for (int  i = 0; i < n; i++)
						deltaDist[i] = 0;


					double contribute[n]; // contribute of each point to V3, V4
					for (int  i = 0; i < n; i++)
						contribute[i] = 0;
/*					int nContribute[n];
					for (int  i = 0; i < n; i++) // number of distance that contribute 
						nContribute[i] = 0;


					double addDelta[n];
					for (int i = 0; i < n; i++)
						addDelta[i] = 0;
	*/
					for (int i = 0; i < (n * (n-1)/2); i++)  {
						if (count >= nPair + nPair) break;

						if ((!x[ pX[i] ].assigned()) && (!x[ pY[i] ].assigned())) {
							
							if (count < nPair)			
								V3 += dSort[i];

							if (count < nPair2) {
								V4 += dSort[i];
								countDist[pX[i]]++;
								countDist[pY[i]]++;
								contribute[pX[i]] += dSort[i];
								contribute[pY[i]] += dSort[i];

//								nContribute[pX[i]] ++;
		//						nContribute[pY[i]] ++;

							}

							else {
								deltaDist[count - nPair2 + 1] = dSort[i];
								if (count > nPair2)
									deltaDist[count - nPair2 + 1] += deltaDist[count - nPair2];					
								
/*								for (int j = 0; j < n; j++)
									if ((!x[j].assigned()) && (nContribute[j] > 0))
										if ((j != pX[i]) && (j != pY[i])) {
											addDelta[j] += dSort[i];
											nContribute[j]--;
										}
											
*/
							}
																
							count++;
							
							
						}
					}
						
				  // I will calcul V4delta for each point which is not fixed
					
					



		  		  GECODE_ME_CHECK(y.gq(home, borne_min + V3));   // there will be error if I do that			

				  //borne_min += V4;


			//______________________ I can make borne_Min to be better
					for (int i = 0; i < n; i++) 
						if ((!x[i].assigned())	)	{		// try to reduce domain of x[i] that is not instantiated

							double delta = V4 + deltaDist[countDist[i]] - contribute[i];
//							cout << delta << " " << V4 - contribute[i] + addDelta[i] << endl;
							int zz[x[i].size()];
							int zcount = 0;

							for  (Int::ViewValues<Int::IntView> z(x[i]); z(); ++z)  // back up value of variable x[i]
									zz[zcount++] = z.val();
											
						  for (int t = 0; t < zcount; t++) {
								if (delta + borne_min + VariancePartiel[i][zz[t]] - VariancePartiel[i][n] >= y.max()) { // now we can remove value z from x[i]

										GECODE_ME_CHECK(x[i].nq(home, zz[t]));   // there will be error if I do that			
								}
		
							}	



						}

				  return ES_OK;
		}
};

	void varianceConstraint(Home home, IntVarArgs x, FloatVar y) {
		// constraint post function
    ViewArray<Int::IntView> vx(home, x);
    Float::FloatView vy(y);
		if (varianceConstraint::post(home, vx, vy) != ES_OK)
			home.fail();
	}

