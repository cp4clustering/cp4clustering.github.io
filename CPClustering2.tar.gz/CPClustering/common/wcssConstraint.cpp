#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class wcssConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x;
		Float::FloatView y;

	public:
		// posting
		wcssConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0) 	// maybe we use ADVISOR to reduce number of propagation
			: Propagator(home), x(x0), y(y0)  {
			x.subscribe(home,*this,Int::PC_INT_VAL);
		}
		static ExecStatus post(Home home, 
			                     ViewArray<Int::IntView>& x0, Float::FloatView y0) {
			(void) new (home) wcssConstraint(home,x0,y0);
			return ES_OK;
		}
		// disposal
		virtual size_t dispose(Home home) {
			x.cancel(home,*this,Int::PC_INT_VAL);

			(void) Propagator::dispose(home);
			return sizeof(*this);
		}
		// copying
		wcssConstraint(Space& home, bool share, wcssConstraint& p) 
			: Propagator(home,share,p) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) wcssConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}




void quickSort(double arr[], int order[], int left, int right)
 {
  int i = left, j = right;

  double pivot = arr[(left + right) / 2];

  /* partition */

  while (i <= j) {
        while (arr[i] < pivot)
              i++;
        while (arr[j] > pivot)
              j--;
        if (i <= j) {
				swap( arr[i], arr[j]);
				swap(order[i], order[j]);

              i++;
              j--;
    }
}
/* recursion */
if (left < j)
    quickSort(arr, order, left, j);
if (i < right)
        quickSort(arr, order, i, right);
}





		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {



		if (k == 2) {

			double borne_min = 0;
			int q = 0; // number of unassigned point;
			double sizeCluster[k]; // number of point in a cluster
			for (int i = 0; i < k; i++) sizeCluster[i] = 0;

			for (int i = 0; i < n; i++)
				if (!x[i].assigned()) q++;
				else
					sizeCluster[ x[i].val() ]++;
			


			double totalSumCluster[k]; //totalSumCluster[i] = total sum of distance of pair of point in cluster i
			for (int i = 0; i < k; i++) totalSumCluster[i] = 0;

 			for (int i = 0; i < n; i++)
				if (x[i].assigned())
					for (int j = i+1; j < n; j++)
						if (x[j].assigned())
							if (x[i].val() == x[j].val())
								totalSumCluster[ x[i].val() ] += dd[i][j] * dd[i][j];		// It is V1
	


			double distanceToCluster[q+1][k]; //  distanceToCluster[i][j] = total squared distance from a point to cluster j. We need to sorted this sum.
			for (int i = 0; i <= q; i++)
				for (int c = 0; c < k; c++)
					distanceToCluster[i][c] = 0;


			q = 0;
			for (int i = 0; i < n; i++)
				if (!x[i].assigned()) {
					
					for (int j = 0; j < n; j++)
						if (x[j].assigned())  
							if (x[i].in( x[j].val() ))						
								distanceToCluster[q][ x[j].val() ] += dd[i][j] * dd[i][j];										
					q++;
				}



			for (int i = 1; i <= q; i++)
				for (int c = 0; c < k; c++)
					if (distanceToCluster[i][c] == 0)				// if distanceToCluster[i] = 0, it means that:   c is not in domain of i  or cluster[c] is EMPTY
						if (sizeCluster[c] > 0)
							distanceToCluster[i][c] = 100000000;



			double minV = 100000000;		

 
			std::vector<double> distQQ[q]; 
			int q1 = 0; 
			for (int i = 0; i < n; i++) {
				if (!x[i].assigned()) {
					for (int j = 0; j < n; j++) 
						if (!x[j].assigned()) 
							distQQ[q1].push_back( dd[i][j] * dd[i][j]/2 );
					q1++;
				}
			}
			

			for (int i = 0; i < q; i++)
				 std::sort (distQQ[i].begin(), distQQ[i].end());  


			for (int i = 0; i < q; i++)
				for (int j = 1; j < q; j++)
					distQQ[i][j] = distQQ[i][j] + distQQ[i][j-1];



			for (int i0 = 0; i0 <= q; i0++){
				int	i1 = q - i0;   // i0 point go to cluster 0, i1 point go to cluster 1
				int sizeC0 = sizeCluster[0] + i0;
				int sizeC1 = sizeCluster[1] + i1;
				
				if ((sizeC0 > 0)&& (sizeC1 > 0)) {
					double deltaV2[q];
				
					for (int i = 0; i < q; i++) {

						deltaV2[i] = 0;
						deltaV2[i] = distanceToCluster[i][0] / sizeC0 -  distanceToCluster[i][1] / sizeC1;

						if (i0 > 1)
							deltaV2[i] +=  distQQ[i][ i0-1 ] / sizeC0;

						if (i1 > 1)
							deltaV2[i] -=  distQQ[i][ i1-1 ] / sizeC1;			
					
			
					}

					int order[q];
					for (int i = 0; i < q; i++)
						order[i] = i;
			
/*					for (int i = 0; i < q; i++)
						for (int j = i+1; j < q; j++)
							if (deltaV2[i] > deltaV2[j]) {
								swap(deltaV2[i], deltaV2[j]);
								swap(order[i], order[j]);
							}
*/

					quickSort(deltaV2, order, 0, q-1);


					double v1 = 0; double v2 = 0; double v3 = 0;
					if (sizeC0 > 0)
						v1 += totalSumCluster[0] / sizeC0;				
					if (sizeC1 > 0)
						v1 += totalSumCluster[1] / sizeC1;

			
					for (int i = 0; i < i0; i++) {
						if (sizeC0 > 0)
							v2 +=  distanceToCluster[ order[i] ][0] / sizeC0;
						
						if (i0 > 1)
							v3 +=  distQQ[order[i]][ i0-1 ] / sizeC0;

					}


					for (int i = i0; i < q; i++) {
						if (sizeC1 > 0)
							v2 +=  distanceToCluster[ order[i] ][1] / sizeC1;

						if (i1 > 1)
							v3 +=  distQQ[order[i]][ i1-1 ] / sizeC1;

					}


					if (sizeC1 > 0) {
						if (v1 + v2  + v3 < minV)
							minV = v1 + v2 + v3 ;
					}
				
		

				}

				
			}

//		cout << minV << endl;
		GECODE_ME_CHECK(y.gq(home, minV));

		}
//______________________________________________K > 2______________________________________________



			double borne_min = 0;
			int q = 0; // number of unassigned point;
			double sizeCluster[k]; // number of point in a cluster
			for (int i = 0; i < k; i++) sizeCluster[i] = 0;

			for (int i = 0; i < n; i++)
				if (!x[i].assigned()) q++;
				else
					sizeCluster[ x[i].val() ]++;
			

			double t[q+1][k]; // t[i][j] = minimum wcss of cluster j if we add i point .    Now t contain only V1 and V2, not V3
			for (int i = 0; i <= q; i++)
				for (int j = 0; j < k; j++)
					t[i][j] = 0;

			double totalSumCluster[k]; //totalSumCluster[i] = total sum of distance of pair of point in cluster i
			for (int i = 0; i < k; i++) totalSumCluster[i] = 0;

 			for (int i = 0; i < n; i++)
				if (x[i].assigned())
					for (int j = i+1; j < n; j++)
						if (x[j].assigned())
							if (x[i].val() == x[j].val())
								totalSumCluster[ x[i].val() ] += dd[i][j] * dd[i][j];		// It is V1
	




			double distanceToCluster[q+1][k]; //  distanceToCluster[i][j] = total squared distance from a point to cluster j. We need to sorted this sum.
			for (int i = 0; i <= q; i++)
				for (int c = 0; c < k; c++)
					distanceToCluster[i][c] = 0;


			q = 0;
			for (int i = 0; i < n; i++)
				if (!x[i].assigned()) {

					for (int j = 0; j < n; j++)
						if (x[j].assigned())  
							if (x[i].in( x[j].val() ))						
								distanceToCluster[q][ x[j].val() ] += dd[i][j] * dd[i][j];										

					q++;
				}



			for (int i = 0; i < q; i++)
				for (int c = 0; c < k; c++)
					if (distanceToCluster[i][c] == 0)				// if distanceToCluster[i] = 0, it means that:   c is not in domain of i  or cluster[c] is EMPTY					
						if (sizeCluster[c] > 0)
						distanceToCluster[i][c] = 100000000;

			// distQQ: distance between non assigned points

			std::vector<double> distQQ[q]; 
			int q1 = 0; 
			for (int i = 0; i < n; i++) {
				if (!x[i].assigned()) {
					for (int j = 0; j < n; j++) 
						if (!x[j].assigned()) 
							distQQ[q1].push_back( dd[i][j] * dd[i][j]/2 );
					q1++;
				}
			}
			

			for (int i = 0; i < q; i++)
				 std::sort (distQQ[i].begin(), distQQ[i].end());  	// distQQ[ i ][ j ]: distance from point i to point j


			for (int i = 0; i < q; i++) 
				for (int j = 1; j < q; j++)
					distQQ[i][j] = distQQ[i][j] + distQQ[i][j-1];  // distQQ[ i ][ j ]: min sum distance from j point to point i



			for (int i = 0; i <= q; i++) {		// t[i][j] = minimum wcss of cluster j if we add i point .    Now t contain only V1 and V2, not V3
				for (int c = 0; c < k; c++) {
					double x = 0; int y = 0;


					std::vector<double> v23; 

					for (int j = 0; j < q; j++)
						if (i > 1)
							v23.push_back ( distanceToCluster[j][c] + distQQ[j] [ i-1 ]  );					
						else
							v23.push_back ( distanceToCluster[j][c] );					
	

			
					std::sort (v23.begin(), v23.end());  


					x = totalSumCluster[c];
					for (int j = 0; j < i; j++)
						x += v23[j];

					y = i + sizeCluster[c];
					

					if (y > 0) {
						t[i][c] = x/y;
						
					}
					if (sizeCluster[c] == 0) // this group is empty, so of course total distance to this cluster is 0
						t[i][c] = 0;

				}
			}		






			// from table t[i][c] -> calculate bound[0..q][ to all cluster]
			double bound[q+1][2];
			for (int i = 0; i <= q; i++) {	
				bound[i][0] = t[i][0];
				bound[i][1] = 0;
			}
			
			for (int c = 1; c < k; c++) {
					for (int i = 0; i <= q; i++) {
						bound[i][1] = 100000000;
						for (int j = 0; j <= i; j++)
							if (bound[i][1] > bound[j][0] + t[i - j][c]) {  // if we take j point from    c-1 cluster and   i-j point from cluster c then what?					
								bound[i][1] = bound[j][0] + t[i - j][c];
							}
					}
  
				// now bound[1] become bound[0]
				for (int i = 0; i <= q; i++) 
					bound[i][0] = bound[i][1];
			}

			borne_min = bound[q][0];


			GECODE_ME_CHECK(y.gq(home, borne_min));


	//		return ES_OK;
//	return ES_OK;


		// Filtering
//_____________________________________________________________________________________________________________

			double dToCluster[n][k];
			for (int i = 0; i < n; i++)
				for (int c = 0; c < k; c++)
					dToCluster[i][c] = 0;
			for (int i = 0; i < n; i++)
				if (!x[i].assigned())
					for (int j = 0; j < n; j++)
						if (x[j].assigned())
							if (x[i].in(x[j].val()))
								dToCluster[i][ x[j].val() ] += dd[i][j] * dd[i][j];
		

			q--;


			for (int c = 0; c < k; c++) { // check if value c is consistency.  We will consider c is the last clusters
				sizeCluster[c]++;
				
				// now BUILD the t[][] and bound[q][ k-1 ]
				// t[][] don't change at ALL
				// rebuild only bound[q][0]

//________________________________________________________________________
				for (int i = 0; i <= q; i++) {	
					if (c != 0) 
						bound[i][0] = t[i][0];
					else  
						bound[i][0] = t[i][1];

					bound[i][1] = 0;
				}
			

				
				for (int c1 = 1; c1 < k; c1++) {
					if (c1 != c)
					if (!((c == 0) && (c1 == 1)))
						for (int i = 0; i <= q; i++) {
							bound[i][1] = 100000000;
							for (int j = 0; j <= i; j++)
								if (bound[i][1] > bound[j][0] + t[i - j][c1]) {  // if we take j point from    c-1 cluster and   i-j point from cluster c then what?					
									bound[i][1] = bound[j][0] + t[i - j][c1];
								}
						}

						// now bound[1] become bound[0]
						for (int i = 0; i <= q; i++) 
							bound[i][0] = bound[i][1];
				}


//________________________________________________________________________



				for (int i = 0; i < n; i++)
					if (!x[i].assigned())
						if (x[i].in(c)) {

							totalSumCluster[c] += dToCluster[i][c];

							for (int i1 = 0; i1 <= q; i1++) {		// t[i][j] = minimum wcss of cluster j if we add i point .    Now t contain  V1 and V2, AND V3
								int y = 0;

	/*							std::vector<double> v23; 

								for (int j = 0; j < q+1; j++)
									if (j!=i)
										if (i1 > 1)
											v23.push_back ( distanceToCluster[j][c] + distQQ[j] [ i-1 ]  );					
										else
											v23.push_back ( distanceToCluster[j][c] );					
	

			
									std::sort (v23.begin(), v23.end());  

	
									x = totalSumCluster[c];
									for (int j = 0; j < i1; j++)
										x += v23[j];

*/


								//	x = totalSumCluster[c] + distanceToCluster[i1][c];		// MAYBE MAKE IT BETTER. I think I don't need because we filter furthest points

									y = i1 + sizeCluster[c];
//									t[i1][c] = x/y;
								
									t[i1][c] = (t[i1][c] * (y-1)  + dToCluster[i][c] )/ y;



							}		

							// we have bound[0..q][0], now take care min 
			
							double minV3 = 1000000;
							for (int j = 0; j <= q; j++)
								if (minV3 > bound[j][0] + t[q - j][c])   // if we take j point from    c-1 cluster and   i-j point from cluster c then what?					
									minV3 = bound[j][0] + t[q - j][c];
								
										

							if (minV3 >= y.max())
								GECODE_ME_CHECK(x[i].nq(home, c));
							



							totalSumCluster[c] -= dToCluster[i][c];

							//revert t[][]
							for (int i1 = 0; i1 <= q; i1++) {		// t[i][j] = minimum wcss of cluster j if we add i point .    Now t contain only V1 and V2, not V3
									double x = 0; int y = 0;


									y = i1 + sizeCluster[c];
									t[i1][c] = (t[i1][c] * y - dToCluster[i][c])/(y-1);
							}		
						}
			
				sizeCluster[c]--;


 	

			}


		return ES_OK;


	





	}

};

	void wcssConstraint(Home home, IntVarArgs x, FloatVar y) {
		// constraint post function
    ViewArray<Int::IntView> vx(home, x);
    Float::FloatView vy(y);
		if (wcssConstraint::post(home, vx, vy) != ES_OK)
			home.fail();
	}

