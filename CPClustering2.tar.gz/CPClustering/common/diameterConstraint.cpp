#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stack>    
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


/*
	Class for the diameter Constraint
	Using matrix of dissimilarity: dd[i][j]
	Input: 
		x - Variables G
		y - Dmax: upper bound of Diameter.   y.min = 0, y.max = upper bound of Diamter
		z - Dmin: lower bound of Diamter.	 z.min = lower bound of Diamter, z.max = infinitie
*/
class diameterConstraint : public Propagator {
	protected:
		ViewArray<Int::IntView> x; // G
		Float::FloatView y; // Dmax
		Float::FloatView z; // Dmin
		stack<int> fixedPoints;
		int changeD;			
	
	 class ViewAdvisor : public Advisor {
	  public:
		Int::IntView x;
		Float::FloatView y; // Dmax
		Float::FloatView z; // Dmin

		int index;


		// The constraint is activated each time there is changement in G or Dmax
		ViewAdvisor(Space& home, Propagator& p, 
		            Council<ViewAdvisor>& c, Int::IntView x0, int index0, Float::FloatView y0) 
		  : Advisor(home,p,c), x(x0), index(index0), y(y0) {
		  x.subscribe(home,*this);
		  y.subscribe(home,*this);

		}
		ViewAdvisor(Space& home, bool share, ViewAdvisor& a)
		  : Advisor(home,share,a), index(a.index) {
		  x.update(home,share,a.x);
		  y.update(home,share,a.y);

		}
		void dispose(Space& home, Council<ViewAdvisor>& c) {
		  x.cancel(home,*this);
		  y.cancel(home,*this);
		  Advisor::dispose(home,c);
		}
	  };

	  Council<ViewAdvisor> c;


	public:
		// posting the constraint
		diameterConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0, Float::FloatView z0) 
			: Propagator(home), x(x0), y(y0), z(z0), c(home), changeD(0)  {
			for (int i=x.size(); i--; )
			  (void) new (home) ViewAdvisor(home,*this,c,x[i], i, y);
		    (void) new (home) ViewAdvisor(home,*this,c,x[0], -1, y);
			home.notice(*this,AP_DISPOSE);
		}

		static ExecStatus post(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0, Float::FloatView z0) {
			(void) new (home) diameterConstraint(home,x0,y0,z0);
			return ES_OK;
		}

		// disposal
		virtual size_t dispose(Home home) {
			c.dispose(home);
			(void) Propagator::dispose(home);
			return sizeof(*this);
		}

		// copying
		diameterConstraint(Space& home, bool share, diameterConstraint& p) 
			: Propagator(home,share,p), changeD(0) {
				x.update(home, share, p.x);
				y.update(home, share, p.y);
				z.update(home, share, p.z);
			    c.update(home,share,p.c);
		}
		virtual Propagator* copy(Space& home, bool share) {
			return new (home) diameterConstraint(home,share,*this);
		}
		// cost computation
		virtual PropCost cost(const Space&, const ModEventDelta&) const {
			return PropCost::binary(PropCost::HI);
		}


	  // advise function to know what variables are changed 
	  // this function is called whenever there are change on G or Dmax
	  virtual ExecStatus advise(Space&, Advisor& a, const Delta& d) {
			//	put every new assigned points to stack fixedPoints
			if (static_cast<ViewAdvisor&>(a).index >= 0) {
				if (static_cast<ViewAdvisor&>(a).x.assigned()) {			
						fixedPoints.push(static_cast<ViewAdvisor&>(a).index);
				}
			}
			else { // index = -1, Dmax has changed	
				changeD = 1;	
			}

			// always active the propagateur			
			return ES_NOFIX;
	  }


		// propagation
		virtual ExecStatus propagate(Space& home, const ModEventDelta&)  {
			if (changeD) {   // Dmax is changed, so I have to add all fixed points to the stack fixedPoints
				changeD = 0;
				if (z.min() >= y.max()) return ES_FAILED;

				while ( !fixedPoints.empty() ) // let the stack be empty
					fixedPoints.pop();
				for (int i = 0; i < n; i++)
					if (x[i].assigned())
						fixedPoints.push(i);				

			}
		
			while (!fixedPoints.empty()) {
 				int i = fixedPoints.top();
				fixedPoints.pop();
				for (int j = 0; j < n; j++) {

					if (dd[i][j] >= y.max())  
							GECODE_ME_CHECK(x[j].nq(  home, x[i].val() )); 
	
					if (x[j].assigned()) 
						if (x[i].val() == x[j].val())	{		// Dmin updated here
				  		  	GECODE_ME_CHECK(z.gq(home, dd[i][j]));
							if (dd[i][j] >= y.max())
								return ES_FAILED;
						}
				}
			}

			return ES_FIX;
		}
};

	void diameterConstraint(Home home, IntVarArgs x, FloatVar y, FloatVar z) {
		// constraint post function
		ViewArray<Int::IntView> vx(home, x);
		Float::FloatView vy(y);
		Float::FloatView vz(z);
			if (diameterConstraint::post(home, vx, vy, vz) != ES_OK)
				home.fail();
	}

