#include <iostream>
#include <vector>



std::vector<double> *a; // matrix  attribute   original
std::vector<double> *center; // used for wcss



double startAll;	// for time of calculation

int *order;	// for saving   new order


int objectiveFunction = 0;

int *realClass;

int **mlcl;


int *positionG; // position[G[i]] = 0,...,k-1

double **dd;
//double **dcarre;


double finalVariance = 0;
int *finalClass;
int *finalOrder;

int n = 0;
int k = 0;
int nA = 0; 	// n: number of points, k: number of clusters, nA: number of attributes

char *fileResult = "result.txt";

double *bestV; // bestVariance with a number of point
//int **bestSol; // best Solution of best Variance


double **VariancePartiel;

int *sClass;

double *dSort; // distance CARRE sort. 
int *pX, *pY; // position x, position y in the dSort. x:row, y:column

int countPropagation = 0;

double maxD, minD;

double diamHeuristic = 0;
double diamHeuristicKmin = 0;
int obj = 0;

double *wcss;

int FoundSolution = 0;

double bestDiam = 10000000000000;
double bestSepa = 0;
int stopCondition = 0;

double Diameter_UB = 0;
double Separateur_UB = 0;

double *allSeparation;

double timebestSol; // time for best solution

double *saveSepa;
double *saveDiam;
int *badParetoSolution;
int nSolution = 0;

double bound_DiameterMax = 0;
double bound_SplitMin = 0;



