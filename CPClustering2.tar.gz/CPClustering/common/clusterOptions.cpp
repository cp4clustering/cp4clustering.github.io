

class ClusterOptions : public Options {
protected:
	Driver::IntOption _n; // Number of transactions/points
	Driver::IntOption _k; // Number of max clusters
	Driver::IntOption _kmin; // Number of min clusters
	Driver::IntOption _a; // Number of attributes
	Driver::IntOption _datatype; // data type:  0 - normal data, 1 - matrix data
	Driver::IntOption _dfpf; // use contrainte of diameter_fpf or NOT,  if fpf=1:  d[i][j] < d_fpf if i, j in same group
	Driver::DoubleOption _s; // User constraint: constraint of minimum split 
	Driver::StringValueOption _f; // file name of dataset
	Driver::StringValueOption _c; // User constraint: constraint file for must-link and cannot-link constraint
	Driver::IntOption _sizeMin; // User constraint: sizeMin constraint of groups
	Driver::IntOption _sizeMax; // User constraint: sizeMax constraint of groups
	Driver::IntOption _order; // ordering point or not. Order = 0: no ordering. Order = 1: Use our Function, Order = 2: FPF
	Driver::IntOption _obj; // objective function, obj = 1: max diameter, obj = 2: min separation, obj = 3 : wcsd,...
	Driver::IntOption _epsilon; // User constraint: for epsilon constraint
	Driver::IntOption _minpoint; //User constraint: for epsilon constraint
	Driver::DoubleOption _diam; // User constraint: constraint of maximum diameter


public:
  /// Constructor
	ClusterOptions(void) : Options("Cluster"),
		_n("-n","number of transactions/points",150),  // opt.n() = 0 when we do with ALL DATA
		_datatype("-datatype","normal data or matrix data",0),  // 0 : normal data, 1: matrix data
		_kmin("-kmin","min number of clusters",2),
		_k("-k","number of clusters",3),
		_a("-a","number of attributes",4),
		_dfpf("-dfpf","Using Contrainte of Diameter FPF", 0), //fpf=1: d[i][j] < d_fpf if i, j  in the same group
		_diam("-diam","Using Contrainte of Diameter", 0), //fpf=1: d[i][j] < d_fpf if i, j  in the same group
		_sizeMin("-sizeMin","sizeMin Constrain",0),
		_sizeMax("-sizeMax","sizeMax Constrain",0),
		_s("-s","separation of group",0),
		_f("-f","file name", "data/iris_150_4_3.txt"),
		_c("-c","constraint ML/CL file", "mlcl.txt"),
		_order("-order","ordering points", 2),
		_obj("-obj","Selection of Objective Functions", 1), //obj = 1: max diameter, obj = 2: min separation, obj = 3: variance; obj = 4 : kMeans
		_epsilon("-epsilon","epsilon", 50), //a distance
		_minpoint("-minpoint","minpoint", 0) //like dbscan, each point must have at least |minpoint| in the distance epsilon  			
	{
		add(_n); add(_k); add(_kmin); add(_a); add(_f); add(_c); add(_diam);
		add(_sizeMin);add(_sizeMax);add(_s);add(_order);add(_obj);add(_dfpf);
		add(_epsilon);add(_minpoint); add(_datatype);
	}


	int n(void) const { 
		return _n.value(); 
	}

	int k(void) const { 
		return _k.value(); 
	}

	int kmin(void) const { 
		return _kmin.value(); 
	}

	int a(void) const { 
		return _a.value(); 
	}

	double diam(void) const { 
		return _diam.value(); 
	}

	int datatype(void) const { 
		return _datatype.value(); 
	}

	int sizeMin(void) const { 
		return _sizeMin.value(); 
	}

	int sizeMax(void) const { 
		return _sizeMax.value(); 
	}

	int order(void) const { 
		return _order.value(); 
	}

	int obj(void) const { 
		return _obj.value(); 
	}

	int dfpf(void) const { 
		return _dfpf.value(); 
	}

	
	int epsilon(void) const { 
		return _epsilon.value(); 
	}

	int minpoint(void) const { 
		return _minpoint.value(); 
	}


	string f(void) const { 
		return _f.value(); 
	}
	string c(void) const { 
		return _c.value(); 
	}
	
	double s(void) const { 
		return _s.value(); 
	}
};
