#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <string>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"
#include "cpClusterCC.h"
#include "branchDiameter.h"
#include "diameterConstraint.h"
#include "splitConstraint.h"

using namespace Gecode;
using namespace std; 


void CPClusterCC::
postConstraints(int nOrigine, bool all, int nSP, 
		int* orderSP, int* rorderSP, 
		vector<int>* clgraph, vector<int>* cc,
		int* rorder, int* ccindex,
		vector<double>* feat, vector<string>* prop) {
  // PRECEDE 
  IntArgs t(options.k()); // array [0..k-1]
  for (int i = 0; i < options.k(); i++)
    t[i] = i;
  precede(*this, G, t);
  
  // At least kmin clusters
  if (options.kmin() > 0)
    count(*this, G, options.kmin()-1, IRT_GQ, 1);
  else
    count(*this, G, options.k()-1, IRT_GQ, 1);

  if (all) { // put all user cluster level constraints
    // size constraint
    if ((options.sizeMin() || options.sizeMax()) ) { 
      IntVarArgs totalG(nOrigine);
      int ip=0;
      for (int i=0; i<nSP; i++)
	for (unsigned j=0; j<cc[orderSP[i]].size(); j++)
	  totalG[ip++] = G[i];
      
      // ATTENTION: for a required number of clusters
      if (options.sizeMin() && options.ucase()==0) {
	cout << "size min required: " << options.sizeMin() << endl;
	for (int c = 0; c < options.k(); c++)
	  count(*this, totalG, c, IRT_GQ, options.sizeMin());
	if (nOrigine/options.sizeMin() < options.k())
	  for (int i=0; i < nSP; i++)
	    rel(*this, G[i], IRT_LQ, nOrigine/options.sizeMin()-1);
      }
      if (options.sizeMax()  && options.ucase()==0) {
	cout << "size max required: " << options.sizeMax() << endl;
	for (int c = 0; c < options.k(); c++) 
	  count(*this, totalG, c, IRT_LQ, options.sizeMax());
	// there must be at least nOrigine/sizemax-1 clusters
	if (nOrigine/options.sizeMax() > options.kmin() ||
	    nOrigine/options.sizeMax() > options.k())
	  count(*this, G, nOrigine/options.sizeMax()-1, IRT_GQ, 1);
      }
    }

    // density constraint
    if (options.epsilon() * options.minpoint() > 0) {
      // compute all neighbors for all points
      vector<int>* neighbor=new vector<int>[nOrigine];
      for (int i=0; i<nOrigine; i++)
 	for (int j=i+1; j<nOrigine; j++)
	  if (dist(feat[rorder[i]], feat[rorder[j]])<=options.epsilon()) {
	    neighbor[i].push_back(j);
	    neighbor[j].push_back(i);
	  }
      // then put constraints for points
      for (int i=0; i<nOrigine; i++) {
	IntVarArgs nearPoints(neighbor[i].size());
	for (unsigned j=0; j<neighbor[i].size(); j++) {
	  int point=neighbor[i][j];
	  nearPoints[j] = G[rorderSP[ccindex[point]]];
	}
	count(*this, nearPoints, G[rorderSP[ccindex[i]]], IRT_GQ, 
	      options.minpoint()*neighbor[i].size());
      }
      delete[] neighbor;
    }

    // diameter constraint ---> CL created in preprocess, put in clgraph

    // split constraint ---> ML created in preprocess, yield superpoints
 
  }

  if (!options.c().empty() || options.diam() > 0) 
    // ML constraints have been handled by super-points
    // need to put only CL constraints
    for (int iSP=0; iSP<nSP; iSP++) {
      int x = rorderSP[iSP]; // position of iSP over all the  points
      for (unsigned j=0; j<clgraph[iSP].size(); j++) {
	int jSP = clgraph[iSP][j];
	int y = rorderSP[jSP]; 
	rel(*this, G[x], IRT_NQ, G[y]);
      }
    }
    
  switch (options.obj()){
  case 1: // minimize diameter
    diameterConstraint(*this, G, D, ddMax);
    break;
  case 2: // maximize split
    splitConstraint(*this, G, S, ddMin);
    break;
  }
}


void CPClusterCC::
postUCconstraints(int nOrigine, bool all, int nSP, 
		  int* orderSP, int* rorderSP, 
		  vector<int>* clgraph, vector<int>* cc,
		  int* rorder, int* ccindex,
		  vector<double>* feat, vector<string>* prop) {
  int  uc = options.ucase();
  IntVarArgs totalG(nOrigine);
  int ip=0;
    cout << "post uc constraints" << endl;
  for (int i=0; i<nSP; i++)
    for (unsigned j=0; j<cc[orderSP[i]].size(); j++)
      totalG[ip++] = G[i];
  int k = options.k();
  IntVarArray sc(*this, k, 1, nOrigine);
  for (int i=0; i<k; i++)
    count(*this, totalG, i, IRT_EQ, sc[i]);
  linear(*this, sc, IRT_EQ, nOrigine);
  if (options.sizeMin())
    for (int i=0; i<k; i++)
      rel(*this, sc[i] >= options.sizeMin());

  switch (uc) {
  case 2: {
    // constraint for all clusters
    // all cluster have 0.5m/f <= #males/#females <= 2m/f
    // prop is indexed wrt order,
    // prop[i] : properties of i-th point in "order"
    
    int ec[nOrigine];
    int nMale = 0;
    int nFemale = 0;
    // count independent from order
    for (int i=0; i<nOrigine; i++) 
      if (prop[rorder[i]][9].compare("Female")==0) {
	ec[i] = 0;
	nFemale++;
      } else {
	ec[i] = 1;
	nMale++;
      }
    cout << nFemale << " females, " << nMale << " males" << endl;
    IntVarArgs varMale(nMale);
    IntVarArgs varFemale(nFemale);
    int iMale=0;
    int iFemale=0;
    for (int i=0; i<nOrigine; i++)
      if (ec[i]==1)
	varMale[iMale++] = G[rorderSP[ccindex[i]]];
      else
	varFemale[iFemale++] = G[rorderSP[ccindex[i]]];
    IntVarArray m(*this,k, 0, nMale);
    IntVarArray f(*this, k, 0, nFemale);
    linear(*this, m, IRT_EQ, nMale);
    linear(*this, f, IRT_EQ, nFemale);
    for (int i=0; i<k; i++) {
      count(*this, varMale, i, IRT_EQ, m[i]);
      count(*this, varFemale, i, IRT_EQ, f[i]);
      rel(*this, m[i]+f[i] == sc[i]);
      rel(*this, f[i]*nMale <= 2*m[i]*nFemale);
      rel(*this, m[i]*nFemale <= 2*f[i]*nMale);
    }
    break;
  }
  case 3:  {
    // // each person of 20 <= age <= 50
    // must be in the same cluster with at least 10% of persons having the same work occupation
    for (int i=0; i<nOrigine; i++) {
      int ai = atoi(prop[rorder[i]][0].c_str());
      if (ai >= 20 && ai <= 50) {
    	stack<int> neighbor;
    	for (int j=0; j<nOrigine; j++)
    	  //if (j!=i && abs(ai - atoi(prop[rorder[j]][0].c_str())) < 5)
	  if (j!=i && prop[rorder[j]][6].compare(prop[rorder[i]][6])==0)
    	    neighbor.push(j);
    	if (neighbor.size()>0) {
    	  //cout << "point " << i << "neighbor size " << neighbor.size() << endl;
    	  IntVarArgs nearPoint(neighbor.size());
    	  int p=0;
    	  while (!neighbor.empty()) {
    	    int j=neighbor.top();
    	    neighbor.pop();
    	    nearPoint[p++] = G[rorderSP[ccindex[j]]];
    	  }
    	  count(*this, nearPoint, G[rorderSP[ccindex[i]]], IRT_GQ, nearPoint.size()/10);
    	} 
      }
    }

    break;
  }
  case 4:  {
    // diameter constraint
    int minAge, maxAge;
    maxAge=minAge=atoi(prop[0][0].c_str());
    for (int i=1; i<nOrigine; i++) {
      int age = atoi(prop[i][0].c_str());
      if (minAge > age)
	minAge = age;
      else if (maxAge < age)
	maxAge = age;
    }
    cout << "max age = " << maxAge << " min = " << minAge << endl;
    for (int i=0; i<nOrigine; i++)
      for (int j=i+1; j<nOrigine; j++)
	// prop is indexed wrt "order"
	if (abs(atoi(prop[rorder[i]][0].c_str())-atoi(prop[rorder[j]][0].c_str()))
	    //>=(maxAge-minAge)/2+1)
	    >=(maxAge-minAge)/1.5+1)
	  rel(*this, G[rorderSP[ccindex[i]]], IRT_NQ, G[rorderSP[ccindex[j]]]);
    break;
  }
  case 7: {
    // combination of case 3 and case 4
    // // each person of 20 <= age <= 55 must have at least 10% of neighbors
    for (int i=0; i<nOrigine; i++) {
      int ai = atoi(prop[rorder[i]][0].c_str());
      if (ai >= 20 && ai <= 50) {
    	stack<int> neighbor;
    	for (int j=0; j<nOrigine; j++)
    	  //if (j!=i && abs(ai - atoi(prop[rorder[j]][0].c_str())) < 5)
	  if (j!=i && prop[rorder[j]][6].compare(prop[rorder[i]][6])==0)
    	    neighbor.push(j);
    	if (neighbor.size()>0) {
    	  //cout << "point " << i << "neighbor size " << neighbor.size() << endl;
    	  IntVarArgs nearPoint(neighbor.size());
    	  int p=0;
    	  while (!neighbor.empty()) {
    	    int j=neighbor.top();
    	    neighbor.pop();
    	    nearPoint[p++] = G[rorderSP[ccindex[j]]];
    	  }
    	  count(*this, nearPoint, G[rorderSP[ccindex[i]]], IRT_GQ, nearPoint.size()/10);
    	} 
      }
    }
        // diameter constraint
    int minAge, maxAge;
    maxAge=minAge=atoi(prop[0][0].c_str());
    for (int i=1; i<nOrigine; i++) {
      int age = atoi(prop[i][0].c_str());
      if (minAge > age)
  	minAge = age;
      else if (maxAge < age)
  	maxAge = age;
    }
    for (int i=0; i<nOrigine; i++)
      for (int j=i+1; j<nOrigine; j++)
  	if (abs(atoi(prop[rorder[i]][0].c_str())-atoi(prop[rorder[j]][0].c_str()))
	    //>=(maxAge-minAge)/2+1)
	    >=(maxAge-minAge)/1.5+1)
  	  rel(*this, G[rorderSP[ccindex[i]]], IRT_NQ, G[rorderSP[ccindex[j]]]);

    break;
  }
  case 5: {
    // constraint for all clusters
    // a cluster having more than 20 persons younger than 20 must have 30 person older than 45
    stack<int> less20;
    stack<int> more45;
    for (int i=0; i<nOrigine; i++)  {
      int age = atoi(prop[rorder[i]][0].c_str());
      if (age <= 20) {
    	less20.push(i);
      } else if (age >= 45)
	more45.push(i);
    }
    int n20 = less20.size();
    int n45 = more45.size();
    IntVarArgs var20(n20);
    IntVarArgs var45(n45);
    int index20=0;
    int index45=0;
    while (!less20.empty()) {
      int i = less20.top();
      less20.pop();
      var20[index20++] = G[rorderSP[ccindex[i]]];
    }
    while (!more45.empty()) {
      int i = more45.top();
      more45.pop();
      var45[index45++] = G[rorderSP[ccindex[i]]];
    }
    IntVarArray l20(*this,k, 0, n20);
    IntVarArray m45(*this, k, 0, n45);
    linear(*this, m45, IRT_EQ, n45);
    linear(*this, l20, IRT_EQ, n20);
    for (int i=0; i<k; i++) {
      count(*this, var20, i, IRT_EQ, l20[i]);
      count(*this, var45, i, IRT_EQ, m45[i]);
      rel(*this, (l20[i]>=20) >> (m45[i]>=30));
    }
    break;
  }

  default:
    break;
  }
}

void  CPClusterCC::
postPenConstraints(int nOrigine, int nSP, 
		   int* orderSP, int* rorderSP, 
		   vector<int>* clgraph, vector<int>* cc,
		   int* rorder, int* ccindex,
		   vector<double>* feat, vector<string>* prop) {
  // -u ucase  to pass the coordinate (3rd or 5th)
  // -d diam to pass bound value
  cout << "coordinate:" << options.ucase() << " diam max:" << options.diam() << endl;
  for (int i=0; i<nOrigine; i++)
    for (int j=i+1; j<nOrigine; j++)
      if (abs(feat[rorder[i]][options.ucase()]-feat[rorder[j]][options.ucase()]) > options.diam())
	  rel(*this, G[rorderSP[ccindex[i]]], IRT_NQ, G[rorderSP[ccindex[j]]]);

}

void CPClusterCC::postBranch() {
  switch(options.obj()) {
  case 1: // diameter
    if (options.branch()==0)
      branchDiameter::post(*this, G, ddMax,true,false);
    else
      branch(*this, G, INT_VAR_DEGREE_MAX(), INT_VAL_MIN());
    break;
  case 2: // split
    branchDiameter::post(*this, G, ddMin,true,false);
    break;
  case 0:
  default:
    break;
  }
}
 
void CPClusterCC::print() const {
  if (options.verbose() >= 2) {
    cout << G << endl;
    cout << "___________________________________________________" << endl;
  }
  switch (options.obj()) {
  case 1: // diameter
    //cout << "print solution" << endl;
    cout << "D: " << D.min() << endl; //<< " " << D.max() << endl;
    break;
  case 2: // split
    cout << "S: " << S.min() << " " << S.max() << endl;
    break;
  default:
    break;
  }
}

double CPClusterCC::objValue() {
  switch (options.obj()) {
  case 1:
    return D.min();
  case 2:
    return S.max();
  default:
    return 0;
  }
}

void CPClusterCC::computeSize(vector<int>* cc, int* orderSP) {
  int n=G.size();
  int k=0;
  for (int i=0; i<n; i++)
    if (k<G[i].val())
      k = G[i].val();
  k += 1;
  int s[k];
  cout << k << " clusters of sizes: ";
  for (int i=0; i<k; i++)
    s[i] = 0;
  for (int i=0; i<n; i++)
    s[G[i].val()] += cc[orderSP[i]].size();
  for (int i=0; i<k; i++)
    cout << s[i] << ", ";
  cout << endl;
}
 

double CPClusterCC::computeRI(int nOrigine, int* clusterGT, int* ccindex, int* rorderSP) {
  double ri = 0;
  int a = 0;
  int b = 0;
  for (int i=0; i<nOrigine; i++)
    for (int j=i+1; j<nOrigine; j++) {
      int iSP = ccindex[i];
      int jSP = ccindex[j];
      if (clusterGT[i]==clusterGT[j] && G[rorderSP[iSP]].val()==G[rorderSP[jSP]].val())
	a++;
      else if (clusterGT[i]!=clusterGT[j] && G[rorderSP[iSP]].val()!=G[rorderSP[jSP]].val())
	b++;
    }
  ri = ((double)(a+b)*2) / ((nOrigine-1)*nOrigine);
  return ri;
}

void CPClusterCC::printStats(int nOrigine, vector<string>* prop, int*ccindex, int* rorderSP, int* rorder) {
  int n=G.size();
  int k=0;
  for (int i=0; i<n; i++)
    if (k<G[i].val())
      k = G[i].val();
  k += 1;
  vector<int> cptF(k,0);
  vector<int> cptM(k,0);
  vector<double> minCapGain(k,0);
  vector<double> maxCapGain(k,0);
  vector<double> minCapLoss(k,0);
  vector<double> maxCapLoss(k,0);
  vector<int> minEdu(k,0);
  vector<int> maxEdu(k,0);
  vector<int> minAge(k,0);
  vector<int> maxAge(k,0);
  vector<int> cptH(k,0);

  for (int i=0; i<nOrigine; i++) {
    int posI = rorder[i];
    int c = G[rorderSP[ccindex[i]]].val(); // cluster that contains i
    if (prop[posI][9].compare("Female")==0)
      cptF[c]++;
    else
      cptM[c]++;
    // husband
    if (prop[posI][7].compare("Husband")==0)
      cptH[c]++;
    // education
    if (atoi(prop[posI][4].c_str())>maxEdu[c])
      maxEdu[c] = atoi(prop[posI][4].c_str());
    else if (minEdu[c]==0 || atoi(prop[posI][4].c_str()) < minEdu[c])
      minEdu[c] =  atoi(prop[posI][4].c_str());
    // age
    if (atoi(prop[posI][0].c_str())>maxAge[c])
      maxAge[c] = atoi(prop[posI][0].c_str());
    else if (minAge[c]==0 || atoi(prop[posI][0].c_str()) < minAge[c])
      minAge[c] =  atoi(prop[posI][0].c_str());
    // gain
    if (atoi(prop[posI][10].c_str())>maxCapGain[c])
      maxCapGain[c] = atoi(prop[posI][10].c_str());
    else if (minCapGain[c]==0 || atoi(prop[posI][10].c_str()) < minCapGain[c])
      minCapGain[c] =  atoi(prop[posI][10].c_str());
    // loss
    if (atoi(prop[posI][11].c_str())>maxCapLoss[c])
      maxCapLoss[c] = atoi(prop[posI][11].c_str());
    else if (minCapLoss[c]==0 || atoi(prop[posI][11].c_str()) < minCapLoss[c])
      minCapLoss[c] =  atoi(prop[posI][11].c_str());
  }
  for (int i=0; i<k; i++)
    cout << i << "(" << cptF[i] << "f/" << cptM[i] << "m," << cptH[i] << "husbands, edu " 
	 << minEdu[i] << "/"<< maxEdu[i] 
	 << ",age " << minAge[i] << "/" << maxAge[i]
	 << ", gain "
	 << minCapGain[i] << "/"<< maxCapGain[i] << ", loss "
	 << minCapLoss[i] << "/"<< maxCapLoss[i] << "), ";
  cout << endl;
}

void CPClusterCC::savePartition(int n, vector<int>& partition, int* ccindex, int* rorderSP) {
  for (int i=0; i<n; i++) {
    int iSP = ccindex[i];
    partition[i] = G[rorderSP[iSP]].val();
  }
}

void CPClusterCC::savePartitionFile(int n, int* ccindex, int* rorderSP) {
  string fname=options.output();
  if (fname.empty())
    fname="partition.txt";
  ofstream f(fname,ios::out);        
  if (!f.good()) {
    cerr << "Error: could not open file " << fname << endl;
    exit(EXIT_FAILURE);
  }
  for (int i=0; i<n; i++) {
    int iSP = ccindex[i];
    f<< G[rorderSP[iSP]].val()+1 << endl;
  }
  f.close();
}
