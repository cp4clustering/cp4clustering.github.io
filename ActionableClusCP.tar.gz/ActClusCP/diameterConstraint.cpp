#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stack>    
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "diameterConstraint.h"


using namespace Gecode;
using namespace std;

// propagation
ExecStatus DiameterConstraint::propagate(Space& home, const ModEventDelta& med)  {
  int n = x.size(); // there is n point

  if (Float::FloatView::me(med) == Float::ME_FLOAT_BND) {   
    // see if change in upper bound
    if (ub > y.max()) {
      ub = y.max();
      //cout << "bound diameter changed: " << ub << " to " << y.min() << endl;
      //int na = 0;
      while ( !fixedPoints.empty() ) // empty the stack
	fixedPoints.pop();
      for (int i = 0; i < n; i++)
	if (x[i].assigned()) {
	  fixedPoints.push(i);
	  //na++;
	}
      //cout << na << " assigned variables" << endl;
    }
  }
		
  while (!fixedPoints.empty()) {
    int i = fixedPoints.top();
    fixedPoints.pop();
    for (int j = 0; j < n; j++) {
      if (dd[i][j] >= y.max())  
	GECODE_ME_CHECK(x[j].nq(  home, x[i].val() )); 
      if (x[j].assigned() && x[i].val() == x[j].val())
	GECODE_ME_CHECK(y.gq(home, dd[i][j]));
    }
  }


  return ES_FIX;
}

void diameterConstraint(Home home, IntVarArgs x, FloatVar y, vector<double>* dd) {
  if (home.failed()) return;
  ViewArray<Int::IntView> vx(home, x);
  Float::FloatView vy(y);
  GECODE_ES_FAIL(DiameterConstraint::post(home,vx,vy,dd));
}

