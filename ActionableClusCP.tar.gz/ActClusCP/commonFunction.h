#ifndef COMMON_FUNCTION
#define COMMON_FUNCTION

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include <stack>  
#include <string>

using namespace std;

double dist(vector<double>, vector<double>);
double distSquare(vector<double> x, vector<double> y);
int distInt(vector<double> x, vector<double> y) ;  // calcul distance of 2 points x, y
double give_time();
void readDataMatrix(int n, ifstream&, double &maxD, double &minD, double**) ;
void readData(int n, ifstream&, vector<double> *a) ;
void sortD(int n, vector<double>* dd, double* dSort, int* pX, int* pY);
void reOrderPointFPF(int n, vector<double> *a, int* order) ;
void reOrderPointRBBA(int n, vector<double> *a, int* order) ;
void reOrderPointFPF_lastK(int n, int k, vector<double> *a, int* order) ;
void reOrderPointVariance(int n, vector<double> *a, int* order) ;
void reOrderPointPoid(int n,vector<double> *a, int* order)  ;
void reOrderPointRANDOM(int n, vector<double> *a, int* order)  ;
void reOrderPointRevert(int n, vector<double> *a, int* order)  ;
void calculD(int n, int nSmall, int order, double &maxD, double &minD,  vector<double> *a, double** dd);
double calculDiameterFPF(int n, int k, double** dd) ;
//void buildFinalOrder(int n, int* finalClass, int* finalOrder, double** dd) ;

void reOrderFPF_SP(int n, double** dist, int* order);

#endif
