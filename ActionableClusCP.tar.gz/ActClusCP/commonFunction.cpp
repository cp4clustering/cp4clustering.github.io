#include<climits>
#include <sstream>
#include "commonFunction.h"


 double dist(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return sqrt(d);
}


 double distSquare(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return d;
}



 int distInt(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  d = sqrt(d);
  d *= 100;

  return (int) d;
}

 double give_time(){
  struct rusage ru;
  struct timeval tim;
  getrusage(RUSAGE_SELF, &ru);
  tim = ru.ru_utime;
  return (double)tim.tv_sec+(double)tim.tv_usec/1000000.0;
}


 void readDataMatrix(int n, ifstream &fin, double &maxD, double &minD, double** dd) {
  maxD = 0;
  minD = 100000000;
  for (int i = 0; i < n; i++) 
    for (int j = 0; j < n; j++) {
      fin >> dd[i][j];
      //dcarre[i][j] = dd[i][j] * dd[i][j];
      if (i != j) {
	if (maxD < dd[i][j]) maxD = dd[i][j];
	if (minD > dd[i][j]) minD = dd[i][j];
      }
    }	// end of read file
}

 void readData(int n, ifstream &fin, vector<double> *a) {
  for (int i = 0; i < n; i++)  {        
    string line;
    getline(fin,line);   
    istringstream iss(line);
    double value;
    while ( iss >> value ) 
      a[i].push_back(value);
    if (i>0 && a[i].size()!=a[i-1].size()) {
      cerr << i << " Error: data don't have the same size.\n";
      exit(EXIT_FAILURE);
    }
  }
}


int pivot(double a[], int pX[], int pY[], int first, int last) {
  int  p = first;
  double pivotElement = a[first];
 
  for(int i = first+1 ; i <= last ; i++) {
    if(a[i] <= pivotElement) {
      p++;
      swap(a[i], a[p]);
      swap(pX[i], pX[p]);
      swap(pY[i], pY[p]);
    }
  }

  swap(a[p], a[first]);
  swap(pX[p], pX[first]);
  swap(pY[p], pY[first]);

  return p;
}

inline void quickSort( double a[], int pX[], int pY[], int first, int last ) {
  int pivotElement;
 
  if(first < last) {
    pivotElement = pivot(a, pX, pY, first, last);
    quickSort(a, pX, pY, first, pivotElement-1);
    quickSort(a, pX, pY, pivotElement+1, last);
  }
}
 
void sortD(int n, vector<double>* dd, double* dSort, int* pX, int* pY) {
  int count = 0;
  for (int i = 0; i < n; i++)
    for (int j = i+1; j <n; j++) {
      pX[count] = i;
      pY[count] = j;
      count++;
    }

  count = 0;
  for (int i = 0; i < n; i++)
    for (int j = i+1; j <n; j++) {
      dSort[count] = dd[i][j]; // dd[i][j] * dd[i][j];
      count++;
    }

  quickSort(dSort, pX, pY, 0, count-1);
}


void reOrderPointFPF(int n,vector<double> *a, int* order) {
  double totalDist[n];
  double tempD = 0;
    
  for (int i = 0; i < n; i++) 
    totalDist[i] = 0;
  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(a[i], a[j]);
      totalDist[i] += tempD;
      totalDist[j] += tempD;
    }
  double distToP[n];
  for (int i = 0; i < n; i++)
    distToP[i] = totalDist[i];

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE NEED ORDER ALL
    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {
      if (distToP[i] > maxF) {  // select the point that has max of minDist
	maxF = distToP[i];
	position = i;
      }
    }
    if (p < position) {
      swap(a[p], a[position]);
      swap(order[p], order[position]);
      swap(totalDist[p], totalDist[position]);
      swap(distToP[p], distToP[position]);	  
    }
    // now: update distToP of point p+1 to n
    for (int c = p+1; c < n; c++) {
      double tempD = dist(a[p], a[c]);
      if (distToP[c] > tempD)
	distToP[c] = tempD;
    }
  }
  //cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;
}

void reOrderPointRBBA(int n,vector<double> *a, int* order) {
  // Following Brusco's pseudo code (separate nearest neighbors)
  int first = 0;
  int last = n-1;
  int unassigned = n;
  
  vector<bool> assigned(n, false);
  vector<int> position(n, -1);
  
  while (unassigned > 0) {
    int pos_r = 0;
    int pos_c = 0;
    
    // compute arg min position
    double distmin = INT_MAX;
    for (int c=0; c!=n; c++) { // over column/row to mimic RBBA
      if (not assigned[c]) {
        for (int r=c+1; r!=n; r++) {
          if (not assigned[r]) {
            double d = dist(a[r], a[c]);
            if (d < distmin) {
              distmin = d;
              pos_r = r;
              pos_c = c;
            }
          }
        }
      }
    }
    
    // add to back/front
    position[first++] = pos_c;
    assigned[pos_c] = true;
    position[last--] = pos_r;
    assigned[pos_r] = true;
    
    unassigned -= 2;
    // special case, one left
    if (unassigned == 1) {
      for (int i=0; i!=n; i++) {
        if (not assigned[i]) {
          position[first] = i;
          assigned[i] = true;
          unassigned -= 1;
        }
      }
    }
  }
  
  // do the reordering
  // a, pionter wrangling
  vector<double> *a_bis = new vector<double>[n];
  for (int i=0; i!=n; i++)
    a_bis[i] = a[i];
  for (int i=0; i!=n; i++)
    a[i] = a_bis[position[i]];
  //delete a_bis;
  
  //order, got that already
  for (int i=0; i!=n; i++)
    order[i] = position[i];
  
  //cout << "Reading + ReOrganisation DATA (RBBA) in \t:  " << give_time() - startAll << endl;
}


void reOrderPointFPF_lastK(int n, int k, vector<double> *a, int* order) {

  double totalDist[n];
  double tempD = 0;
    
  for (int i = 0; i < n; i++) 
    totalDist[i] = 0;

  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(a[i], a[j]);
      totalDist[i] += tempD;
      totalDist[j] += tempD;
    }

  double distToP[n];
  for (int i = 0; i < n; i++)
    distToP[i] = totalDist[i];

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL

    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {

      double f = 0; // f(i)	

      if (p > k)
	for (int zz = 1; zz <= k; zz++)
	  f += dist(a[i], a[p-zz]);
      else
	f = distToP[i];
		
		
      if (f > maxF) {		// select the point that is has  max of  minDist
	maxF = f;
	position = i;
      }
    }
	
	
    //	cout << maxF	 << " " << distToP[position] << endl;

    if (p < position) {
      swap(a[p], a[position]);
      swap(order[p], order[position]);
      swap(totalDist[p], totalDist[position]);
      swap(distToP[p], distToP[position]);	  
    }
    // now: update distToP of point p+1 to n
    for (int c = p+1; c < n; c++) {
      double tempD = dist(a[p], a[c]);
      if (distToP[c] > tempD)
	distToP[c] = tempD;
    }


  }

  // calcal D[x][y] = distance between point x and y, distance is integer

  //cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;

}



void reOrderPointVariance(int n, vector<double> *a, int* order) {

  double totalDist[n];
  double tempD = 0;
    
  for (int i = 0; i < n; i++) 
    totalDist[i] = 0;

  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(a[i], a[j]);
      totalDist[i] += tempD * tempD;
      totalDist[j] += tempD * tempD;
    }

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {
      double f = 0; // f(i)				
      double minDist = 0;
      //double maxDist = 0;
      int p1 = n;  // p1 = 3 * k ??
      if (p < p1) p1 = p;
      for (int j = 0; j < p1; j++) { 
	minDist += dist(a[i],a[j]) * dist(a[i],a[j]) ;
      }

      // minDist = min distance from a point to  [point 0, point 1, ... point p-1 ] 
      if (p == 0)   // special case
	f = totalDist[i]; 
      else
	f = minDist;
      if (f > maxF) {		// select the point that is has  max of  minDist
	maxF = f;
	position = i;
      }
    }
    swap(a[p], a[position]);
    swap(order[p], order[position]);
    swap(totalDist[p], totalDist[position]);
  }

  // calcal D[x][y] = distance between point x and y, distance is integer

  //cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;
}

void reOrderPointPoid(int n, vector<double> *a, int* order)  {
  double totalDist[n];
  double tempD = 0;
    
  for (int i = 0; i < n; i++) 
    totalDist[i] = 0;

  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(a[i], a[j]);
      totalDist[i] += tempD;
      totalDist[j] += tempD;
    }

  // here we use our Function to reorder points
  for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL

    // now we find point for position p

    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		

    for (int i = p; i < n; i++) {
      double f = 0; // f(i)				
      double minDist = 100000;
      double maxDist = 0;

      int p1 = n;
      if (p < p1) p1 = p;

      for (int j = 0; j < p1; j++) {  // f(i) = Sum d(i, j) * min/max * (n-p)/p
	double distTemp = dist(a[i], a[j]);
	f += distTemp;	
	if (distTemp < minDist) minDist = distTemp;
	if (distTemp > maxDist) maxDist = distTemp;
      }

      if (p >= 1)
	f = f * (((minDist/maxDist)/p) * (n-p)-1);

      f += totalDist[i];	

      if (f > maxF) {
	maxF = f;
	position = i;
      }
    }
    swap(a[p], a[position]);
    swap(order[p], order[position]);
    swap(totalDist[p], totalDist[position]);
  }
  //cout << "Reading + ReOrganisation DATA (WEIGHT FUNCTION) in \t:  " << give_time() - startAll << endl;
}

void reOrderPointRANDOM(int n, vector<double> *a, int* order){
  for (int i = 0; i < 10000; i++) {
    int x = rand() % n;
    int y = rand() % n;
    swap(a[x], a[y]);
    swap(order[x], order[y]);
  }
  cout << "Randomly reorder point \n";

}

void reOrderPointRevert(int n, vector<double> *a, int* order) {
  for (int i = 0; i < n/2; i++) {
    swap(a[i], a[n-i-1]);
    swap(order[i], order[n-i-1]);
  }
  cout << "Revert reorder point \n";

}

// reorder super-points using FPF on squared distances
void reOrderFPF_SP(int n, double** dist, int* order) {
  double distToP[n];
    
  for (int i = 0; i < n; i++) 
    distToP[i] = 0;
  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      distToP[i] += dist[i][j];
      distToP[j] += dist[i][j];
    }

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE NEED ORDER ALL
    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {
      if (distToP[i] > maxF) {  // select the point that has max of minDist
	maxF = distToP[i];
	position = i;
      }
    }
    if (p < position) {
      swap(order[p], order[position]);
      swap(distToP[p], distToP[position]);
      swap(dist[p],dist[position]);
    }
    // now: update distToP of point p+1 to n
    for (int c = p+1; c < n; c++) {
      if (distToP[c] > dist[p][c])
	distToP[c] = dist[p][c];
    }
  }
  //cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;
}

void buildOrderSP(int n, int* order, int nSP, int* orderSP, int* ccindex) {
  int done[nSP];
  for (int i=0; i<nSP; i++)
    done[i]=0;
  int iSP=0;
  int iP=0;
  while (iP < n) {
    int sp=ccindex[order[iP]];
    if (done[sp]==0) {
      orderSP[iSP]=sp;
      done[sp]=1;
      iSP++;
    }
    iP++;
  }
}

void calculD(int n, int nSmall, int order, double &maxD, double &minD,  vector<double> *a, double** dd) {

  // now we take nSmall instead of n. So we will consider only point n-nSmall to point n-1.
  maxD = 0;
  minD = -1;
	
  if (order==1)
    for (int i = n-nSmall; i < n; i++)
      for (int j = n-nSmall; j < n; j++) {
				
	dd[i - n + nSmall][j - n + nSmall] = dist(a[i], a[j]);
	//					dcarre[i- n + nSmall][j- n + nSmall] = dd[i - n + nSmall][j - n + nSmall] * dd[i - n + nSmall][j - n + nSmall];
	if (dd[i- n + nSmall][j- n + nSmall] > maxD)	
	  maxD = dd[i- n + nSmall][j- n + nSmall];  // max distance between two points
	if (minD == -1 || (i!=j && dd[i- n + nSmall][j- n + nSmall]<minD)) 
	  if (dd[i- n + nSmall][j- n + nSmall] != 0)	// minD > 0
	    minD = dd[i- n + nSmall][j- n + nSmall]; // min distance between two points
      }

  if (order==0)
    for (int i = 0; i < nSmall; i++)
      for (int j = 0; j < nSmall; j++) {
				
	dd[i][j] = dist(a[i], a[j]);
	//					dcarre[i][j] = dd[i][j] * dd[i][j];
	if (dd[i][j] > maxD)	
	  maxD = dd[i][j];  // max distance between two points
	if (minD == -1 || (i!=j && dd[i][j]<minD)) 
	  if (dd[i][j] != 0)	// minD > 0
	    minD = dd[i][j]; // min distance between two points
      }

  cout << maxD << " " << minD << endl;
}


double calculDiameterFPF(int n, int k, double** dd) {
  int group[n];
  int head[k];
  head[0] = 0;
  double diamHeuristic = 0;

  for (int i = 0; i < n; i++) 
    group[i] = head[0];
    

  for (int c = 1; c < k; c++) {
    // find furthest point
    double maxDtoHead = 0;
    int point = 0;
    for (int i = 0; i < n; i++) 
      if (dd[i][group[i]] > maxDtoHead) {
	maxDtoHead = dd[i][group[i]];
	point = i;
      }
    head[c] = point; 
    for (int i = 0; i < n; i++)
      if (dd[i][group[i]] > dd[i][point]) {
	group[i] = point;
      }				
  }

 
  for (int i = 0; i < n; i++)
    for (int j = i+1; j < n; j++)
      if (group[i] == group[j])
	if (diamHeuristic < dd[i][j])
	  diamHeuristic = dd[i][j];
    

  return diamHeuristic;
}



