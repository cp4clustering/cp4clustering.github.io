#ifndef INITFUNCTIONS_H
#define INITFUNCTIONS_H

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"

// read data and do preparations
int readN(const ClusterOptions&);
void readAndOrderData(const ClusterOptions& opt, int nOrigine, 
		      vector<double> *feat, int* order, int* rorder);
void readAndOrderProperties(const ClusterOptions& opt, int nOrigine, 
			    vector<string> *prop, int* rorder);
int constructCC(const ClusterOptions& opt, int nOrigine,
                vector<double> *a, int* rorder,
                vector<int>* cc, int* ccindex) ;
vector<int>* buildCLGraph(const ClusterOptions& opt,int nOrigine,
                          vector<double> *a, int* rorder,
                          int nSP, int* ccindex) ;
void buildOrderSP(int n, int* order, int nSP, int* orderSP, int* rorderSP, int* ccindex, int verbose=0);
vector<double>* computeSS(const ClusterOptions& opt, int nOrigine, int nSP, vector<double> *a, 
			  vector<int>* cc, int* rorder, int* orderSP);
vector<double>* computeMin(const ClusterOptions& opt, int nOrigine, int nSP, vector<double> *a, 
			  vector<int>* cc, int* rorder, int* orderSP);
vector<double>* computeMax(const ClusterOptions& opt, int nOrigine, int nSP, vector<double> *a, 
			   vector<int>* cc, int* rorder, int* orderSP);

void computeGT(const ClusterOptions&, vector<double>* coord, int* clusterGT, int* sizeGT);
double diameter(vector<double>*, int* clusterGT, int);
double split(vector<double>*, int* clusterGT, int);

// for adult dataset
void  printStatsAdult(int nOrigine, vector<string>* prop, int* clusterGT, int* rorder);
double computeRI(int n, int* p1, int* p2);
#endif
