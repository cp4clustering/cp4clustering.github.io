#include <gecode/driver.hh>
#include <gecode/search.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"
#include "initFunctions.h"
#include "cpClusterCC.h"

using namespace Gecode;
using namespace std;


int main(int argc, char* argv[]) {
  srand(time(NULL));
  double startAll=give_time();
  ClusterOptions opt;
  opt.solutions(0);
  opt.parse(argc,argv);
  opt.c_d(1); 
  opt.a_d(1);  // No recomputation, we save all nodes' information
  //        opt.time(2000); // Time limit is 10 minutes
  if (opt.verbose() == 0) {
    opt.out_file("/dev/null");
    opt.log_file("/dev/null");
  }

  int nOrigine=0; // number of points
  int nSP=0; // number of super-points
  vector<double> *feat; // features matrix
  vector<string> *prop; // properties matrix
  int* order; // order[i] is the index of the point at rank i
  int* rorder; // rorder[i] gives the rank of the point i
  vector<int>* cc; // connected components of ML graph
  int* ccindex; // ccindex[i]: index of the connected component containing i
  vector<int>* clgraph; // graph for CL constraints
  int *orderSP; // orderSP[i]=j means G[i] corresponds to super-point j
  int* rorderSP; // rorderSP[i]=j means G[j] corresponds to super-point i
  vector<double> *ddSS; // distance matrice by sum of squares for super-points
  vector<double> *ddMin; // distance matrice by minimal distance for super-points
  vector<double> *ddMax; // distance matrice by maximal distance for super-points
  int* sizeGT; // size of ground truth clusters
  double diamGT; // maximal diameter of ground truth partition
  double splitGT; // minimal split of ground truth partition
  int* clusterGT=NULL; // ground truth partition
  int gt = 0;
  int* instUsed;
  double diamSample=0;
  double splitSample=0;
  
  nOrigine = readN(opt);
  feat =  new vector<double>[nOrigine];
  prop = new vector<string>[nOrigine];
  order = new int[nOrigine];
  rorder = new int[nOrigine];
  cc = new vector<int>[nOrigine];
  ccindex = new int[nOrigine];
  sizeGT = new int[opt.k()];
  clusterGT = new int[nOrigine];
  instUsed = new int[nOrigine];

  int nInst=0;
  vector<int> instances;
  vector<double>* coor = new vector<double>[nOrigine];

  if (!opt.gt().empty() && opt.k() != 0) { // compute statistics from ground truth partition
    int k = opt.k();
    gt = 1;
    computeGT(opt, coor, clusterGT, sizeGT);
    diamGT = diameter(coor, clusterGT, nOrigine);
    splitGT = split(coor, clusterGT, nOrigine);
    if (opt.verbose() >=0 ) {
      cout << "ground truth diameter: "<< diamGT << " split: "<< splitGT<< endl;
      cout << "Size GT: ";
      for (int i=0; i<k; i++)
	cout << sizeGT[i] << ", ";
      cout << endl;
    }
  }

  if (opt.rmlcl() && gt==1 && opt.verbose() >-4) { // a number of random ML/CL required
    int nb = opt.rmlcl();
    opt.setC("rMLCL.txt");
    ofstream f(opt.c().c_str(),ios::out);        
    if (!f.good()) {
      cerr << "Error: could not open file " << opt.c() << endl;
      exit(EXIT_FAILURE);
    }
    for (int i=0; i<nOrigine; i++)
      instUsed[i] = 0;
    for (int i=0; i<nb; i++) {
      int x = rand() % nOrigine;
      int y;
      do {
	y = rand() % nOrigine;
      } while (y==x);
      if (clusterGT[x] == clusterGT[y]) // ML constraint
	f << x << "  " << y << "  " << 1 << endl;
      else // CL constraint
	f << x << "  " << y << "  " << -1 << endl;
      instUsed[x] = 1;
      instUsed[y] = 1;
    }
    f.close();
  }
      
  // data ordered by distance
  readAndOrderData(opt, nOrigine, feat, order, rorder);
  // read properties
  readAndOrderProperties(opt, nOrigine, prop, rorder);
  // here feat has been changed such that feat[i] is for the i-th point in 'order'

  // new version of verbose=-2, compute min size
  if (opt.verbose() ==-2) { // create cluster level constraints
    int k= opt.k();
    vector<int> clusSizeS(k,0);
    nInst = 0;
    for (int i=0; i<nOrigine; i++)
      if (instUsed[i] == 1) {
	clusSizeS[clusterGT[i]]++;
	nInst ++;
      }
    int minS=clusSizeS[0];
    cout << "cluster sample size: ";
    for (int c=0; c<k;c++)
      cout << clusSizeS[c] << ", ";
    cout << endl;
    for (int c=1; c<k; c++)
      if (minS > clusSizeS[c])
	minS = clusSizeS[c];
    cout << "min size " << minS << " --> ";
    minS = minS*nOrigine*0.9/nInst;
    cout  << minS << endl;
    opt.setSizeMin(minS);
    // compute diameter and split of the sample
    for (int i=0; i<nOrigine; i++)
      if (instUsed[i] == 1) 
	for (int j=i+1; j<nOrigine; j++)
	  if (instUsed[j] == 1) {
	    double d = dist(coor[i],coor[j]);
	    if (clusterGT[i] == clusterGT[j] && diamSample<d)
	      diamSample = d;
	    else if (clusterGT[i] != clusterGT[j] &&
		     (splitSample==0 || splitSample>d))
	      splitSample = d;
	  }
  }
  
  // construct ML-blocks and CL graph
  // cc and ccindex based on original order
  nSP=constructCC(opt,nOrigine,feat,rorder,cc,ccindex); 
  clgraph=buildCLGraph(opt,nOrigine,feat,rorder,nSP,ccindex);


  // build order on super-points
  orderSP = new int[nSP];
  rorderSP = new int[nSP];
  buildOrderSP(nOrigine,order,nSP,orderSP,rorderSP,ccindex,opt.verbose());

  // compute distances for super-points
  ddSS = computeSS(opt, nOrigine, nSP, feat, cc, rorder, orderSP);
  ddMin = computeMin(opt, nOrigine, nSP, feat, cc, rorder, orderSP);
  ddMax = computeMax(opt, nOrigine, nSP, feat, cc, rorder, orderSP);

  
  if (opt.verbose() >= 1)
    cout << "preparation: " << give_time() - startAll << endl;

  // for BAB<> (must be _Search::_Options)
  Search::Options sopt;
  sopt.threads = opt.threads();
  sopt.c_d = opt.c_d();
  sopt.a_d = opt.a_d();
  sopt.nogoods_limit = opt.nogoods_limit();
  
  // call CP model for n points
  if (opt.verbose() > -2) {
    CPClusterCC* m = new CPClusterCC(opt,true,nOrigine,nSP,ddSS,ddMin,ddMax,
				     orderSP, rorderSP, clgraph,
				     cc, rorder, ccindex, feat, prop);
    BAB<CPClusterCC> e(m,sopt);
    delete m;
    int sols=0;
    CPClusterCC* best=NULL;
    while (CPClusterCC* s = e.next()) {
      sols++;
      if (best) // delete previous solution
	delete best; 
      best = s;
      //s->print();
      if (gt == 1)
	cout << "RI: " << s->computeRI(nOrigine, clusterGT, ccindex, rorderSP) 
	     << endl;
      cout << s->objValue() << "  " << give_time()-startAll << endl;
      if (opt.verbose()>=1) {
	s->computeSize(cc, orderSP);
	  
      }
    }
    // print the best solution
    if (best) {
      best->print();
      best->computeSize(cc, orderSP);
      //if (opt.ucase() > 0)
      //best->printStats(nOrigine, prop, ccindex, rorderSP, rorder);
      if (gt == 1)
	cout << "RI: " << best->computeRI(nOrigine, clusterGT, ccindex, rorderSP) 
	     << endl;
      // create files that contain final partition
      best->savePartitionFile(nOrigine, ccindex, rorderSP);
    }

    if (opt.verbose() >= 0) {
      Search::Statistics stats = e.statistics();
      cout << "Time: " << give_time() - startAll << ", s/f: " 
	   << sols << "/" << stats.fail << ", nodes: " << stats.node 
	   << ", props: " << stats.propagate << endl;
    }

  } else if (opt.verbose()==-2) { 
    // mode for experiments same set of ML/CL without/with cluster level constraint
    double ri1 = 0;
    double ri2 = 0;
    // first call CPCluster with only ML/CL constraints
    CPClusterCC* m1 = new CPClusterCC(opt,false,nOrigine,nSP,ddSS,ddMin,ddMax,
				      orderSP, rorderSP, clgraph,
				      cc, rorder, ccindex, feat, prop);
    BAB<CPClusterCC> e1(m1,sopt);
    delete m1;
    while (CPClusterCC* s = e1.next()) {
      if (gt == 1)
	ri1 = s->computeRI(nOrigine, clusterGT, ccindex, rorderSP);
      delete s;
    }
    // second call CPCluster with all user constraints
    CPClusterCC* m2 = new CPClusterCC(opt,true,nOrigine,nSP,ddSS,ddMin,ddMax,
				      orderSP, rorderSP, clgraph,
				      cc, rorder, ccindex, feat, prop);
    BAB<CPClusterCC> e2(m2,sopt);
    delete m2;
    while (CPClusterCC* s = e2.next()) {
      if (gt == 1)
	ri2 = s->computeRI(nOrigine, clusterGT, ccindex, rorderSP);
      delete s;
    }
    //cout << diamSample << " " << splitSample << endl;
    cout << ri1 << " " << ri2 << endl;
  } else  if (opt.verbose()==-3) { // pen digits experiments
    double time1=give_time();

    vector<int> partition1(nOrigine,0);
    vector<int> partition2(nOrigine,0);
    vector<int> partition3(nOrigine,0);
    cout << "Pen digits without constraint:" << endl;
    opt.setUC(-1);
    CPClusterCC* m = new CPClusterCC(opt,true,nOrigine,nSP,ddSS,ddMin,ddMax,
				     orderSP, rorderSP, clgraph,
				     cc, rorder, ccindex, feat, prop);
    BAB<CPClusterCC> e(m,sopt);
    delete m;
    CPClusterCC* best=NULL;
    while (CPClusterCC* s = e.next()) {
      if (best) // delete previous solution
	delete best; 
      best = s;
    }
    // print the best solution
    if (best) {
      best->print();
      best->computeSize(cc, orderSP);
      best->savePartition(nOrigine, partition1, ccindex, rorderSP);
      cout << "Time: " << give_time()-time1 << endl;
    }
    // compute diamter on the horizontal 3rd and 5th coordinates
    int k=opt.k();
    vector<double> diam3(k,0);
    vector<double> diam5(k,0);
    for (int i=0; i<nOrigine; i++)
      for (int j=i+1; j<nOrigine; j++)
	if (partition1[i] == partition1[j]) {
	  if (abs(feat[rorder[i]][4]-feat[rorder[j]][4]) > diam3[partition1[i]])
	    diam3[partition1[i]] = abs(feat[rorder[i]][4]-feat[rorder[j]][4]);
	  if (abs(feat[rorder[i]][8]-feat[rorder[j]][8]) > diam5[partition1[i]])
	    diam5[partition1[i]] = abs(feat[rorder[i]][8]-feat[rorder[j]][8]);
	}
    double maxdiam3=0;
    double maxdiam5=0;
    for (int c=0; c<k; c++) {
      if (maxdiam3 < diam3[c])
	maxdiam3 = diam3[c];
      if (maxdiam5 < diam5[c])
	maxdiam5 = diam5[c];
    }
    cout << "diam 3rd point: " << maxdiam3 << endl;
    cout << "diam 5th point: " << maxdiam5 << endl;
    // solution with a diameter constraint on the 3rd coordinate
    time1=give_time();
    cout << "Pen digits with a diameter on 3rd coordinate constraint:" << endl;
    opt.setDiam(maxdiam3*1/2);
    opt.setUC(4);
    CPClusterCC* m2 = new CPClusterCC(opt,true,nOrigine,nSP,ddSS,ddMin,ddMax,
				     orderSP, rorderSP, clgraph,
				     cc, rorder, ccindex, feat, prop);
    BAB<CPClusterCC> e2(m2,sopt);
    delete m2;
    CPClusterCC* best2=NULL;
    while (CPClusterCC* s = e2.next()) {
      if (best2) // delete previous solution
	delete best2; 
      best2 = s;
    }
    // print the best solution
    if (best2) {
      best2->print();
      best2->computeSize(cc, orderSP);
      best2->savePartition(nOrigine, partition2, ccindex, rorderSP);
      cout  << "Time:  " << give_time()-time1 << endl;
    }
    // solution with a diameter constraint on the 5th coordinate
    time1 = give_time();
    cout << "Pen digits with a diameter on 5th coordinate constraint:" << endl;
    opt.setDiam(maxdiam5*1/2);
    opt.setUC(8);
    CPClusterCC* m3 = new CPClusterCC(opt,true,nOrigine,nSP,ddSS,ddMin,ddMax,
				     orderSP, rorderSP, clgraph,
				     cc, rorder, ccindex, feat, prop);
    BAB<CPClusterCC> e3(m3,sopt);
    delete m3;
    CPClusterCC* best3=NULL;
    while (CPClusterCC* s = e3.next()) {
      if (best3) // delete previous solution
	delete best3; 
      best3 = s;
    }
    // print the best solution
    if (best3) {
      best3->print();
      best3->computeSize(cc, orderSP);
      best3->savePartition(nOrigine, partition3, ccindex, rorderSP);
      cout << "Time: " <<  give_time()-time1 << endl;
    }

        // compute diamter on the 3rd and 5th coordinates
      vector<double> diam32(k,0);
    vector<double> diam52(k,0);
    for (int i=0; i<nOrigine; i++)
      for (int j=i+1; j<nOrigine; j++)
	if (partition2[i] == partition2[j]) {
	  if (abs(feat[rorder[i]][4]-feat[rorder[j]][4]) > diam32[partition2[i]])
	    diam32[partition2[i]] = abs(feat[rorder[i]][4]-feat[rorder[j]][4]);
	  if (abs(feat[rorder[i]][8]-feat[rorder[j]][8]) > diam52[partition2[i]])
	    diam52[partition2[i]] = abs(feat[rorder[i]][8]-feat[rorder[j]][8]);
	}
    double maxdiam32=0;
    double maxdiam52=0;
    for (int c=0; c<k; c++) {
      if (maxdiam32 < diam32[c])
	maxdiam32 = diam32[c];
      if (maxdiam52 < diam52[c])
	maxdiam52 = diam52[c];
    }
    cout << "case 2 diam 3rd point: " << maxdiam32 << endl;
    cout << "case 2 diam 5th point: " << maxdiam52 << endl;

    vector<double> diam33(k,0);
    vector<double> diam53(k,0);
    for (int i=0; i<nOrigine; i++)
      for (int j=i+1; j<nOrigine; j++)
	if (partition3[i] == partition3[j]) {
	  if (abs(feat[rorder[i]][4]-feat[rorder[j]][4]) > diam33[partition3[i]])
	    diam33[partition3[i]] = abs(feat[rorder[i]][4]-feat[rorder[j]][4]);
	  if (abs(feat[rorder[i]][8]-feat[rorder[j]][8]) > diam53[partition2[i]])
	    diam53[partition3[i]] = abs(feat[rorder[i]][8]-feat[rorder[j]][8]);
	}
    double maxdiam33=0;
    double maxdiam53=0;
    for (int c=0; c<k; c++) {
      if (maxdiam33 < diam33[c])
	maxdiam33 = diam33[c];
      if (maxdiam53 < diam53[c])
	maxdiam53 = diam53[c];
    }
    cout << "case 3 diam 3rd point: " << maxdiam33 << endl;
    cout << "case 3 diam 5th point: " << maxdiam53 << endl;

  
    // compute centroids
    vector< vector<double> > centroid1(k), centroid3(k), centroid5(k);
    vector<int> size1(k,0), size3(k,0), size5(k,0);
    for (int i=0; i<k; i++) {
      centroid1[i] = vector<double>(16,0);
      centroid3[i] = vector<double>(16,0);
      centroid5[i] = vector<double>(16,0);
    }
    for (int i=0; i<nOrigine; i++) {
      size1[partition1[i]]++;
      size3[partition2[i]]++;
      size5[partition3[i]]++;
      for (int j=0; j<16; j++) {
	int rang=rorder[i];
	centroid1[partition1[i]][j] += feat[rang][j];
	centroid3[partition2[i]][j] += feat[rang][j];
	centroid5[partition3[i]][j] += feat[rang][j];
      }
    }
    for (int c=0; c<k; c++)
      for (int j=0; j<16; j++) {
	centroid1[c][j] = centroid1[c][j]/size1[c];
	centroid3[c][j] = centroid3[c][j]/size3[c];
	centroid5[c][j] = centroid5[c][j]/size5[c];
    }
    ofstream fout(opt.output(),ios::out);        
    if (!fout.good()) {
      cerr << "Error: could not open file centroids.txt" << endl;
      exit(EXIT_FAILURE);
    }
    fout << "Centroids without constraints" << endl;
    for (int c=0; c<k; c++) {
      fout << "Cluster " << c << ":" << endl;
      for (int j=0; j<16; j++)
	fout << centroid1[c][j] << "  ";
      fout << endl;
    }
    fout << "Centroids with diameter constraint on 3rd coor" << endl;
    for (int c=0; c<k; c++) {
      fout << "Cluster " << c << ":" << endl;
      for (int j=0; j<16; j++)
	fout << centroid3[c][j] << "  ";
      fout << endl;
    }
    fout << "Centroids with diameter constraint on 5th coor" << endl;
    for (int c=0; c<k; c++) {
      fout << "Cluster " << c << ":" << endl;
      for (int j=0; j<16; j++)
	fout << centroid5[c][j] << "  ";
      fout << endl;
    }
    fout.close();
  }

  ofstream f(opt.c().c_str(),ios::out);        
  f.close();
  delete[] coor;
  remove("rMLCL.txt");
  return 0;
}

