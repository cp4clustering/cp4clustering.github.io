#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stack>    
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "splitConstraint.h"

using namespace Gecode;
using namespace std;



// propagation
ExecStatus SplitConstraint::propagate(Space& home, const ModEventDelta& med)  {
  int n = x.size(); // there is n point
  if (Float::FloatView::me(med) == Float::ME_FLOAT_BND) 
    // see if change in lower bound
    if (lb < y.min()) {
      //cout << "change lb:" << lb << " to " << y.min() << endl;
      lb = y.min();
      while ( !changedPoints.empty() ) // empty the stack
	changedPoints.pop();
      for (int i = 0; i < n; i++)
	changedPoints.push(i);				
    }
		
  while (!changedPoints.empty()) {
    int i = changedPoints.top();
    changedPoints.pop();
    for (int j = 0; j < n; j++) {
      if (j!=i && dd[i][j] <= y.min())  { // x[i] and x[j] must be equal
	//cout << "change in " << i << "," << j << endl;
	Int::ViewRanges<Int::IntView> ri(x[i]);
	GECODE_ME_CHECK(x[j].inter_r(home,ri,false));
	Int::ViewRanges<Int::IntView> rj(x[j]);
	GECODE_ME_CHECK(x[i].narrow_r(home,rj,false));
      }
      if (x[i].assigned() && x[j].assigned() && x[i].val() != x[j].val()) {
	//cout << "change bound with " << i << "," << j << endl;
	GECODE_ME_CHECK(y.lq(home, dd[i][j]));   
      }
    }
  }
  return ES_FIX;
}


void splitConstraint(Home home, IntVarArgs x, FloatVar y, vector<double>* dd) {
  if (home.failed()) return;
  ViewArray<Int::IntView> vx(home, x);
  Float::FloatView vy(y);
  GECODE_ES_FAIL(SplitConstraint::post(home,vx,vy,dd));
}

