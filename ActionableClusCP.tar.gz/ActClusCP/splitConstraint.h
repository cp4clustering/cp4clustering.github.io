#ifndef SPLIT_CONSTRAINT
#define SPLIT_CONSTRAINT

#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stack>    
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class SplitConstraint : public Propagator {
protected:

  class ViewAdvisor : public Advisor {
  public:
    Int::IntView x;
    int index;

    ViewAdvisor(Space& home, Propagator& p, 
		Council<ViewAdvisor>& c, Int::IntView x0, int index0) 
      : Advisor(home,p,c), x(x0), index(index0) {
      x.subscribe(home, *this);
    }

    ViewAdvisor(Space& home, bool share, ViewAdvisor& a)
      : Advisor(home,share,a), index(a.index) {
      x.update(home,share,a.x);
    }

    void dispose(Space& home, Council<ViewAdvisor>& c) {
      x.cancel(home, *this);
      Advisor::dispose(home,c);
    }
  };

  Council<ViewAdvisor> c;
  ViewArray<Int::IntView> x; // G
  Float::FloatView y; // S
  stack<int> changedPoints;
  vector<double>* dd;
  double lb;

public:
  // posting
 SplitConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0, vector<double>* mat) 	
   : Propagator(home), c(home), x(x0), y(y0), dd(mat), lb(0)  {
    for (int i=x.size(); i--; )
      (void) new (home) ViewAdvisor(home,*this,c,x[i], i);
    y.subscribe(home,*this,Float::PC_FLOAT_BND);
    home.notice(*this,AP_DISPOSE);
  }
  static ExecStatus post(Home home, 
			 ViewArray<Int::IntView>& x0, Float::FloatView y0, vector<double>* mat) {
    (void) new (home) SplitConstraint(home,x0,y0,mat);
    return ES_OK;
  }
  // disposal
  virtual size_t dispose(Space& home) {
    c.dispose(home);
    y.cancel(home,*this,Float::PC_FLOAT_BND);
    (void) Propagator::dispose(home);
    return sizeof(*this);
  }

  // copying
  SplitConstraint(Space& home, bool share, SplitConstraint& p) 
    : Propagator(home,share,p), dd(p.dd), lb(p.lb) {
    x.update(home, share, p.x);
    y.update(home, share, p.y);
    c.update(home,share,p.c);
  }
  virtual Propagator* copy(Space& home, bool share) {
    return new (home) SplitConstraint(home,share,*this);
  }

  // cost computation
  virtual PropCost cost(const Space&, const ModEventDelta&) const {
    return PropCost::binary(PropCost::HI);
  }


  // advise function
  virtual ExecStatus advise(Space&, Advisor& a, const Delta& d) {
    //cout << "Add point " << static_cast<ViewAdvisor&>(a).index << endl;
    changedPoints.push(static_cast<ViewAdvisor&>(a).index); // add point i, even if i is not fixed
    // always active the propagateur			
    return ES_NOFIX;
  }


  // propagation
  virtual ExecStatus propagate(Space& home, const ModEventDelta&);


};

void splitConstraint(Home, IntVarArgs, FloatVar, vector<double>*);

#endif
