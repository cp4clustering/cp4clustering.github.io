#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include <limits>
#include "clusterOptions.h"
#include "commonFunction.h"
#include "initFunctions.h"


int readN(const ClusterOptions& opt) {
  ifstream fin(opt.f().c_str(),ios::in);        // read file
  if (!fin.good()) {
    cerr << "Error: could not read data file " << opt.f() << ".\n";
    exit(EXIT_FAILURE);
  }
  // read n from the first line
  int nOrigine;
  string line;
  getline(fin,line);   
  istringstream iss(line);
  iss >> nOrigine;
  if (opt.n() > 0)
    nOrigine = opt.n();
  fin.close();
  return nOrigine;
} 


void dfsVisit(int i, vector<int>* graph, vector<int>* cc, int* ccindex, int nSP) {
  ccindex[i]=nSP;
  cc[nSP].push_back(i);
  for (unsigned j=0; j<graph[i].size(); j++) {
    int u=graph[i][j];
    if (ccindex[u]==-1)
      dfsVisit(u, graph, cc, ccindex, nSP);
  }
}



// construct connected components on must-link graph
int constructCC(const ClusterOptions& opt, int nOrigine,
                vector<double> *a, int* rorder,
                vector<int>* cc, int* ccindex) {
  vector<int>* mlgraph=new vector<int>[nOrigine];
  if (!opt.c().empty()) { // there are ML/CL from file
    const char* fname=opt.c().c_str();
    ifstream fmlcl(fname, ios::in);
    if (!fmlcl.good()) {
      cerr << "Error: could not read constraint file " << opt.c() << ".\n";
      exit(EXIT_FAILURE);
    }
    // read ML constraints from file
    int x,y,z;
    while  (fmlcl >> x >> y >> z) {
      if (z==1 && x<nOrigine && y<nOrigine) { // ML constraint
	mlgraph[x].push_back(y);
	mlgraph[y].push_back(x);
      }
    }
    fmlcl.close();
  }

  if (opt.split()>0) { // add ML constraints created by a split constraint
    for (int i=0; i<nOrigine; i++) 
      for (int j=i+1; j<nOrigine; j++)
	if (dist(a[rorder[i]], a[rorder[j]]) < opt.split()) {
	  mlgraph[i].push_back(j);
	  mlgraph[j].push_back(i);
	}
  }

  // create ML-blocks
  int nSP=0;
  for (int i=0; i<nOrigine; i++)
    ccindex[i]=-1;

  for (int i=0; i<nOrigine; i++) 
    if (ccindex[i]==-1) { // point i is not reached 
      dfsVisit(i,mlgraph,cc,ccindex,nSP);
      nSP++;
    }
  if (opt.verbose() >= 2) {
    cout << "Connected components: " << endl;
    for (int i=0; i< nSP; i++) {
      cout << i << ": ";
      for (unsigned j=0; j<cc[i].size(); j++)
        cout << cc[i][j] << "  ";
      cout << endl;
    }
  }
  if (opt.verbose() >= 0)
    cout << "number of super-points: " << nSP << endl;

  return nSP;
}

// build Cannot-link graph on ML-blocks
// each CL is on two ML-blocks
vector<int>* buildCLGraph(const ClusterOptions& opt,int nOrigine,
                          vector<double> *a, int* rorder,
                          int nSP, int* ccindex) {
  vector<int>* clgraph=new vector<int>[nSP];
  if (!opt.c().empty()) { // there are ML/CL constraints in file
    const char* fname=opt.c().c_str();
    ifstream fmlcl(fname, ios::in);
    int x,y,z,xSP,ySP;
    while  (fmlcl >> x >> y >> z) {
      if (z==-1 && x<nOrigine && y<nOrigine) { // CL constraint
	xSP=ccindex[x]; // super-point containing x
	ySP=ccindex[y]; // super-point containing y
	clgraph[xSP].push_back(ySP);
	clgraph[ySP].push_back(xSP);
      }
    }
    fmlcl.close();
  }

  if (opt.diam()>0) {
    if (opt.attr()==-1) { // there are CL created by diameter constraint
      cout << "diameter <= " << opt.diam() << endl;
      for (int i=0; i<nOrigine; i++)
	for (int j=i+1; j<nOrigine; j++)
	  if (dist(a[rorder[i]],a[rorder[j]]) > opt.diam()) {
	    int iSP=ccindex[i];
	    int jSP=ccindex[j];
	    clgraph[iSP].push_back(jSP);
	    clgraph[jSP].push_back(iSP);
	  }
    } else { // diameter constraint on one attribute
      int att=opt.attr();
      cout << "diameter <= " << opt.diam() << "on attribute " << att << endl;
      for (int i=0; i<nOrigine; i++)
	for (int j=i+1; j<nOrigine; j++)
	  if (abs(a[rorder[i]][att]-a[rorder[j]][att]) > opt.diam()) {
	    int iSP=ccindex[i];
	    int jSP=ccindex[j];
	    clgraph[iSP].push_back(jSP);
	    clgraph[jSP].push_back(iSP);
	  }
    }
  }

  return clgraph;
}


// read data and do preparations
void readAndOrderData(const ClusterOptions& opt, int nOrigine, 
          vector<double> *a, int* order, int* rorder) {
  ifstream fin(opt.f().c_str(),ios::in);       
  if (!fin.good()) {
    cerr << "Error: could not read data file " << opt.f() << ".\n";
    exit(EXIT_FAILURE);
  }
   
  int k = opt.k();  
  // pass through the first line
  string line;
  getline(fin,line);   

  if (opt.datatype() == 0) // data given by points
    readData(nOrigine, fin, a); // read all attributs of points to A
  fin.close();

  //_______RE ORDERING POINT________________________________________________

  for (int i=0; i<nOrigine; i++)
    order[i] =i;

  if (opt.datatype() == 0) // only when data is read in normal form
    switch (opt.order()) {
    case 0:
      cout << "No Ordering Points" << endl;
      break;
    case 1:
      reOrderPointFPF_lastK(nOrigine, k, a, order);
      break;
    case 2: // which is default value for opt.order()
      reOrderPointFPF(nOrigine, a, order);
      break;
    case 3:
      reOrderPointRANDOM(nOrigine, a, order);
      break;        
    case 4:
      reOrderPointVariance(nOrigine, a, order);
      break;        
    case 5:
      reOrderPointRBBA(nOrigine, a, order);
      break;
    }

  // build reverse order
  for (int i=0; i<nOrigine; i++)
    rorder[order[i]]=i;

  if (opt.verbose() >= 1) {
    cout << "Order on points: [ ";
    for (int i=0; i!=nOrigine; i++) {
      cout << order[i] << " "; // +1 for comparison with RBBA
    }
    cout << "]" << endl;
  }

  //-----END RE ORDERING POINT----------------------------------
}

void readAndOrderProperties(const ClusterOptions& opt, int nOrigine, 
			    vector<string> *prop, int* rorder){
  ifstream fin(opt.p().c_str(),ios::in);        // read file
  if (!fin.good()) {
    cerr << "Error: could not read property file " << opt.p() << ".\n";
    exit(EXIT_FAILURE);
  }
   
  // pass through the first line
  string line;
  getline(fin,line);   
  istringstream iss(line);
  int n;
  iss >> n;
  if (n != nOrigine) {
    cerr << "Error: not the same number of objects in feature and in property files." << endl;
    exit(EXIT_FAILURE);
  }
  for (int i = 0; i < n; i++)  {
    int newI = rorder[i]; // new index according to 'order'
    string line;
    getline(fin,line);   
    istringstream iss(line);
    string value;
    while ( iss >> value ) 
      prop[newI].push_back(value);
    if (i>0 && prop[newI].size()!=prop[rorder[0]].size()) {
      cerr << i << " Error: property lines don't have the same size.\n";
      exit(EXIT_FAILURE);
    }
  }  
  fin.close();
}


vector<double>* computeSS(const ClusterOptions& opt,
			  int nOrigine, int nSP, vector<double> *a, 
			  vector<int>* cc, int* rorder, int* orderSP) {
  vector<double>* ddFull = new vector<double>[nSP];
  for (int i=0; i<nSP; i++)
    for (int j=0; j<nSP; j++) 
      if (i<=j) {
	int iSP = orderSP[i]; // iSP number of super-point at position i
	int jSP = orderSP[j];
	double d=0;
	int pu,pv;
	for (unsigned u=0; u<cc[iSP].size(); u++)
	  for (unsigned v=0; v<cc[jSP].size(); v++) {
	    // array a has been swapped by reordering, need new indices
	    pu=cc[iSP][u];
	    pv=cc[jSP][v];
	    d += distSquare(a[rorder[pu]],a[rorder[pv]]); 
	  }
	if (i==j)
	  d = d/2; // since each distance is counted twice
	ddFull[i].push_back(d);
      } else
	ddFull[i].push_back(ddFull[j][i]);

  return ddFull;
}

vector<double>* computeMin(const ClusterOptions& opt,
			  int nOrigine, int nSP, vector<double> *a, 
			   vector<int>* cc, int* rorder, int* orderSP) {
  vector<double>* ddMin = new vector<double>[nSP];
  for (int i=0; i<nSP; i++)
    for (int j=0; j<nSP; j++) 
      if (i<=j) {
	int iSP = orderSP[i]; // iSP number of super-point at position i
	int jSP = orderSP[j];
	double d=std::numeric_limits<double>::max();
	int pu,pv;
	for (unsigned u=0; u<cc[iSP].size(); u++)
	  for (unsigned v=0; v<cc[jSP].size(); v++) {
	    // array a has been swapped by reordering, need new indices
	    pu=cc[iSP][u];
	    pv=cc[jSP][v];
	    if (d > dist(a[rorder[pu]],a[rorder[pv]]))
	      d = dist(a[rorder[pu]],a[rorder[pv]]); 
	  }
	ddMin[i].push_back(d);
      } else
	ddMin[i].push_back(ddMin[j][i]);

  return ddMin;
}

vector<double>* computeMax(const ClusterOptions& opt,
			  int nOrigine, int nSP, vector<double> *a, 
			   vector<int>* cc, int* rorder, int* orderSP) {
  vector<double>* ddMax = new vector<double>[nSP];
  for (int i=0; i<nSP; i++)
    for (int j=0; j<nSP; j++) 
      if (i<=j) {
	int iSP=orderSP[i];
	int jSP = orderSP[j];
	double d=0;
	int pu,pv;
	for (unsigned u=0; u<cc[iSP].size(); u++)
	  for (unsigned v=0; v<cc[jSP].size(); v++) {
	    // array a has been swapped by reordering, need new indices
	    pu=cc[iSP][u];
	    pv=cc[jSP][v];
	    if (d < dist(a[rorder[pu]],a[rorder[pv]]))
	      d = dist(a[rorder[pu]],a[rorder[pv]]); 
	  }
	ddMax[i].push_back(d);
      } else
	ddMax[i].push_back(ddMax[j][i]);

  return ddMax;
}

void buildOrderSP(int n, int* order, int nSP, int* orderSP, int* rorderSP, int* ccindex, int verbose) {
  int done[nSP];
  for (int i=0; i<nSP; i++)
    done[i]=0;
  int iSP=0;
  int iP=0;
  while (iP < n) {
    int sp=ccindex[order[iP]];
    if (done[sp]==0) {
      orderSP[iSP]=sp;
      done[sp]=1;
      iSP++;
    }
    iP++;
  }
  
  // compute reverse order of super-points
  for (int i=0; i!=nSP; i++)
    rorderSP[orderSP[i]] = i;
  
  if (verbose >= 1) {
    cout << "Order in super-points: [ ";
    for (int i=0; i!=nSP; i++) {
      cout << orderSP[i] << " "; // +1 for comparison with RBBA
    }
    cout << "]" << endl;
  }
  
}

void computeGT(const ClusterOptions& opt, vector<double>* coor, 
	       int* clusterGT, int* sizeGT) {
  ifstream fin(opt.gt().c_str(),ios::in);        // read file
  if (!fin.good()) {
    cerr << "Error: could not read ground truth file " << opt.f() << ".\n";
    exit(EXIT_FAILURE);
  }
  int k = opt.k();
  int n;
  string line;
  getline(fin,line);   
  istringstream iss(line);
  iss >> n;
  for (int i=0; i<k; i++)
    sizeGT[i] = 0;
  for (int i = 0; i < n; i++)  {        
    getline(fin,line);   
    istringstream iss(line);
    double value;
    iss >> clusterGT[i]; // number of clusters begins from 1
    clusterGT[i] -= 1; // number of clusters starts from 0
    sizeGT[clusterGT[i]] ++;
    while ( iss >> value ) 
      coor[i].push_back(value);
    if (i>0 && coor[i].size()!=coor[i-1].size()) {
      cerr << "Error: ground truth data don't have the same size.\n";
      exit(EXIT_FAILURE);
    }
  }
  fin.close();
}

double diameter(vector<double>* coor, int* clusterGT, int n) {
 // compute diameter
  double diamGT = 0;
  double d=0;
  for (int i=0; i<n; i++)
    for (int j=i+1; j<n; j++) 
      if (clusterGT[i] == clusterGT[j]) {
	d = dist(coor[i], coor[j]);
	if (diamGT < d)
	  diamGT = d;
      }
  return diamGT;
}

double split(vector<double>* coor, int* clusterGT, int n) {
 // compute diameter
  double splitGT = 0;
  double d=0;
  for (int i=0; i<n; i++)
    for (int j=i+1; j<n; j++) 
      if (clusterGT[i] != clusterGT[j]) {
	d = dist(coor[i], coor[j]);
	if (splitGT==0 || splitGT > d)
	  splitGT = d;
      }
  return splitGT;
}

void  printStatsAdult(int nOrigine, vector<string>* prop, 
		      int* clusterGT, int* rorder) {
  // number of males, females
  // max/min income
  // --> can be done by Weka
}

double computeRI(int n, int* p1, int* p2) {
  double ri = 0;
  int a = 0;
  int b = 0;
  for (int i=0; i<n; i++)
    for (int j=i+1; j<n; j++) {
      if (p1[i]==p1[j] && p2[i]==p2[j])
	a++;
      else if (p1[i]!=p1[j] && p2[i]!=p2[j])
	b++;
    }
  ri = ((double)(a+b)*2) / ((n-1)*n);
  return ri;
}

