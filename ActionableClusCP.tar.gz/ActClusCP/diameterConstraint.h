#ifndef DIAMETER_CONSTRAINT
#define DIAMETER_CONSTRAINT

#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stack>    
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 

using namespace Gecode;
using namespace std;

class DiameterConstraint : public Propagator {
protected:

  class ViewAdvisor : public Advisor {
  public:
    Int::IntView x;
    int index;

    // The constraint is activated each time there is changement in G or Dmax
    ViewAdvisor(Space& home, Propagator& p, 
		Council<ViewAdvisor>& c, Int::IntView x0, int index0) 
      : Advisor(home,p,c), x(x0), index(index0) {
      x.subscribe(home, *this);
    }

    ViewAdvisor(Space& home, bool share, ViewAdvisor& a)
      : Advisor(home,share,a), index(a.index) {
      x.update(home,share,a.x);
    }

    void dispose(Space& home, Council<ViewAdvisor>& c) {
      x.cancel(home, *this);
      Advisor::dispose(home,c);
    }
  };

  Council<ViewAdvisor> c;
  ViewArray<Int::IntView> x; // G
  Float::FloatView y; // D
  vector<double>* dd; // distance matrice
  stack<int> fixedPoints; // keeps indices of just assigned variables
  double ub;

public:
  // posting the constraint
 DiameterConstraint(Home home, ViewArray<Int::IntView>& x0, Float::FloatView y0, vector<double>* mat) 
   : Propagator(home), c(home),  x(x0), y(y0), dd(mat), ub(Float::Limits::max) {
    for (int i=x0.size(); i--;) {
      (void) new (home) ViewAdvisor(home,*this,c,x0[i], i);	
    }
    y.subscribe(home,*this,Float::PC_FLOAT_BND);
    home.notice(*this,AP_DISPOSE);
  }

  static ExecStatus post(Home home, ViewArray<Int::IntView>& x, Float::FloatView y, vector<double>* mat) {
    // test if a super point has its distance more than y.max()
    for (int i=0; i<x.size(); i++)
      if (mat[i][i] >= y.max())
	return ES_FAILED;
    (void) new (home) DiameterConstraint(home,x,y,mat);
    return ES_OK;
  }

  // disposal
  virtual size_t dispose(Space& home) {
    c.dispose(home);
    y.cancel(home,*this,Float::PC_FLOAT_BND);
    (void) Propagator::dispose(home);
    return sizeof(*this);
  }

  // copying
  DiameterConstraint(Space& home, bool share, DiameterConstraint& p) 
    : Propagator(home,share,p), dd(p.dd), ub(p.ub) {
    x.update(home, share, p.x);
    y.update(home, share, p.y);
    c.update(home,share,p.c);
  }

  virtual Propagator* copy(Space& home, bool share) {
    return new (home) DiameterConstraint(home,share,*this);
  }

  // cost computation
  virtual PropCost cost(const Space&, const ModEventDelta&) const {
    return PropCost::binary(PropCost::HI);
  }


  // advise function to know what variables are changed 
  // this function is called whenever there are change on G
  virtual ExecStatus advise(Space&, Advisor& a, const Delta& d) {
    //	put every new assigned points to stack fixedPoints
    if (static_cast<ViewAdvisor&>(a).x.assigned()) {			
      fixedPoints.push(static_cast<ViewAdvisor&>(a).index);
    }
    // always active the propagateur			
    return ES_NOFIX;
  }


  // propagation
  virtual ExecStatus propagate(Space& home, const ModEventDelta&);
};

void diameterConstraint(Home, IntVarArgs, FloatVar, vector<double>* );


#endif
