#ifndef CLUSTER_OPTION
#define CLUSTER_OPTION
#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include <stack>  

using namespace Gecode;
using namespace std;


class ClusterOptions : public Options {
 protected:
  Driver::IntOption _datatype; // ratio number of cl/n
  Driver::IntOption _n; // Number of transactions/points
  Driver::IntOption _k; // Number of clusters
  Driver::IntOption _kmin; // Number of min clusters
  Driver::StringValueOption _f; // file name of dataset features
  Driver::StringValueOption _p; // file name of dataset properties
  Driver::StringValueOption _gt; // file name of ground truth partition
  Driver::StringValueOption _c; // file for must-link and cannot-link constraint
  Driver::StringValueOption _o; // file name for output partition
  
  Driver::IntOption _r; // number of ML/CL randomly generated
  Driver::IntOption _sizeMin; // sizeMin constraint of groups
  Driver::IntOption _sizeMax; // sizeMax constraint of groups
  Driver::DoubleOption _d; // limit diameter
  Driver::DoubleOption _s; // separation between group
  
  Driver::IntOption _a; // attribute used in geometric constraints

  Driver::IntOption _order; // ordering point
  Driver::IntOption _obj; // objective function
  Driver::IntOption _searchstrategy; // search order,  search = 1: IDG, search = 2: IGD
  Driver::DoubleOption _epsilon; // search order,  search = 1: IDG, search = 2: IGD
  Driver::DoubleOption _minpoint; // search order,  search = 1: IDG, search = 2: IGD
  Driver::IntOption _verbose; // verbosity, 0 = minimal, 1= CP output also, 2= debug
  Driver::StringValueOption _model; 
  Driver::IntOption _uc; // use case for complex constraints
  Driver::IntOption _br; // branching choice



 public:
  /// Constructor
 ClusterOptions(void) : Options("Cluster"),
    _datatype("-datatype","coordinates/distances",0),  // 0: coordinates, 1: distance matrix
    _n("-n","number of points",0),  // 0: all data
    _k("-k","number of clusters",0),
    _kmin("-kmin","min number of clusters",0),    
    _f("-f","features file name", ""),
    _p("-p","properties file name", ""),
    _gt("-g","ground truth", ""),
    _c("-c","ML/CL constraint file", ""),
    _o("-o","output partition file", ""),
    _r("-r","#ML/CL random",0),
    _sizeMin("-sizeMin","min cluster size",0),
    _sizeMax("-sizeMax","max cluster size",0),
    _d("-d","maximal diameter",0),
    _s("-s","minimal split",0),
    _a("-a","attribute",-1),
    _order("-order","ordering points", 2),
    _obj("-obj","opt criterion", 1), 
    _searchstrategy("-searchstrategy","Search order", 0), 
    _epsilon("-epsilon","epsilon neighbor", 0),
    _minpoint("-minpoint","minpoint", 0), 	
    _verbose("-v","verbose", 0), 
    _model("-mod","full/local", "full"),
    _uc("-u","use case",0),
    _br("-b","use case",0)
      {
	add(_datatype); add(_n); add(_k); add(_kmin); add(_f); add(_p);  add(_gt); 
	add(_c); add(_o); add(_r); add(_sizeMin); add(_sizeMax); add(_d); add(_s); 
	add(_order); add(_obj); add(_searchstrategy);
	add(_epsilon); add(_minpoint); add(_verbose); add(_model); add(_uc); add(_br); add(_a);
      }
  int datatype(void) const { return _datatype.value(); }
  int n(void) const { return _n.value(); }
  int k(void) const { return _k.value(); }
  int kmin(void) const { return _kmin.value(); }
  string f(void) const { return _f.value(); }
  string p(void) const { return _p.value(); }
  string gt(void) const { return _gt.value(); }
  string c(void) const { return _c.value(); 	}
  string output(void) const { return _o.value(); 	}
  int rmlcl(void) const { return _r.value(); }
  int sizeMin(void) const { return _sizeMin.value(); }
  int sizeMax(void) const { return _sizeMax.value(); }
  double split(void) const { return _s.value(); }
  double diam(void) const { return _d.value(); }
  int order(void) const { return _order.value(); }
  int obj(void) const { return _obj.value(); }
  int searchstrategy(void) const { return _searchstrategy.value(); }
  double epsilon(void) const { return _epsilon.value(); }
  double minpoint(void) const { return _minpoint.value(); }
  int verbose(void) const { return _verbose.value(); }
  string model(void) const { return _model.value(); }
  int ucase(void) const { return _uc.value(); }
  int branch(void) const { return _br.value(); }
  int attr(void) const { return _a.value(); }
  void setC(const char* v) {_c.value(v);}
  void setSizeMin(int v) {_sizeMin.value(v);}
  void setSizeMax(int v) {_sizeMax.value(v);}
  void setUC(int u) {_uc.value(u); }
  void setDiam(double d) {_d.value(d); }
  void setOutput(const char* v) {_o.value(v);}
};

#endif
