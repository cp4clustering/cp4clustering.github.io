
mainCC.cpp: compcons, implements complex constraints 



-v (verbose)
	1  print number of super-points, orderSP, rorderSP, 
		intermediate solutions
	2  like 1 and more information
	-2 experiments that compare 2 cases (1) random ML/CL constraints 
		vs (2) random ML/CL constraints with a minimal size constraint
		the number of ML/CL constraints is given by -r
		sizeMin infered from the sample taken for computing ML/CL
		this mode is used on datasets Iris, Wine, WDBC
	-3 experiments on pendigits

-f (data file)
	the file must have at 1st line the number of instances
	the other lines are instances
	all values are taken as double

-g (ground truth)
	the file must have at 1st line the number of instances
	the other lines are instances and must have at 1st column the class

-p (property)
	the file must have at 1st line the number of instances
	the other lines all the properties
	properties are taken as string

-c (constraint ML/CL file)
	the value can be set by user or by program, in case of creating ML/CL

-r (random ML/CL or % of instances)

