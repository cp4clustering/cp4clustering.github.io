#ifndef CLUSTERCC
#define CLUSTERCC

#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"

using namespace Gecode;
using namespace std;

class CPClusterCC : public Space {
protected:
  const ClusterOptions& options;
  IntVarArray G; // G[i]: 1..k,  G[i]: class of i
  FloatVar D;
  FloatVar S;

  vector<double>* ddMax;
  vector<double>* ddMin;
  vector<double>* ddSS;

public:
 CPClusterCC(const ClusterOptions& opt, bool all, int nOrigine, int nSP, 
	   vector<double>* ddSS0, vector<double>* ddMin0, vector<double>* ddMax0,
	   int* orderSP, int* rorderSP, 
	   vector<int>* clgraph, vector<int>* cc,
	   int* rorder, int* ccindex,
	     vector<double>* feat, vector<string>* prop) : 
  //Space(opt),
  options(opt), 
    G(*this, nSP, 0, opt.k()-1), 
    D(*this, 0, Float::Limits::max), 
    S(*this, 0, Float::Limits::max),
    ddMax(ddMax0), ddMin(ddMin0), ddSS(ddSS0)
  {
    postConstraints(nOrigine, all, nSP, 
		    orderSP, rorderSP, clgraph,
		    cc, rorder, ccindex, feat, prop);
    if (opt.verbose() != -3)
      postUCconstraints(nOrigine, all, nSP, 
			orderSP, rorderSP, clgraph,
			cc, rorder, ccindex, feat, prop);
    else
      if (opt.verbose() == -3 && opt.ucase() >= 0)
      postPenConstraints(nOrigine, nSP, orderSP, rorderSP, clgraph,
			cc, rorder, ccindex, feat, prop);
    postBranch();
  }

  CPClusterCC(bool share, CPClusterCC& s) : 
  Space(share, s), options(s.options), ddMax(s.ddMax), ddMin(s.ddMin), ddSS(s.ddSS) {
    G.update(*this, share, s.G);
    D.update(*this, share, s.D);
    S.update(*this, share, s.S);
  }

  virtual Space* copy(bool share) {
    return new CPClusterCC(share,*this);
  }


  virtual void constrain(const Space& sol) { 
    const CPClusterCC& _sol=static_cast<const CPClusterCC&>(sol);     
    switch (options.obj()) {
    case 1: // minimize diameter
      rel(*this, D < _sol.D.min());
      break;
    case 2: // maximize split
      rel(*this, S > _sol.S.max());
      break;
    case 0:
    default:
      break;
    }
  }

  virtual void print() const;
  
  void postConstraints(int nOrigine, bool all, int nSP, 
		       int* orderSP, int* rorderSP, 
		       vector<int>* clgraph, vector<int>* cc,
		       int* rorder, int* ccindex,
		       vector<double>* feat, vector<string>* prop);
  void postUCconstraints(int nOrigine, bool all, int nSP, 
		       int* orderSP, int* rorderSP, 
		       vector<int>* clgraph, vector<int>* cc,
		       int* rorder, int* ccindex,
			 vector<double>* feat, vector<string>* prop);
  void postPenConstraints(int nOrigine, int nSP, 
		       int* orderSP, int* rorderSP, 
		       vector<int>* clgraph, vector<int>* cc,
		       int* rorder, int* ccindex,
			 vector<double>* feat, vector<string>* prop);
  void postBranch();
  void computeSize(vector<int>* cc, int* orderSP);
  double computeRI(int  nOrigine, int* clusterGT, int* ccindex, int* rorderSP);
  void printStats(int nOrigine, vector<string>* prop, int*ccindex, int* rorderSP, int* rorder);
  void savePartition(int nOrigine, vector<int>& partition, int* ccindex, int* rorderSP);
  void savePartitionFile(int nOrigine, int* ccindex, int* rorderSP);
  double objValue();
};


#endif
