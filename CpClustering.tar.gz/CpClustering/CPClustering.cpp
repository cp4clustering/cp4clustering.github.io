#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 

#include "common/commonVariables.cpp"

#include "common/branchDiameter.cpp"
#include "common/branchMix.cpp"
#include "common/branchVariance.cpp"


#include "common/varianceConstraint.cpp"

#include "common/commonFunction.cpp"
#include "common/clusterOptions.cpp"
#include "common/IGConstraint.cpp"

using namespace Gecode;
using namespace std;


double timebestSol;


class Cluster : public Script {
protected:
  const ClusterOptions& options;
  IntVarArray G; // G[i]: 1..k,  G[i]: class of i
  FloatVar DS; // maximal diameter or minimum Separation
  IntVarArray I; // I[1..k]: 1..n,  I[c] = representant (le plus petit index) du C
  FloatVar variance; // variance (formule avec ou sans Division est dans la 

public:
  enum {
    ORDER_NONE, ORDER_POID, ORDER_FPF, ORDER_RANDOM
  };
  enum {
    ORDER_FIRST, ORDER_LAST // take first n point or take last n point
  };

  Cluster(const ClusterOptions& opt) : 
  options(opt),
  G(*this, opt.n(), 0, opt.n()-1), 
  DS(*this, 0, Float::Limits::max), 
  variance(*this, 0, Float::Limits::max), 
  I(*this, opt.k(), 0, opt.n()-1)
 
  {

//______________________________________________________________________________________________________________________________//
//								READ DATA + RE-ORDER POINTS + CALCUL MATRIX D + CALCUL DIAMETER FPF								//
//______________________________________________________________________________________________________________________________//



	int ORDER_first_last = ORDER_FIRST;
    double maxD, minD; // max and min Distance between points
    startAll = give_time();
    ifstream fin(opt.f().c_str(),ios::in);	// read file

    int n; // n: number of points, k: number of clusters, nA: number of attributes
    int k = opt.k(); int nA = opt.a();	nClass = k; objectiveFunction = opt.obj();

    fin >> n; 	// we will clustering last nSmall objects from n objects. But we always have to reorder n point. 
	
    vector<double> a[n];
	nSmall = opt.n();
	nBig = n;
	initCommonVariables(nBig);		// nBIG: total number of points in database. nSmall: number of point we wanna to cluster


//	readPreviousResult(); // read  previous result for lower bound of variance (or diameter?). but sometimes we cannot add user-constraints


	if (opt.datatype() == 0)
		readData(n, nA, fin, a);	// read all attributs of points to A
	if (opt.datatype() == 1)
		readDataMatrix(n, fin,maxD, minD);	// read all attributs of points to A
	
    int realClass[n];
	readRealClass(n, nA, opt.f() + "Class", a, realClass); 		// input: iris.txt => real class:  iris.txtClass
//----------------------------------END  READ DATA FROM FILE AND INIT VARIABLES----------------------------------


//_________________________________INIT RANDOMIZE___________________________________________________
//	timeval t1;	
//	gettimeofday(&t1, NULL);
//	srand(t1.tv_usec * t1.tv_sec); 
	
//	cout << "Randomly reorder point \n";


	nBig = nSmall;	
	n = nSmall;


//_________________________________RE ORDERING POINT________________________________________________

if (opt.datatype() == 0) // only when data is read in normal form
	switch (opt.order()) {
		case ORDER_NONE:
			cout << "No Ordering Points" << endl;
			break;
	    case ORDER_POID:
			reOrderPointPoid(n, k, nA, a, realClass); // these functions are in commonFunction.cpp
			break;
		case ORDER_FPF:
			reOrderPointFPF(n, k, nA, a, realClass);
			break;
		case ORDER_RANDOM:
			reOrderPointRANDOM(n, a, realClass);
			break;	
		case 4:
			reOrderPointVariance(n, k, nA, a, realClass);
			break;
    }
    startAll = give_time();

    
//----------------------------------END RE ORDERING POINT----------------------------------


//________________________________CALCUL MATRIX OF DISTANCE_____________________________________________

	if (opt.datatype() == 0) {
		calculD(n, nSmall, ORDER_first_last, maxD, minD, a); // ORDER_FIRST if we take first n points or ORDER_LAST if we take last n point
	}
	n = nSmall;
//--------------------------------END CALCUL MATRIX OF DISTANCE----------------------------------
    cout << "Calcul Matrix of Dissimilarity in \t: " << give_time() - startAll << endl;
    startAll = give_time();

//________________________________CALCUL DIAMETER FPF_____________________________________________	

	double diamHeuristic = calculDiameterFPF(n, k);
    cout << "Diameter heuristic FPF = " << diamHeuristic << ", in \t: " << give_time() - startAll << endl;
    startAll = give_time();
//--------------------------------END CALCUL DIAMETER FPF----------------------------------
    



//______________________________________________________________________________________________________________________________//
//								POSTING CONSTRAINT	: BASIC CONSTRAINT + USER CONSTRAINTS										//
//______________________________________________________________________________________________________________________________//


// _______________________________POST BASIC CONSTRAINT_______________________________________________
	// CONSTRAINT OF DOMAIN OF DIAMETER OR SEPARATION
	rel(*this, DS, FRT_GQ, minD);
	rel(*this, DS, FRT_LQ, maxD);

 
    // RELIER I et G:  G[I[c]] = I[c]
    for (int c = 0; c < k; c++)
	      element(*this, G, I[c], I[c]);			
		
    // G[0] = 0, I[0] = 0
    rel(*this, I[0], IRT_EQ, 0);
    
    // #{c|I[c] = G[i]} = 1  for every i in [1..n]
    for (int i = 0; i < n; i++)
      count(*this, I, G[i], IRT_EQ, 1);




    // G[i] <= i
    for (int i = 0; i < n; i++)
      rel(*this, G[i], IRT_LQ, i);

    // I[c] < I[c'] with c < c'
    rel(*this, I, IRT_LE);

	// CONSTRAINT On Same POINT  
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++)
			if (dcarre[i][j] == 0)  {
				rel(*this, G[i], IRT_EQ, G[j]);		    
				cout << "Same point on " << i << " " << j << endl;
			}

// ----------------------------END POST BASIC CONSTRAINT----------------------------------
    

	

// _______________________________POST MUST-LINK CANNOT-LINK CONSTRAINTS_______________________________________________
	generateMLCL(opt.ml(), opt.cl(), n, realClass); // generate must-link and cannot-link pair to matrix mlcl[i][j]. mlcl[i][j] = 0 if cannot link, =1 if mustlink, =2 otherwise
	if (opt.ml() + opt.cl() > 0) {
		for (int i = 0; i < n; i++)
			for (int j = i+1; j < n; j++) {
				if (mlcl[i][j] == 1) { // must-link
					rel(*this, G[i], IRT_EQ, G[j]);
					if (opt.obj() == 1)  // if we want Max Diameter
						rel(*this, DS, FRT_GQ, dd[i][j]);
				}
				if (mlcl[i][j] == 0) { // cannot-link
					rel(*this, G[i], IRT_NQ, G[j]);
					if (opt.obj() == 2)  // if we want min separation 
						rel(*this, DS, FRT_LQ, dd[i][j]);
				}				
			}	
	}
//----------------------------------END POST MUST-LINK CANNOT-LINK CONSTRAINTS----------------------------------


//___________________________________CONTRAINT OF DIAMTER with UPPER BOUND is GIVEN by FPF: this is the CASE when there is NO USER-CONSTRAINT

		if (opt.dfpf() == 1) {
				// DIAMETER FPF,   d[i, j] > diameter_Fpf => i, j in different groups
				rel(*this, DS, FRT_LQ, diamHeuristic);

				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) {			
							if (dd[i][j] > 	diamHeuristic) 
								rel(*this, G[i], IRT_NQ, G[j]);
				  }
		}
//----------------------------------END CONTRAINT OF DIAMTER with UPPER BOUND is GIVEN by FPF: this is the CASE when there is NO USER-CONSTRAINT


//___________________________________CONTRAINT OF DIAMTER given BY USER_______________________________________________________

		if (opt.diam() > 0) {
				// DIAMETER FPF,   d[i, j] > diameter_Fpf => i, j in different groups
				rel(*this, DS, FRT_LQ, opt.diam());

				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) {			
							if (dd[i][j] > 	opt.diam()) 
								rel(*this, G[i], IRT_NQ, G[j]);
				  }
		}
//----------------------------------END CONTRAINT OF DIAMTER given BY USER----------------------------------

//___________________________________CONSTRAINT of SEPARATION _____________________________________________________
    if (opt.s() > 0) {
		rel(*this, DS, FRT_GQ, opt.s());
		for (int i = 0; i < n; i++)
			for (int  j = i+1; j < n; j++)
			  if (dd[i][j] < opt.s()) 
			  	rel(*this, G[i], IRT_EQ, G[j]);
	}
//----------------------------------END CONSTRAINT of SEPARATION----------------------------------



//___________________________________COUNTING CONSTRAINT: SIZE OF EACH GROUP_______________________________________________________
	if (opt.sizeMin())
		for (int c = 0;c < k; c++) 
			count(*this, G, I[c], IRT_GQ, opt.sizeMin());

	if (opt.sizeMax())
		for (int c = 0;c < k; c++) 
			count(*this, G, I[c], IRT_LQ, opt.sizeMax());
//----------------------------------END COUNTING CONSTRAINT: SIZE OF EACH GROUP----------------------------------


//___________________________________ CONSTRAINT OF DENSITY: Epsilon + Minpoint____________________________________
		if (opt.epsilon() * opt.minpoint() > 0) {
			for (int i = 0; i < n; i++) { // we need to check point 0
				int npoint = 0; 
				for (int j = 0; j < n; j++)
					if (dd[i][j] <= opt.epsilon()) 
						if (i != j) 
							npoint++; 		// number of point near point i;
				if (npoint >= 0) {
						IntVarArgs nearPoint(npoint);
						npoint = 0;
						for (int j = 0; j < n; j++)
							if (dd[i][j] <= opt.epsilon()) 
								if (i != j) 
									nearPoint[npoint++] = G[j];
			      count(*this, nearPoint, G[i], IRT_GQ, opt.minpoint()); // there are at least minpoint near G[i] at distance epsilon
				}
			}
		}
//----------------------------------END: CONSTRAINT OF DENSITY----------------------------------


//______________________________________________________________________________________________________________________________//
//								POSTING CONSTRAINT ON OBJECTIVE FUNCTION : DIAMETER, SEPARATION, VARIANCE						//
//______________________________________________________________________________________________________________________________//

//_________________________________ objective function = 1: Minimise Maximum Diameter_________________________________
		if (opt.obj() == 1) {
				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) 			
						if (dd[i][j] >= diamHeuristic/2) 
							if (mlcl[i][j] == 2) {			// we do this only when there is no must-link or cannot-link constraint								
								BoolVar b(*this, 0, 1);
								rel(*this, DS, FRT_GQ, dd[i][j], b); // b = (Diameter >= dd(i, j)
								BoolVar same(*this, 0, 1);

								rel(*this, G[i], IRT_EQ, G[j], same);  // same = (G[i] = G[j])	
								rel(*this, same, IRT_LQ, b);			// same <= b
							}
			rel(*this, DS, FRT_GQ, diamHeuristic/2);
		}
//----------------------------------END objective function = 1: Minimise Maximum Diameter----------------------------------



//_________________________________ objective function = 2: Maximise Min Separation_________________________________
		if (opt.obj() == 2) {
				// SEPARATION
				for (int i = 0; i < n; i++)
				  for (int j = i + 1; j < n; j++) 			
					if (mlcl[i][j] == 2) {			// we do this only when there is no must-link or cannot-link constraint								
						BoolVar b(*this, 0, 1);
						BoolVar same(*this, 0, 1);
	
						rel(*this, DS, FRT_GQ, dd[i][j], b); 
						rel(*this, G[i], IRT_EQ, G[j], same);
						rel(*this, b, IRT_LQ, same);			
				  }
		}
//----------------------------------END objective function = 2: Maximise Miln Separation----------------------------------


//_________________________________ objective function = 3: Min Variance_________________________________
	
	// UPPER BOUND of VARIANCE from PREVIOUS RESULTs
	if (opt.obj() == 3) {
//		double upper = upper_Variance(n);  //  We need privious result with n-1, given by result.txt, and Point need to take in ORDER_LAST, not ORDER_FIRST
//double		upper = 550;
//		rel(*this, variance, FRT_LQ, upper+0.000001);

		sortD(n); // sort distance for variance constraint
		varianceConstraint(*this, G, variance);
		
//		varianceConstraintDivision(*this, G, variance);
	}
//----------------------------------END  objective function = 3: Min Variance----------------------------------


    cout << "Posting Constraints in \t:  " << give_time() - startAll << endl;
    startAll = give_time();
    cout << "__________________________________________________________" << endl;


//	IGConstraint(*this, I, G);


//______________________________________________________________________________________________________________________________//
//								BRANCHING ON I, G																				//
//______________________________________________________________________________________________________________________________//


   branch(*this, I, INT_VAR_NONE(), INT_VAL_MIN()); 


	if (opt.obj() == 1)  // min Diameter max
	    branchDiameter::post(*this, G);

	if (opt.obj() == 2)  // max Separation min
	    branchDiameter::post(*this, G);

	if (opt.obj() == 3)  // min Variance
	//	branchVarianceDivision::post(*this, G);
//		branchVariance::post(*this, G);
		branchMix::post(*this, G); 
  }


  Cluster(bool share, Cluster& s) : Script(share, s), options(s.options) {
    G.update(*this, share, s.G);
    I.update(*this, share, s.I);
    DS.update(*this, share, s.DS);
	variance.update(*this, share, s.variance);
  }

  virtual Space* copy(bool share) {
    return new Cluster(share,*this);
  }


// BRANCH AND BOUND: Next solution must be better than the previous
  virtual void constrain(const Space& sol) { 
    const Cluster& _sol=static_cast<const Cluster&>(sol);
		if (objectiveFunction == 1) 
			rel(*this, DS < _sol.DS.min());

		if (objectiveFunction == 2) 
			rel(*this, DS > _sol.DS.max());
		
		if (objectiveFunction == 3) {
			rel(*this, variance < _sol.variance.min());

		}
  }


// Print solution
  virtual void print(ostream& os) const {
	os << "___________________________________________________________________________\n";
	int n = nSmall;
	int checkAllG = 0;
	while ((checkAllG < n) && G[checkAllG].assigned()) checkAllG++;   // check if we have a solution or still in the search

	// PRINT Rand Index, Size of Group,..
	if (checkAllG == n) { // It means we have a real solution, all variables are fixed
		int GR[nBig];	
		for (int i = 0; i < nBig; i++)
			GR[i] = -1;
		for (int i = 0; i < nSmall; i++) {
		  GR[order[i]] = G[i].val();
		  finalClass[i] = G[i].val();
		}	
//		for (int i = 0; i < nSmall; i++)
//			finalClass[i] = GR[i];
		ofstream fOut("class.txt",ios::out);	// read file
		for (int i = 0; i < G.size(); i++)
		  fOut << GR[i] << endl;		
		fOut.close();
		// Calcul size of each group
		os << "Size of groups: ";
		for (int c = 0; c < I.size(); c++) {
		  int sum = 0;
		  for (int i = 0; i < G.size(); i++)
		if (G[i].val() == I[c].val())
		  sum++;
		  os << sum << " ";
		}
		os << endl;		
		os << "Rand Index = " << RandIndex(n, realClass1, GR) << endl;				
	}
    

	// PRINT I, G
    os << "I: " << I << endl;
//    os << "G: " << G << endl;


	// PRINT Diameter / Separation /Variance
	if (objectiveFunction == 1) 
		    os << "Diameter: " << DS.min() << " " << DS.max() <<  endl;
	if (objectiveFunction == 2)
	    os << "Separation: " << DS.max() << endl;
	if (objectiveFunction == 3)
	    os << "Variance: " << variance.min() << " " << variance.max() << endl;
    cout << "This solution is found AFTER: " << give_time() - startAll << endl;
			finalVariance = variance.min();

	timebestSol = give_time() - startAll;

//	buildFinalOrder(n);

  }
};


int main(int argc, char* argv[]) {
	double start2 = give_time();
	ClusterOptions opt;
	opt.solutions(0);
	opt.parse(argc,argv);
	opt.c_d(50); 
	opt.a_d(50);  // No recomputation, we save all nodes' information

//	opt.time(600000); // Time limit is 10 minutes

	MinimizeScript::run<Cluster,BAB,ClusterOptions>(opt);

	cout << "SEARCHING TIME : " << give_time() - startAll << endl;
	cout << "TOTAL TIME : " << give_time() - start2 << endl;

  // print final solution to txt file
	ofstream fOut(fileResult,ios::app);	// read file
//	fOut << nSmall << " " << finalVariance << " " ;
	fOut << nSmall << " " << timebestSol << " " << give_time() - start2 << " " << finalVariance << endl;
//	for (int i = 0; i < nSmall; i++) 
//		fOut << finalClass[i] << " ";

    fOut.close();  


	return 0;
}

