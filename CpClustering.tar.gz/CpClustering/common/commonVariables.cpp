#include <iostream>

double startAll;

int counter1 = 0;
int counter2 = 0;
int *order;

int countSolution = 0;
int objectiveFunction = 0;
int *realClass1;
int **mlcl;

//double **VariancePartiel; // V[i][j] Variance of point i to class of representant j
//int *checkI;
int *positionG; // position[G[i]] = 0,...,k-1
int nClass = 0;
double *notFixDist;
double **dd;
//double **dcarre;
double *VarianceClass; // total number of pair in this class
//int *sClass; // size of each class


double finalVariance = 0;
int *finalClass;
int *finalOrder;

int nBig; // real number of point in database, nBig of iris = 150
int nSmall;
char *fileResult = "result.txt";

double *bestV; // bestVariance with a number of point
int **bestSol; // best Solution of best Variance

int *checkI;
double **VariancePartiel;
double **dcarre;
int *sClass;

double *dSort; // distance CARRE sort. 
int *pX, *pY; // position x, position y in the dSort. x:row, y:column

int countPropagation = 0;

