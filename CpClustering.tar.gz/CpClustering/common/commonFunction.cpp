


double dist(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return sqrt(d);
}

int distInt(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  d = sqrt(d);
  d *= 100;

  return (int) d;
}

double give_time(){
  struct rusage ru;
  struct timeval tim;
  getrusage(RUSAGE_SELF, &ru);
  tim = ru.ru_utime;
  return (double)tim.tv_sec+(double)tim.tv_usec/1000000.0;
}


void readPreviousResult() {
	// read bestV and solution with that
    ifstream fResult(fileResult,ios::in);	// read file		
	
	int n1;
	while(fResult >> n1)  // Attempt read into x, return false if it fails
	{
    	// will only be entered if read succeeded.
		fResult >> bestV[n1];
//		cout << "BEST " << n1 << " " << bestV[n1] << endl;
		for (int i = 1; i <= n1; i++)
			fResult >> bestSol[n1][i];
	}

}

void readDataMatrix(int n, ifstream &fin, double &maxD, double &minD) {
	maxD = 0;
	minD = 100000000;
	for (int i = 0; i < n; i++) 
		for (int j = 0; j < n; j++) {
			fin >> dd[i][j];
			dcarre[i][j] = dd[i][j] * dd[i][j];
			if (i != j) {
				if (maxD < dd[i][j]) maxD = dd[i][j];
				if (minD > dd[i][j]) minD = dd[i][j];
			}
      }	// end of read file
}

void readData(int n, int nA, ifstream &fin, vector<double> *a) {
    double temp;
    for (int i = 0; i < n; i++) 
      for (int j = 0; j < nA; j++) {
				fin >> temp;
				a[i].push_back(temp); 		
      }	// end of read file

}


// read real class of points
void readRealClass(int n, int nA, string fileName, vector<double> *a, int *realClass) {


    
      ifstream finClass(fileName.c_str(),ios::in);	// read filel	
      for (int i = 0; i < n; i++) {
				finClass >> realClass[i];
				realClass1[i] = realClass[i];
	  }
    
}

void generateMLCL(int ml, int cl, int n, int *realClass) {
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			mlcl[i][j] = 2;	// mlcl[i][j] = 1 if there is ML, = 0 if there is CL
    
    for (int i = 0; i < ml; i++) {   // generate must link constraint
      int x = rand() % n;
      int y = rand() % n;
      while ((realClass[x] != realClass[y]) || (x == y))  
		y = rand() % n;
	  mlcl[x][y] = 1;
	  mlcl[y][x] = 1;
    }
    
    for (int i = 0; i < cl; i++) {   // generate CANNOT link constraint
		int x = rand() % n;
		int y = rand() % n;
		while (realClass[x] == realClass[y])   y = rand() % n;
		mlcl[x][y] = 0;
		mlcl[y][x] = 0;
    }
}

void initCommonVariables(int n) {
	// creat VariancePartiel
    VariancePartiel = new double*[n];
    for (int i=0; i<n; i++)
        VariancePartiel[i] = new double[n];

 	// creat notFixDist  : Distance carre between non-fixed point
	notFixDist = new double[n * n];

	//creat positionG
	positionG = new int[n]; // for ex: G[i] = 0, 1, 5 => postion[0] = 0; position[1] = 1; position[5] = 2;
	positionG[0] = 0;

	// creat dd[n][n]
    dd=new double*[n];
    for (int i=0; i<n; i++)
        dd[i] = new double[n];
	//___________ end_______________
	// creat checkI
    checkI = new int[n];
	//___________ end_______________

	// creat order
    order = new int[n];
    for (int i = 0; i < n; i++)
      order[i] = i;

	//___________ end_______________
	// creat realClass1
    realClass1 = new int[n];
	//___________ end_______________
	// creat mlcl[n][n]
    mlcl = new int*[n];
    for (int i=0; i<n; i++)
        mlcl[i] = new int[n];
	//___________ end_______________
	// creat dcarre[n][n]
    dcarre = new double*[n];
    for (int i=0; i<n; i++)
        dcarre[i] = new double[n];
	//creat double *VarianceClass; // total variance in this class
	VarianceClass = new double[n];
	// creat int *sClass; // size of each class
	sClass = new int[n];
	// creat finalClass
	finalClass = new int[n];
	for (int i = 0; i < n; i++)
		finalClass[i] = -1;
	// creat bestV;
	bestV = new double[n+1];	
	for (int i = 0; i < n+1; i++)
		bestV[i] = 0;
	// creat bestSol;
	bestSol = new int*[n+1];	
	for (int i = 0; i < n+1; i++)
		bestSol[i] = new int[n+1];
	// creat finalOrder
	finalOrder = new int[n];
}




int pivot(double a[], int pX[], int pY[], int first, int last) 
{
    int  p = first;
    double pivotElement = a[first];
 
    for(int i = first+1 ; i <= last ; i++)
    {
        if(a[i] <= pivotElement)
        {
            p++;
            swap(dSort[i], dSort[p]);
			swap(pX[i], pX[p]);
			swap(pY[i], pY[p]);

        }
    }
 
    swap(a[p], a[first]);
	swap(pX[p], pX[first]);
	swap(pY[p], pY[first]);

    return p;
}

void quickSort( double a[], int pX[], int pY[], int first, int last ) 
{
    int pivotElement;
 
    if(first < last)
    {
        pivotElement = pivot(a, pX, pY, first, last);
        quickSort(a, pX, pY, first, pivotElement-1);
        quickSort(a, pX, pY, pivotElement+1, last);
    }
}
 
 


void sortD(int n) {
	// creat dSort
    dSort = new double[n * (n - 1)/2];
	// creat pX, pY
    pX = new int[n * (n - 1)/2];
    pY = new int[n * (n - 1)/2];

	int count = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j <n; j++) {
			pX[count] = i;
			pY[count] = j;
			count++;
		}

	count = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j <n; j++) {
			dSort[count] = dd[i][j] * dd[i][j];
			count++;
		}

	// sort
/*	for (int i = 0; i < count; i++)
		for (int j = i+1; j < count; j++)
			if (dSort[i] > dSort[j]) {
				swap(dSort[i], dSort[j]);
				swap(pX[i], pX[j]);
				swap(pY[i], pY[j]);
			}
*/
	quickSort(dSort, pX, pY, 0, count-1);
}


void reOrderPointFPF(int n, int k, int nA, vector<double> *a, int *realClass) {

    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD;
				totalDist[j] += tempD;
      }

	double distToP[n];
	for (int i = 0; i < n; i++)
		distToP[i] = totalDist[i];

	// here we use FPF to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
	  // now we find point for position p
	  // FIRST, calcul F(i) off all point from i to n
	  int position = 0;
	  double maxF = 0;		
	  for (int i = p; i < n; i++) {
			double f = 0; // f(i)				
			double minDist = 100000;
			//double maxDist = 0;
/*			int p1 = n;  // p1 = 3 * k ??
			if (p < p1) p1 = p;
			for (int j = 0; j < p1; j++) { 
				double distTemp = dist(a[i], a[j]);

				if (distTemp < minDist) 
					minDist = distTemp;
			}

		// minDist = min distance from a point to  [point 0, point 1, ... point p-1 ] 
		if (p == 0)   // special case
			f = totalDist[i]; 
		else
			f = minDist;

*/		f = distToP[i];
		
		
		if (f > maxF) {		// select the point that is has  max of  minDist
			maxF = f;
			position = i;
		}
	  }
	
	
	//	cout << maxF	 << " " << distToP[position] << endl;

	  if (p < position) {
		  swap(a[p], a[position]);
		  swap(order[p], order[position]);
		  swap(totalDist[p], totalDist[position]);
		  swap(realClass[p], realClass[position]);	
		  swap(distToP[p], distToP[position]);	  
	  }
		  // now: update distToP of point p+1 to n
	  for (int c = p+1; c < n; c++) {
		 double tempD = dist(a[p], a[c]);
		 if (distToP[c] > tempD)
			distToP[c] = tempD;
	  }


	}

	// calcal D[x][y] = distance between point x and y, distance is integer

	cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;

}


void reOrderPointVariance(int n, int k, int nA, vector<double> *a, int *realClass) {

    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD * tempD;
				totalDist[j] += tempD * tempD;
      }

	// here we use FPF to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
		// now we find point for position p
		// FIRST, calcul F(i) off all point from i to n
		int position = 0;
		double maxF = 0;		
		for (int i = p; i < n; i++) {
			double f = 0; // f(i)				
			double minDist = 0;
			//double maxDist = 0;
			int p1 = n;  // p1 = 3 * k ??
			if (p < p1) p1 = p;
			for (int j = 0; j < p1; j++) { 
				minDist += dist(a[i],a[j]) * dist(a[i],a[j]) ;
		}

		// minDist = min distance from a point to  [point 0, point 1, ... point p-1 ] 
		if (p == 0)   // special case
			f = totalDist[i]; 
		else
			f = minDist;
		if (f > maxF) {		// select the point that is has  max of  minDist
			maxF = f;
			position = i;
		}
	  }
	  swap(a[p], a[position]);
	  swap(order[p], order[position]);
	  swap(totalDist[p], totalDist[position]);
	  swap(realClass[p], realClass[position]);
	}

	// calcal D[x][y] = distance between point x and y, distance is integer

	cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;
}
void reOrderPointPoid(int n, int k, int nA, vector<double> *a, int *realClass)  {
    double totalDist[n];
    double tempD = 0;
    
    for (int i = 0; i < n; i++) 
      totalDist[i] = 0;

    // totalDistant of point i to all other point
    for (int i = 0; i < n; i++) 
      for (int j = i+1; j < n; j++) {
				tempD = dist(a[i], a[j]);
				totalDist[i] += tempD;
				totalDist[j] += tempD;
      }

	// here we use our Function to reorder points
	for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL

	// now we find point for position p

		// FIRST, calcul F(i) off all point from i to n
		int position = 0;
		double maxF = 0;		

		for (int i = p; i < n; i++) {
			double f = 0; // f(i)				
			double minDist = 100000;
			double maxDist = 0;

			int p1 = n;
			if (p < p1) p1 = p;

			for (int j = 0; j < p1; j++) {  // f(i) = Sum d(i, j) * min/max * (n-p)/p
				double distTemp = dist(a[i], a[j]);
				f += distTemp;	
				if (distTemp < minDist) minDist = distTemp;
				if (distTemp > maxDist) maxDist = distTemp;
			}

			if (p >= 1)
				f = f * (((minDist/maxDist)/p) * (n-p)-1);

			f += totalDist[i];	

			if (f > maxF) {
				maxF = f;
				position = i;
			}
		}
		swap(a[p], a[position]);
		swap(order[p], order[position]);
		swap(totalDist[p], totalDist[position]);
		swap(realClass[p], realClass[position]);
	}
	cout << "Reading + ReOrganisation DATA (WEIGHT FUNCTION) in \t:  " << give_time() - startAll << endl;
}

void reOrderPointRANDOM(int n, vector<double> *a, int *realClass)  {
	for (int i = 0; i < 10000; i++) {
	  int x = rand() % n;
      int y = rand() % n;
	  swap(a[x], a[y]);
	  swap(order[x], order[y]);
	  swap(realClass[x], realClass[y]);
	}
	cout << "Randomly reorder point \n";

}

void reOrderPointRevert(int n, vector<double> *a, int *realClass)  {
	for (int i = 0; i < n/2; i++) {
	  swap(a[i], a[n-i-1]);
	  swap(order[i], order[n-i-1]);
	  swap(realClass[i], realClass[n-i-1]);
	}
	cout << "Revert reorder point \n";

}



void calculD(int n, int nSmall, int order, double &maxD, double &minD,  vector<double> *a) {

	// now we take nSmall instead of n. So we will consider only point n-nSmall to point n-1.
	maxD = 0;
	minD = -1;
	
	if (order==1)
		for (int i = n-nSmall; i < n; i++)
		  for (int j = n-nSmall; j < n; j++) {
				
					dd[i - n + nSmall][j - n + nSmall] = dist(a[i], a[j]);
					dcarre[i- n + nSmall][j- n + nSmall] = dd[i - n + nSmall][j - n + nSmall] * dd[i - n + nSmall][j - n + nSmall];
					if (dd[i- n + nSmall][j- n + nSmall] > maxD)	
		  			maxD = dd[i- n + nSmall][j- n + nSmall];  // max distance between two points
					if (minD == -1 || (i!=j && dd[i- n + nSmall][j- n + nSmall]<minD)) 
						if (dd[i- n + nSmall][j- n + nSmall] != 0)	// minD > 0
						  minD = dd[i- n + nSmall][j- n + nSmall]; // min distance between two points
		  }

	if (order==0)
		for (int i = 0; i < nSmall; i++)
		  for (int j = 0; j < nSmall; j++) {
				
					dd[i][j] = dist(a[i], a[j]);
					dcarre[i][j] = dd[i][j] * dd[i][j];
					if (dd[i][j] > maxD)	
		  			maxD = dd[i][j];  // max distance between two points
					if (minD == -1 || (i!=j && dd[i][j]<minD)) 
						if (dd[i][j] != 0)	// minD > 0
						  minD = dd[i][j]; // min distance between two points
		  }

	cout << maxD << " " << minD << endl;
}


double calculDiameterFPF(int n, int k) {
    int group[n];
    int head[k];
    head[0] = 0;
	double diamHeuristic = 0;

    for (int i = 0; i < n; i++) 
      group[i] = head[0];
    

    for (int c = 1; c < k; c++) {
      // find furthest point
      double maxDtoHead = 0;
      int point = 0;
      for (int i = 0; i < n; i++) 
			if (dd[i][group[i]] > maxDtoHead) {
				maxDtoHead = dd[i][group[i]];
				point = i;
			}
 	   	head[c] = point; 
    	for (int i = 0; i < n; i++)
			if (dd[i][group[i]] > dd[i][point]) {
	  		group[i] = point;
			}				
    }

 
    for (int i = 0; i < n; i++)
      for (int j = i+1; j < n; j++)
		if (group[i] == group[j])
	  	if (diamHeuristic < dd[i][j])
	  	  diamHeuristic = dd[i][j];
    

	return diamHeuristic;
}

double upper_Variance_Division(int n) {
	double upper = 1000000;
	for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
			checkI[j] = 0;

	for (int j = 1; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
			checkI[bestSol[n-1][j]] = 1;		


	for (int c = 0; c < n; c++) 
			if (checkI[c]) {	// c is a representative
				bestSol[n-1][0] = c; // now we have n point, from bestSol[n-1][0] to bestSol[n-1][n-1]. We calcul variance
				double tempV = 0; // tempVariance = 0;


				for (int i = 0; i < n; i++) {
					VarianceClass[i] = 0;	
					sClass[i] = 0;
				}

				for (int i = 0; i < n; i++) 
					sClass[bestSol[n-1][i]]++;

				for (int i = 0; i < n; i++)
					for (int j = i + 1; j < n; j++)
						if (bestSol[n-1][i] == bestSol[n-1][j])
							VarianceClass[bestSol[n-1][i]] += dcarre[i][j];					
				
				for (int i = 0; i < n; i++)
					if (checkI[i])	
						tempV += VarianceClass[i]/sClass[i];
				if (upper > tempV)
					upper = tempV;	
			}

	cout << "Counting upper bound of variance:  " << upper <<  endl;
	return upper;
}



double upper_VarianceLAST(int n) {
	double upper = 1000000;
	if (bestV[n-1] > 0) {

		// now we have bestSol[n-1][1] to bestSol[n-1][n-1]

		for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
			checkI[j] = 0;

		for (int j = 1; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
			checkI[bestSol[n-1][j]] = 1;		

		for (int c = 0; c < n; c++) 
			if (checkI[c]) {	// c is a representative

				bestSol[n-1][0] = c; // now we have n point, from bestSol[n-1][0] to bestSol[n-1][n-1]. We calcul variance
				double tempV = 0; // tempVariance = 0;

				for (int i = 0; i < n; i++) {
					VarianceClass[i] = 0;	
					sClass[i] = 0;
				}

				for (int i = 0; i < n; i++) 
					sClass[bestSol[n-1][i]]++;

				for (int i = 0; i < n; i++)
					for (int j = i + 1; j < n; j++)
						if (bestSol[n-1][i] == bestSol[n-1][j])
							VarianceClass[bestSol[n-1][i]] += dcarre[i][j];					
				
				for (int i = 0; i < n; i++)
					if (checkI[i])	
						tempV += VarianceClass[i];
				if (upper > tempV)
					upper = tempV;	
			}

		cout << "Counting upper bound of variance:  " << upper <<  endl;
	}
	return upper;
}


double RandIndex(int n, int *realClass1, int* GR) {
// calcul RAND_INDEX	IT IS NOT CORRECT ANYMORE WITH NSMALL AND NBIG
	int a = 0; int b = 0; int c = 0; int d = 0; int z = 0;
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++) {
			z++;

			if ((realClass1[i] == realClass1[j]) && (GR[i] == GR[j]))
				a++;
			if ((realClass1[i] != realClass1[j]) && (GR[i] != GR[j]))
				b++;
			if ((realClass1[i] == realClass1[j]) && (GR[i] != GR[j])) {
//			cout << i << " " << j << endl;

				c++;
			}
			if ((realClass1[i] != realClass1[j]) && (GR[i] == GR[j]))  {
				d++;
			}	
			
		}
	double Rand;
	Rand = (double) (a + b)/(a+b+c+d);
	return Rand;
}


double upper_Variance(int n) {
	double upper = 1000000;
	if (bestV[n-1] > 0) {

		// now we have bestSol[n-1][1] to bestSol[n-1][n-1]

		for (int j = 0; j < n; j++) // checkI[j] = 1 if j is a representatative
			checkI[j] = 0;

		for (int j = 1; j < n; j++) // calcul sub variance if we assign x[i] = x[j]
			checkI[bestSol[n-1][j]] = 1;		

		for (int c = 0; c < n; c++) 
			if (checkI[c]) {	// c is a representative

				bestSol[n-1][0] = c; // now we have n point, from bestSol[n-1][0] to bestSol[n-1][n-1]. We calcul variance
				double tempV = 0; // tempVariance = 0;

				for (int i = 0; i < n; i++) {
					VarianceClass[i] = 0;	
					sClass[i] = 0;
				}

				for (int i = 0; i < n; i++) 
					sClass[bestSol[n-1][i]]++;

				for (int i = 0; i < n; i++)
					for (int j = i + 1; j < n; j++)
						if (bestSol[n-1][i] == bestSol[n-1][j])
							VarianceClass[bestSol[n-1][i]] += dcarre[i][j];					
				
				for (int i = 0; i < n; i++)
					if (checkI[i])	
						tempV += VarianceClass[i];
				if (upper > tempV)
					upper = tempV;	
			}

		cout << "Counting upper bound of variance:  " << upper <<  endl;
	}
	return upper;
}


void buildFinalOrder(int n) {
// Use strategy from previous solution - FIRST FAIL. I have finalClass[i], I need to build finalOrder[i]
	// so Order[1] will be points the is very far to other points in the same group

	double v[n][n]; // v[i][c]: total distance carre from i to other points in the group c
	for (int i = 0; i < n; i++) {
		finalOrder[i] = i;
		for (int c = 0; c < n; c++)
			v[i][c] = 0;
	}

	// now I calcul v[i]
	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++) {
			v[i][  finalClass[j] ] += dcarre[i][j];
			v[j][  finalClass[i] ] += dcarre[i][j];				
		}

	for (int i = 0; i < n; i++)
		sClass[i] = 0;	// size of class

	for (int i = 0; i < n; i++)
		sClass[  finalClass[i] ]++;
	

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			if (v[i][j] > 0)
				v[i][j] = v[i][j]; // sClass[j];

	double vmin[n]; //  variance from a point to its groups
	for (int i = 0; i < n; i++)
		vmin[i] = v[i][ finalClass[i] ]; // should I divide ?? I think NO

	
	double borderIndex[n];
	for (int  i = 0; i < n; i++)
		borderIndex[i] = 10000000;


	// calcul borderIndex: the ratio of variance between point i to other group and to its group
	for (int i = 0; i < n; i++) 
		for (int j = 0; j < n; j++)
			if ((v[i][j] > 0) && (j != finalClass[i])) // calcul ratio class j and class of i			
				if (borderIndex[i] >  v[i][j]) { // this ratio may < 1
					borderIndex[i] = v[i][j];
				}

	// now I reorder I follow borderIndex
//	for (int i = 0; i < n; i++)
	//	borderIndex[i] = vmin[i];

	for (int i = 0; i < n; i++)
		for (int j = i+1; j < n; j++)
			if (borderIndex[i] > borderIndex[j]) {
				swap(borderIndex[i], borderIndex[j]);
		//		swap(finalOrder[i], finalOrder[j]);
			}
//	for (int i = 0; i < n; i++)
//		cout << finalOrder[i] << " " << borderIndex[ i ] << endl;

}
