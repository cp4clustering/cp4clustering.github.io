

class ClusterOptions : public Options {
protected:
  Driver::IntOption _n; // Number of transactions/points
  Driver::IntOption _k; // Number of clusters
  Driver::IntOption _a; // Number of attributes
  Driver::IntOption _ml; // ratio number of ml/n
  Driver::IntOption _cl; // ratio number of cl/n

  Driver::IntOption _datatype; // ratio number of cl/n


  Driver::IntOption _dfpf; // use contrainte of diameter_fpf or NOT,  if fpf=1:  d[i][j] < d_fpf if i, j in same group


  Driver::DoubleOption _s; // separation between group
  Driver::StringValueOption _f; // file name of dataset
  Driver::IntOption _sizeMin; // sizeMin constraint of groups
  Driver::IntOption _sizeMax; // sizeMax constraint of groups
  Driver::IntOption _order; // ordering point or not. Order = 0: no ordering. Order = 1: Use our Function, Order = 2: FPF
  Driver::IntOption _obj; // objective function, obj = 1: max diameter, obj = 2: min separation, obj = 3 : variance
  Driver::IntOption _searchstrategy; // search order,  search = 1: IDG, search = 2: IGD
  Driver::IntOption _epsilon; // search order,  search = 1: IDG, search = 2: IGD
  Driver::IntOption _minpoint; // search order,  search = 1: IDG, search = 2: IGD
  Driver::DoubleOption _diam; // limit diameter




public:
  /// Constructor
  ClusterOptions(void)
    : Options("Cluster"),
      _n("-n","number of transactions/points",150),  // opt.n() = 0 when we do with ALL DATA

      _datatype("-datatype","normal data or matrix data",0),  // 0 : normal data, 1: matrix data

      _k("-k","number of clusters",3),
      _a("-a","number of attributes",4),
      _ml("-ml","Must Link %",0),
      _cl("-cl","Cannot Link %",0),

			_dfpf("-dfpf","Using Contrainte of Diameter FPF", 0), //fpf=1: d[i][j] < d_fpf if i, j  in the same group
			_diam("-diam","Using Contrainte of Diameter", 0), //fpf=1: d[i][j] < d_fpf if i, j  in the same group

			_sizeMin("-sizeMin","sizeMin Constrain",0),
			_sizeMax("-sizeMax","sizeMax Constrain",0),
      _s("-s","separation of group",0),
      _f("-f","file name", "iris150.txt"),
      _order("-order","ordering points", 2),
			_obj("-obj","Selection of Objective Functions", 1), //obj = 1: max diameter, obj = 2: min separation, obj = 3: variance
			_searchstrategy("-searchstrategy","Search order", 1), //search = 1: I G D, search = 2: I DG  			
			_epsilon("-epsilon","epsilon", 50), //a distance
			_minpoint("-minpoint","minpoint", 0) //like dbscan, each point must have at least |minpoint| in the distance epsilon  			

  {
    add(_n); add(_k); add(_a); add(_f); add(_diam);
    add(_ml);add(_cl);add(_sizeMin);add(_sizeMax);add(_s);add(_order);add(_obj);add(_dfpf);add(_searchstrategy);
		add(_epsilon);add(_minpoint); add(_datatype);
  }
  int n(void) const { return _n.value(); }
  int k(void) const { return _k.value(); }
  int a(void) const { return _a.value(); }
  int ml(void) const { return _ml.value(); }
  int cl(void) const { return _cl.value(); }
  double diam(void) const { return _diam.value(); }
  int datatype(void) const { return _datatype.value(); }

  int sizeMin(void) const { return _sizeMin.value(); }
  int sizeMax(void) const { return _sizeMax.value(); }
  int order(void) const { return _order.value(); }
  int obj(void) const { return _obj.value(); }
  int dfpf(void) const { return _dfpf.value(); }
  int searchstrategy(void) const { return _searchstrategy.value(); }
  int epsilon(void) const { return _epsilon.value(); }
  int minpoint(void) const { return _minpoint.value(); }


  string f(void) const { return _f.value(); }
  double s(void) const { return _s.value(); }
};
