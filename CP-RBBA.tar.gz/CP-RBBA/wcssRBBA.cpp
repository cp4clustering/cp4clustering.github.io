#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "wcssRBBA.h"

using namespace Gecode;
using namespace std;


// propagation
ExecStatus WcssRBBA::propagate(Space& home, const ModEventDelta&)  {
  int n=x.size();
  assert(assigned == -1 || x[assigned].assigned());
  while ((assigned+1 < n) && ( x[assigned+1].assigned() )) {
    //cout << "is assigned: " << assigned+1 << "\n";
    assigned++;
    
    int c = x[assigned].val();
    clus_sums[c] += dd[assigned][assigned];
    for (int j = 0; j < assigned; j++) {
      if (x[j].val() == c)
	clus_sums[c] += dd[assigned][j];
    }
    clus_sizes[c] += sizePart[assigned];
  }
    
  // here assigned is the largest index of assigned points
  // the number of assigned points is therefore assigned+1

  // for each cluster, its wcss contrib
  vector<double> subwcss(k,0);
  for (int c=0; c!=k; c++) {
    if (clus_sizes[c] != 0)
      subwcss[c] += (clus_sums[c]/clus_sizes[c]);
  }
  double totwcss = 0;
  for (int c=0; c!=k; c++)
    totwcss += subwcss[c];
    
  double borne_min = totwcss + wcss[n - (assigned+1)];
  if (wcss[n-(assigned+1)]==INT_MAX)
    borne_min=totwcss;
  if (borne_min >= y.max()) {
    return ES_FAILED;
  }
  GECODE_ME_CHECK(y.gq(home, borne_min));

  
  // look-ahead: check for lastAssigned+1 var and prune that
  if (assigned+1 < n) {
    Int::IntView& v = x[assigned+1];
      
    // prep
    vector<double> sumcontrib(k,0);
    for (int j = 0; j < assigned+1; j++)
      sumcontrib[x[j].val()] += dd[assigned+1][j];
      
    // check dom
    for (int c=0; c!=k; c++) {
      if (v.in(c)) { // val is in dom
	double corr = (-subwcss[c] + ((clus_sums[c]+sumcontrib[c]+dd[assigned+1][assigned+1])/(clus_sizes[c]+sizePart[assigned+1])));
	if (totwcss + corr + wcss[n - (assigned+2)] >= y.max()) {
	  // prune this c
	  GECODE_ME_CHECK(v.nq(home, c));
	}
      }
    }
    // check if prop should be called again (or do internally?)
    if (x[assigned+1].assigned())
      return ES_NOFIX;
  }
    
  return ES_FIX;
}


void wcssRBBA(Space& home, IntVarArgs x, FloatVar y, 
	      int k, vector< vector<double> >&  dd, vector<double>& wcss, vector<int>& sizePart) {
  // constraint post function
  ViewArray<Int::IntView> vx(home, x);
  Float::FloatView vy(y);
  if (WcssRBBA::post(home, vx, vy, k, dd, wcss,sizePart) != ES_OK)
    home.fail();
}

