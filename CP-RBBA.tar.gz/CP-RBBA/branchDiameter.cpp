#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "branchDiameter.h"

using namespace Gecode;
using namespace std;


/// Return choice
Gecode::Choice* branchDiameter::choice(Space&) {
  unsigned int i = start;

  // choose value for x[i]
  int bestVal=-1;
  double bestDist;
  double clusDist[k];

  if (closest_point) {
    // compute closest point for each cluster
    for (int t = 0; t < k; t++)
      clusDist[t] = INT_MAX;
    
    for (int t = 0; t < start; t++) {
      int v = x[t].val();
      if (x[i].in(v)) 
        if (dd[i][t] < clusDist[v]) 
          clusDist[v] = dd[i][t];
    }
  } else { // furthest point
    // compute furthest point for each cluster
    for (int t = 0; t < k; t++)
      clusDist[t] = 0;
    
    for (int t = 0; t < start; t++) {
      int v = x[t].val();
      if (x[i].in(v)) 
        if (dd[i][t] > clusDist[v]) 
          clusDist[v] = dd[i][t];
    }
  }

  if (closest_clus) {
    // take cluster of closest 'check' 
    bestDist = INT_MAX;
    for (int c = 0; c < k; c++)
      if (x[i].in(c)) 
        if (bestDist >= clusDist[c]) {
          bestDist = clusDist[c];
          bestVal = c;
        }
  } else {
    // take cluster of furthest 'check' 
    bestDist = 0;
    for (int c = 0; c < k; c++)
      if (x[i].in(c)) 
        if (bestDist <= clusDist[c]) {
          bestDist = clusDist[c];
          bestVal = c;
        }
  }

  // can do all choices as var order is fixed?
  return new Choice(*this,i,bestVal); // assign G[i] = minVal, G[i] != minVal
}
