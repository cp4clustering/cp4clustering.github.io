#include<climits>
#include <sstream>
#include "commonFunction.h"


 double dist(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return sqrt(d);
}


 double distSquare(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  return d;
}



 int distInt(vector<double> x, vector<double> y) {  // calcul distance of 2 points x, y
  double d = 0;
  for (unsigned int i = 0; i < x.size(); i++)
    d += (x[i] - y[i]) * (x[i] - y[i]);
  d = sqrt(d);
  d *= 100;

  return (int) d;
}

 double give_time(){
  struct rusage ru;
  struct timeval tim;
  getrusage(RUSAGE_SELF, &ru);
  tim = ru.ru_utime;
  return (double)tim.tv_sec+(double)tim.tv_usec/1000000.0;
}


//  void readDataMatrix(int n, ifstream &fin, double &maxD, double &minD, double** dd) {
//   maxD = 0;
//   minD = 100000000;
//   for (int i = 0; i < n; i++) 
//     for (int j = 0; j < n; j++) {
//       fin >> dd[i][j];
//       //dcarre[i][j] = dd[i][j] * dd[i][j];
//       if (i != j) {
// 	if (maxD < dd[i][j]) maxD = dd[i][j];
// 	if (minD > dd[i][j]) minD = dd[i][j];
//       }
//     }	// end of read file
// }

void readData(int n, ifstream &fin, vector< vector<double> >& attrMat) {
  for (int i = 0; i < n; i++)  {        
    string line;
    getline(fin,line);   
    istringstream iss(line);
    double value;
    while ( iss >> value ) 
      attrMat[i].push_back(value);
    if (i>0 && attrMat[i].size()!=attrMat[i-1].size()) {
      cerr << "Error: data don't have the same size.\n";
      exit(EXIT_FAILURE);
    }
  }
}


// int pivot(double a[], int pX[], int pY[], int first, int last) 
// {
//   int  p = first;
//   double pivotElement = a[first];
 
//   for(int i = first+1 ; i <= last ; i++)
//     {
//       if(a[i] <= pivotElement)
//         {
// 	  p++;
// 	  swap(a[i], a[p]);
// 	  swap(pX[i], pX[p]);
// 	  swap(pY[i], pY[p]);

//         }
//     }
 
//   swap(a[p], a[first]);
//   swap(pX[p], pX[first]);
//   swap(pY[p], pY[first]);

//   return p;
// }

// inline void quickSort( double a[], int pX[], int pY[], int first, int last ) 
// {
//   int pivotElement;
 
//   if(first < last)
//     {
//       pivotElement = pivot(a, pX, pY, first, last);
//       quickSort(a, pX, pY, first, pivotElement-1);
//       quickSort(a, pX, pY, pivotElement+1, last);
//     }
// }
 
 


// void sortD(int n, double** dd, double* dSort, int* pX, int* pY) {
//   int count = 0;
//   for (int i = 0; i < n; i++)
//     for (int j = i+1; j <n; j++) {
//       pX[count] = i;
//       pY[count] = j;
//       count++;
//     }

//   count = 0;
//   for (int i = 0; i < n; i++)
//     for (int j = i+1; j <n; j++) {
//       dSort[count] = dd[i][j] * dd[i][j];
//       count++;
//     }

//   // sort
//   /*	for (int i = 0; i < count; i++)
// 	for (int j = i+1; j < count; j++)
// 	if (dSort[i] > dSort[j]) {
// 	swap(dSort[i], dSort[j]);
// 	swap(pX[i], pX[j]);
// 	swap(pY[i], pY[j]);
// 	}
//   */
//   quickSort(dSort, pX, pY, 0, count-1);
// }


void reOrderPointFPF(int n,vector< vector<double> >& attrMat, vector<int>& order) {
  vector<double> totalDist(n,0);
  double tempD = 0;
    
  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(attrMat[i], attrMat[j]);
      totalDist[i] += tempD;
      totalDist[j] += tempD;
    }
  vector<double> distToP(n);
  for (int i = 0; i < n; i++)
    distToP[i] = totalDist[i];

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE NEED ORDER ALL
    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {
      if (distToP[i] > maxF) {  // select the point that has max of minDist
	maxF = distToP[i];
	position = i;
      }
    }
    if (p < position) {
      swap(attrMat[p], attrMat[position]);
      swap(order[p], order[position]);
      swap(totalDist[p], totalDist[position]);
      swap(distToP[p], distToP[position]);	  
    }
    // now: update distToP of point p+1 to n
    for (int c = p+1; c < n; c++) {
      double tempD = dist(attrMat[p], attrMat[c]);
      if (distToP[c] > tempD)
	distToP[c] = tempD;
    }
  }
  //cout << "Reading + ReOrganisation DATA (FPF) in \t:  " << give_time() - startAll << endl;
}

void reOrderPointRBBA(int n, vector< vector<double> >& attrMat, vector<int>& order) {
  // Following Brusco's pseudo code (separate nearest neighbors)
  int first = 0;
  int last = n-1;
  int unassigned = n;
  
  vector<bool> assigned(n, false);
  vector<int> position(n, -1);
  
  while (unassigned > 0) {
    int pos_r = 0;
    int pos_c = 0;
    
    // compute arg min position
    double distmin = INT_MAX;
    for (int c=0; c!=n; c++) { // over column/row to mimic RBBA
      if (not assigned[c]) {
        for (int r=c+1; r!=n; r++) {
          if (not assigned[r]) {
            double d = dist(attrMat[r], attrMat[c]);
            if (d < distmin) {
              distmin = d;
              pos_r = r;
              pos_c = c;
            }
          }
        }
      }
    }
    
    // add to back/front
    position[first++] = pos_c;
    assigned[pos_c] = true;
    position[last--] = pos_r;
    assigned[pos_r] = true;
    
    unassigned -= 2;
    // special case, one left
    if (unassigned == 1) {
      for (int i=0; i!=n; i++) {
        if (not assigned[i]) {
          position[first] = i;
          assigned[i] = true;
          unassigned -= 1;
        }
      }
    }
  }
  
  // do the reordering
  // a, pionter wrangling
  vector<double> *a_bis = new vector<double>[n];
  for (int i=0; i!=n; i++)
    a_bis[i] = attrMat[i];
  for (int i=0; i!=n; i++)
    attrMat[i] = a_bis[position[i]];
  //delete a_bis;
  
  //order, got that already
  for (int i=0; i!=n; i++)
    order[i] = position[i];
}


void reOrderPointFPF_lastK(int n, int k, vector< vector<double> >& attrMat, vector<int>& order) {

  vector<double> totalDist(n,0);
  double tempD = 0;
    
  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(attrMat[i], attrMat[j]);
      totalDist[i] += tempD;
      totalDist[j] += tempD;
    }

  vector<double> distToP(n);
  for (int i = 0; i < n; i++)
    distToP[i] = totalDist[i];

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {
      double f = 0; // f(i)	
      if (p > k)
	for (int zz = 1; zz <= k; zz++)
	  f += dist(attrMat[i], attrMat[p-zz]);
      else
	f = distToP[i];
      if (f > maxF) {		// select the point that is has  max of  minDist
	maxF = f;
	position = i;
      }
    }
    //	cout << maxF	 << " " << distToP[position] << endl;
    if (p < position) {
      swap(attrMat[p], attrMat[position]);
      swap(order[p], order[position]);
      swap(totalDist[p], totalDist[position]);
      swap(distToP[p], distToP[position]);	  
    }
    // now: update distToP of point p+1 to n
    for (int c = p+1; c < n; c++) {
      double tempD = dist(attrMat[p], attrMat[c]);
      if (distToP[c] > tempD)
	distToP[c] = tempD;
    }
  }
}



void reOrderPointVariance(int n, vector< vector<double> >& attrMat, vector<int>& order) {
  vector<double> totalDist(n,0);
  double tempD = 0;

  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(attrMat[i], attrMat[j]);
      totalDist[i] += tempD * tempD;
      totalDist[j] += tempD * tempD;
    }

  // here we use FPF to reorder points
  for (int p = 0; p < n; p++) {  // WE DONT NEED ORDER ALL
    // now we find point for position p
    // FIRST, calcul F(i) off all point from i to n
    int position = 0;
    double maxF = 0;		
    for (int i = p; i < n; i++) {
      double f = 0; // f(i)				
      double minDist = 0;
      //double maxDist = 0;
      int p1 = n;  // p1 = 3 * k ??
      if (p < p1) p1 = p;
      for (int j = 0; j < p1; j++) { 
	minDist += dist(attrMat[i],attrMat[j]) * dist(attrMat[i],attrMat[j]) ;
      }

      // minDist = min distance from a point to  [point 0, point 1, ... point p-1 ] 
      if (p == 0)   // special case
	f = totalDist[i]; 
      else
	f = minDist;
      if (f > maxF) {		// select the point that is has  max of  minDist
	maxF = f;
	position = i;
      }
    }
    swap(attrMat[p], attrMat[position]);
    swap(order[p], order[position]);
    swap(totalDist[p], totalDist[position]);
  }
}

void reOrderPointPoid(int n, vector< vector<double> >& attrMat, vector<int>& order)  {
  vector<double> totalDist(n,0);
  double tempD = 0;
  // totalDistant of point i to all other point
  for (int i = 0; i < n; i++) 
    for (int j = i+1; j < n; j++) {
      tempD = dist(attrMat[i], attrMat[j]);
      totalDist[i] += tempD;
      totalDist[j] += tempD;
    }

  // here we use our Function to reorder points
  for (int p = 0; p < n; p++) { 
    int position = 0;
    double maxF = 0;		

    for (int i = p; i < n; i++) {
      double f = 0; // f(i)				
      double minDist = 100000;
      double maxDist = 0;

      int p1 = n;
      if (p < p1) p1 = p;

      for (int j = 0; j < p1; j++) {  // f(i) = Sum d(i, j) * min/max * (n-p)/p
	double distTemp = dist(attrMat[i], attrMat[j]);
	f += distTemp;	
	if (distTemp < minDist) minDist = distTemp;
	if (distTemp > maxDist) maxDist = distTemp;
      }

      if (p >= 1)
	f = f * (((minDist/maxDist)/p) * (n-p)-1);

      f += totalDist[i];	

      if (f > maxF) {
	maxF = f;
	position = i;
      }
    }
    swap(attrMat[p], attrMat[position]);
    swap(order[p], order[position]);
    swap(totalDist[p], totalDist[position]);
  }
}

void reOrderPointRANDOM(int n, vector< vector<double> >& attrMat, vector<int>& order){
  for (int i = 0; i < 10000; i++) {
    int x = rand() % n;
    int y = rand() % n;
    swap(attrMat[x], attrMat[y]);
    swap(order[x], order[y]);
  }
}

void reOrderPointRevert(int n,vector< vector<double> >& attrMat, vector<int>& order) {
  for (int i = 0; i < n/2; i++) {
    swap(attrMat[i], attrMat[n-i-1]);
    swap(order[i], order[n-i-1]);
  }
  cout << "Revert reorder point \n";

}


void buildOrderSP(int n, vector<int>& order, int nSP, int* orderSP, int* ccindex) {
  int done[nSP];
  for (int i=0; i<nSP; i++)
    done[i]=0;
  int iSP=0;
  int iP=0;
  while (iP < n) {
    int sp=ccindex[order[iP]];
    if (done[sp]==0) {
      orderSP[iSP]=sp;
      done[sp]=1;
      iSP++;
    }
    iP++;
  }
}

