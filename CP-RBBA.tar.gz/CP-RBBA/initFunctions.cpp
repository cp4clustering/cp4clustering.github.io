#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"
#include "initFunctions.h"


int readN(const ClusterOptions& opt) {
  ifstream fin(opt.f().c_str(),ios::in);        // read file
  if (!fin.good()) {
    cerr << "Error: could not read file " << opt.f() << ".\n";
    exit(EXIT_FAILURE);
  }
  // read n from the first line
  int nOrigine;
  string line;
  getline(fin,line);   
  istringstream iss(line);
  iss >> nOrigine;
  fin.close();
  if (opt.n() > 0) { // take the provided number
    if (opt.n() > nOrigine) {
      cerr << "The required number is larger than provided " << endl;
      exit(EXIT_FAILURE);
    }
    nOrigine = opt.n();
  }
  return nOrigine;
} 


void dfsVisit(int i, vector< vector<int> >& graph, vector< vector<int> >& cc,
	      vector<int>& ccindex, int nSP) {
  ccindex[i]=nSP;
  cc[nSP].push_back(i);
  for (unsigned j=0; j<graph[i].size(); j++) {
    int u=graph[i][j];
    if (ccindex[u]==-1)
      dfsVisit(u, graph, cc, ccindex, nSP);
  }
}



// construct connected components on must-link graph
int constructCC(const ClusterOptions& opt, int nOrigine,
                vector< vector<double> >& attrMat, vector<int>& rorder,
                vector< vector<int> >& cc, vector<int>& ccindex) {
  vector< vector<int> > mlgraph(nOrigine);
  if (!opt.c().empty()) { // there are ML/CL from file
    //const char* fname=opt.c().c_str();
    ifstream fmlcl(opt.c().c_str(), ios::in);
    if (!fmlcl.good()) {
      cerr << "Error: could not read file " << opt.c().c_str() << ".\n";
      exit(EXIT_FAILURE);
    }
    // read ML constraints from file
    int nc=0;
    int x,y,z;
    while  (fmlcl >> x >> y >> z) {
      if (z==1 && x<nOrigine && y<nOrigine) { // ML constraint
	if (opt.verbose() >= 2)
	  cout << "ML(" << x << "," << y << ")" << endl;
	mlgraph[x].push_back(y);
	mlgraph[y].push_back(x);
	nc++;
      }
    }
    if (opt.verbose() >= 1)
      cout << "number of ML constraints from file: " << nc << endl;
    fmlcl.close();
  }

  //if (opt.s()>0) { // add ML constraints created by a split constraint
  // do always to detect whether there are 2 points identical
    int nc=0;
    for (int i=0; i<nOrigine; i++) 
      for (int j=i+1; j<nOrigine; j++) {
	double d = dist(attrMat[rorder[i]], attrMat[rorder[j]]);
	if (d == 0 || d < opt.s()) {
	  mlgraph[i].push_back(j);
	  mlgraph[j].push_back(i);
	  nc++;
	  //cout  << "add " << i << "  " << j << endl;
	}
      }
    if (opt.verbose() >= 1)
      cout << "#ML created by split constraint: " << nc << endl;

  // create ML-blocks
  int nSP=0;
  for (int i=0; i<nOrigine; i++)
    ccindex[i]=-1;

  for (int i=0; i<nOrigine; i++) 
    if (ccindex[i]==-1) { // point i is not reached 
      dfsVisit(i,mlgraph,cc,ccindex,nSP);
      nSP++;
    }
  if (opt.verbose() >= 2) {
    cout << "Connected components: " << endl;
    for (int i=0; i< nSP; i++) {
      cout << i << ": ";
      for (unsigned j=0; j<cc[i].size(); j++)
        cout << cc[i][j] << "  ";
      cout << endl;
    }
  }
  return nSP;
}

// build Cannot-link graph on ML-blocks
// each CL is on two ML-blocks
bool buildCLGraph(const ClusterOptions& opt,int nOrigine,
		  vector< vector<double> >& attrMat, vector<int>& rorder,
		  int nSP, vector<int>& ccindex, vector< vector<int> >& clgraph) {
  if (!opt.c().empty()) { // there are ML/CL constraints in file
    const char* fname=opt.c().c_str();
    ifstream fmlcl(fname, ios::in);
    int x,y,z,xSP,ySP;
    int nc=0;
    while  (fmlcl >> x >> y >> z) {
      if (z==-1 && x<nOrigine && y<nOrigine) { // CL constraint
	//cout << "CL(" << x << "," << y << ") --> " ;
	xSP=ccindex[x]; // super-point containing x
	ySP=ccindex[y]; // super-point containing y
	//cout << "CL(" << xSP << "," << ySP << ")" << endl;
	if (xSP == ySP)
	  return false;
	clgraph[xSP].push_back(ySP);
	clgraph[ySP].push_back(xSP);
	nc++;
      }
    }
    fmlcl.close();
    if (opt.verbose()>=1)
      cout << "#CL in file: " << nc << endl;
  }

  if (opt.diam()>0) { // there are CL created by diameter constraint
    int nc=0;
    for (int i=0; i<nOrigine; i++)
      for (int j=i+1; j<nOrigine; j++)
	if (dist(attrMat[rorder[i]],attrMat[rorder[j]]) > opt.diam()) {
	  int iSP=ccindex[i];
	  int jSP=ccindex[j];
	  clgraph[iSP].push_back(jSP);
	  clgraph[jSP].push_back(iSP);
	  nc++;
	}
    if (opt.verbose() >= 1)
      cout << "#CL created by diameter constraint: "<< nc << endl;
  }
  return true;
}


// read data and do preparations
void readAndOrderData(const ClusterOptions& opt, int nOrigine, 
		      vector< vector<double> >& attrMat, vector<int>& order, vector<int>& rorder) {
  ifstream fin(opt.f().c_str(),ios::in);        // read file
  if (!fin.good()) {
    cerr << "Error: could not read file " << opt.f() << ".\n";
    exit(EXIT_FAILURE);
  }
   
  int k = opt.k();  
  // pass through the first line
  string line;
  getline(fin,line);   

  if (opt.datatype() == 0) // data given by points
    readData(nOrigine, fin, attrMat); // read all attributs of points to A
  fin.close();


  //_______RE ORDERING POINT________________________________________________

  for (int i=0; i<nOrigine; i++)
    order[i] =i;

  if (opt.datatype() == 0) // only when data is read in normal form
    switch (opt.order()) {
    case 0:
      //cout << "No Ordering Points" << endl;
      break;
    case 1:
      reOrderPointFPF_lastK(nOrigine, k, attrMat, order);
      break;
    case 2:
      reOrderPointFPF(nOrigine, attrMat, order);
      break;
    case 3:
      reOrderPointRANDOM(nOrigine, attrMat, order);
      break;        
    case 4:
      reOrderPointVariance(nOrigine, attrMat, order);
      break;        
    case 5:
      reOrderPointRBBA(nOrigine, attrMat, order);
      break;
    }

  // build reverse order
  for (int i=0; i<nOrigine; i++)
    rorder[order[i]]=i;

  if (opt.verbose() >= 1) {
    cout << "Order on points: [ ";
    for (int i=0; i!=nOrigine; i++) {
      cout << order[i] << " "; // +1 for comparison with RBBA
    }
    cout << "]" << endl;
  }

  //-----END RE ORDERING POINT----------------------------------
}

void computeSS(const ClusterOptions& opt,
	       int nOrigine, int nSP, vector< vector<double> >& attrMat, 
	       vector< vector<int> >& cc, vector<int>& rorder, vector<int>& orderSP,
	       vector< vector<double> >& ddFull) {
  for (int i=0; i<nSP; i++)
    for (int j=0; j<nSP; j++) 
      if (i<=j) {
	int iSP = orderSP[i]; // iSP number of super-point at position i
	int jSP = orderSP[j];
	double d=0;
	int pu,pv;
	for (unsigned u=0; u<cc[iSP].size(); u++)
	  for (unsigned v=0; v<cc[jSP].size(); v++) {
	    // array a has been swapped by reordering, need new indices
	    pu=cc[iSP][u];
	    pv=cc[jSP][v];
	    d += distSquare(attrMat[rorder[pu]],attrMat[rorder[pv]]); 
	  }
	if (i==j)
	  d = d/2; // since each distance is counted twice
	ddFull[i].push_back(d);
      } else
	ddFull[i].push_back(ddFull[j][i]);
}


void buildOrderSP(int n, vector<int>& order, int nSP, vector<int>& orderSP, vector<int>& rorderSP, 
		  vector<int>& ccindex, int verbose) {
  int done[nSP];
  for (int i=0; i<nSP; i++)
    done[i]=0;
  int iSP=0;
  int iP=0;
  while (iP < n) {
    int sp=ccindex[order[iP]];
    if (done[sp]==0) {
      orderSP[iSP]=sp;
      done[sp]=1;
      iSP++;
    }
    iP++;
  }
  
  // compute reverse order of super-points
  for (int i=0; i!=nSP; i++)
    rorderSP[orderSP[i]] = i;
  
  if (verbose >= 1) {
    cout << "Order in super-points: [ ";
    for (int i=0; i!=nSP; i++) {
      cout << orderSP[i] << " "; // +1 for comparison with RBBA
    }
    cout << "]" << endl;
  }
  
}


