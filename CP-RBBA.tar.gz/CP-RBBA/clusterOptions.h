#ifndef CLUSTER_OPTION
#define CLUSTER_OPTION
#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include <stack>  

using namespace Gecode;
using namespace std;


class ClusterOptions : public Options {
 protected:
  Driver::IntOption _n; // Number of transactions/points
  Driver::IntOption _k; // Number of clusters

  Driver::IntOption _a; // Number of attributes
  Driver::IntOption _ml; // ratio number of ml/n
  Driver::IntOption _cl; // ratio number of cl/n
  Driver::StringValueOption _c; // User constraint: constraint file for must-link and cannot-link constraint

  Driver::IntOption _datatype; // ratio number of cl/n
  Driver::IntOption _obj; // objective function

  Driver::IntOption _dfpf; // use contrainte of diameter_fpf or NOT,  if fpf=1:  d[i][j] < d_fpf if i, j in same group
  Driver::DoubleOption _diam; // limit diameter


  Driver::DoubleOption _s; // separation between group
  Driver::StringValueOption _f; // file name of dataset
  Driver::IntOption _sizeMin; // sizeMin constraint of groups
  Driver::IntOption _sizeMax; // sizeMax constraint of groups
  Driver::IntOption _order; // ordering point or not. Order = 0: no ordering. Order = 1: Use our Function, Order = 2: FPF
  Driver::IntOption _searchstrategy; // search order,  search = 1: IDG, search = 2: IGD
  Driver::DoubleOption _epsilon; // search order,  search = 1: IDG, search = 2: IGD
  Driver::DoubleOption _minpoint; // search order,  search = 1: IDG, search = 2: IGD
  Driver::IntOption _verbose; // verbosity, 0 = minimal, 1= CP output also, 2= debug
  Driver::StringValueOption _model; 
  Driver::StringValueOption _out; // file name to output partition 



 public:
  /// Constructor
 ClusterOptions(void) : Options("Cluster"),
    _n("-n","number of transactions/points",0),  // opt.n() = 0 when we do with ALL DATA
    _k("-k","number of clusters",0),

    _a("-a","number of attributes",0),
    _ml("-ml","Must Link %",0),
    _cl("-cl","Cannot Link %",0),
    _c("-c","constraint ML/CL file", ""),
    
    _datatype("-datatype","normal data or matrix data",0),  // 0 : normal data, 1: matrix data
    _obj("-obj", "objective function", 1),
    _dfpf("-dfpf","Using Contrainte of Diameter FPF", 0), //fpf=1: d[i][j] < d_fpf if i, j  in the same group
    _diam("-diam","Using Contrainte of Diameter", 0), //fpf=1: d[i][j] < d_fpf if i, j  in the same group
    
    _s("-s","separation of group",0),
    _f("-f","file name", ""),
    _sizeMin("-sizeMin","sizeMin Constrain",0),
    _sizeMax("-sizeMax","sizeMax Constrain",0),
    _order("-order","ordering points", 5),
    _searchstrategy("-searchstrategy","Search order", 0),  			
    _epsilon("-epsilon","epsilon", 0), //a distance
    _minpoint("-minpoint","minpoint", 0), //like dbscan, each point must have at least |minpoint| in the distance epsilon  			
    _verbose("-v","verbose", 0), // how much output
    _model("-mod","full/local", "full"),
    _out("-o","output file name", "")

      {
	add(_n); add(_k); add(_a); add(_f); add(_diam);  add(_c); add(_obj);
	add(_ml);add(_cl);add(_sizeMin);add(_sizeMax);add(_s);add(_order);add(_dfpf);add(_searchstrategy);
	add(_epsilon);add(_minpoint); add(_datatype); add(_verbose); add(_model); add(_out);
      }
  int n(void) const { return _n.value(); }
  int k(void) const { return _k.value(); }
  int a(void) const { return _a.value(); }
  int ml(void) const { return _ml.value(); }
  int cl(void) const { return _cl.value(); }
  double diam(void) const { return _diam.value(); }
  int datatype(void) const { return _datatype.value(); }
  void datatype(int v) { _datatype.value(v); }
  int obj(void) const { return _obj.value(); }
  void setObj(int obj) { _obj.value(obj); }
  string c(void) const { return _c.value(); 	}
  int sizeMin(void) const { return _sizeMin.value(); }
  int sizeMax(void) const { return _sizeMax.value(); }
  int order(void) const { return _order.value(); }
  void order(int v) { _order.value(v); }
  int dfpf(void) const { return _dfpf.value(); }
  int searchstrategy(void) const { return _searchstrategy.value(); }
  double epsilon(void) const { return _epsilon.value(); }
  double minpoint(void) const { return _minpoint.value(); }
  int verbose(void) const { return _verbose.value(); }
  string f(void) const { return _f.value(); }
  double s(void) const { return _s.value(); }
  void setSplit(double split) { _s.value(split);}
  string model(void) const { return _model.value(); }
  string output(void) const { return _out.value(); }
};

#endif
