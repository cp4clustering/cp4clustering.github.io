#ifndef CLUSTER_FULL
#define CLUSTER_FULL

#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"


using namespace Gecode;
using namespace std;


/*****
class Cluster: model with 
- all the variables G_1 to G_nSP
- all the CL constraints are put
BUT:
- the constraint kmeans is put only on the n last points
- branching is only on the n last points
*****/

class ClusterFull : public Space {
protected:
  const ClusterOptions& options;
  IntVarArray G; // G[i]: 1..k,  G[i]: class of i
  FloatVar objVar;  
  int np; // number of points need to be branched on
public:

 ClusterFull(const ClusterOptions& opt, int n, int nSP, int ubFlag,
	     vector< vector<double> >& dd, vector<double>& bestVal, vector<int>& finalClass,
	     vector<int>& orderSP, vector<int>& rorderSP, vector<int>& sizePart,
	     vector< vector<int> >& clgraph, vector< vector<int> >& cc,
	     vector<int>& rorder, vector<int>& ccindex,
	     vector< vector<double> >& attrMat) : 
  //Space(opt),
  options(opt),
    G(*this, nSP, 0, opt.k()-1), 
    objVar(*this, 0, Float::Limits::max),
    np(n)
  {
    postConstraints(ubFlag,dd,bestVal,finalClass,
		    orderSP, rorderSP, sizePart, clgraph,
		    cc, rorder, ccindex, attrMat);
    postBranch(dd, bestVal);
  }

  ClusterFull(bool share, ClusterFull& s) : 
  Space(share, s), options(s.options), np(s.np) {
    G.update(*this, share, s.G);
    objVar.update(*this, share, s.objVar);
  }

  virtual Space* copy(bool share) {
    return new ClusterFull(share,*this);
  }


  virtual void constrain(const Space& sol) {
    if (options.obj() > 0) {
      const ClusterFull& _sol=static_cast<const ClusterFull&>(sol);      
      rel(*this, objVar < _sol.objVar.min());
    }
  }

  virtual void print() const;
  void saveSolution(vector<int>& finalClass, vector<double>& bestVal);
  double objVal();

  void postConstraints(int ubFlag,  vector< vector<double> >& dd, vector<double>& bestVal,
		       vector<int>& finalClass, vector<int>& orderSP, vector<int>& rorderSP,
		       vector<int>& sizePart,
		       vector< vector<int> >& clgraph, vector< vector<int> >& cc,
		       vector<int>& rorder, vector<int>& ccindex,
		       vector< vector<double> >& attrMat);
  void postBranch( vector< vector<double> >& dd, vector<double>& bestVal);
  void savePartitionFile(string filename, vector< vector<double> >& attrMat,
			 vector<int>& rorder, vector<int>& ccindex, vector<int> rorderSP);
};


#endif
