#ifndef INITFUNCTIONS_H
#define INITFUNCTIONS_H

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"

// read data and do preparations
int readN(const ClusterOptions&);
void readAndOrderData(const ClusterOptions& opt, int nOrigine, 
		      vector< vector<double> >& attrMat, vector<int>& order, vector<int>& rorder);
int constructCC(const ClusterOptions& opt, int nOrigine,
                vector< vector<double> >& attrMat, vector<int>& rorder,
                vector< vector<int> >& cc, vector<int>& ccindex) ;
bool buildCLGraph(const ClusterOptions& opt,int nOrigine,
		  vector< vector<double> >& attrMat, vector<int>& rorder,
		  int nSP, vector<int>& ccindex, vector< vector<int> >& clgraph) ;
void buildOrderSP(int n, vector<int>& order, int nSP,
		  vector<int>& orderSP, vector<int>& rorderSP, vector<int>& ccindex, int verbose=0);
void computeSS(const ClusterOptions& opt,
	       int nOrigine, int nSP, vector< vector<double> >& attrMat, 
	       vector< vector<int> >& cc, vector<int>& rorder, vector<int>& orderSP,
	       vector< vector<double> >& ddFull);
#endif
