#ifndef BRANCH_DIAMETER
#define BRANCH_DIAMETER

#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;




/*
 * value branching
 * for each cluster, find furthest point
 * then choose cluster with closest of those
 *
 * true false = closest clus with furthest point
 * true true = closest clus with closest point
 * false true = futhest clus with closets point
 * false false = furthest clus with furthest point
*/
class branchDiameter : public Brancher {
 protected:
  /// Views of the brancher
  ViewArray<Int::IntView> x; // x is the variables G
  
  /// distance matrice
  vector< vector<double> >& dd;
  int k;
  
  /// Next variable to branch on
  mutable int start;	// start is the first point that is unassigned
  bool closest_clus;
  bool closest_point;

  /// %Choice
  class Choice : public Gecode::Choice {
  public:
    /// Position of variable
    int pos;
    /// Value of variable
    int val;
    /** Initialize choice for brancher \a b, position \a pos0, 
     *  and value \a val0.
     */
  Choice(const Brancher& b, int pos0, int val0)
    : Gecode::Choice(b,2), pos(pos0), val(val0) {}

    /// Report size occupied
    virtual size_t size(void) const {
      return sizeof(Choice);
    }

    /// Archive into \a e
    virtual void archive(Archive& e) const {
      Gecode::Choice::archive(e);
      e << pos << val;
    }
  };
 
  /// Construct brancher
 branchDiameter(Home home, ViewArray<Int::IntView>& xv, vector< vector<double> >& mat, int vk, bool clo_clu, bool clo_pnt) 
   : Brancher(home), x(xv), dd(mat), k(vk), start(0), closest_clus(clo_clu), closest_point(clo_pnt) {}
  /// Copy constructor
 branchDiameter(Space& home, bool share, branchDiameter& b) 
   : Brancher(home, share, b), dd(b.dd), k(b.k), start(b.start), closest_clus(b.closest_clus), closest_point(b.closest_point) {
    x.update(home, share, b.x);
  }

 public:
  /// Check status of brancher, return true if alternatives left
  virtual bool status(const Space&) const {
    for (int i=start; i<x.size(); i++)
      if (!x[i].assigned()) {
        start = i; return true;
      }
    return false;
  }

  /// Return choice
  virtual Gecode::Choice* choice(Space&);  /// Return choice
  virtual Choice* choice(const Space&, Archive& e) {
    int pos, val;
    e >> pos >> val;
    return new Choice(*this, pos, val);
  }

  /// Perform commit for choice \a _c and alternative \a a
  virtual ExecStatus commit(Space& home, const Gecode::Choice& _c, unsigned int a) {
    const Choice& c = static_cast<const Choice&>(_c);
    if (a == 0)
      return me_failed(x[c.pos].eq(home, c.val)) ? ES_FAILED : ES_OK;
    else 
      return me_failed(x[c.pos].nq(home, c.val)) ? ES_FAILED : ES_OK;
  }

  /// Copy brancher
  virtual Actor* copy(Space& home, bool share) {
    return new (home) branchDiameter(home, share, *this);
  }

  /// Post brancher
  static void post(Home home, const IntVarArgs& x,vector< vector<double> >& dd, int k, bool clo_clu=true, bool clo_pnt=false) {
    ViewArray<Int::IntView> xv(home, x);
    (void) new (home) branchDiameter(home, xv,dd,k,clo_clu,clo_pnt);
  }

  /// Delete brancher and return its size
  virtual size_t dispose(Space&) {
    return sizeof(*this);
  }
};

#endif
