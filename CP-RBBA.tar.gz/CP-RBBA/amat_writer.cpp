#include <stdio.h>
#include <iostream>
#include <fstream>

#include "clusterOptions.h"
#include "initFunctions.h"

using namespace std;

void printAMAT(int n, vector<double> *dd) {
        ofstream fOut3("AMAT.DAT",ios::out);
        fOut3 << n << endl;
        for (int i = 0; i < n; i++) { 
                for (int j = 0; j < n; j++) 
                        fOut3 << dd[i][j]   << " ";
                fOut3 << endl;
        }
        fOut3.close();
}

int main(int argc, char* argv[]) {
  
  ClusterOptions opt;
  opt.solutions(0);
  opt.parse(argc,argv);
  opt.datatype(0);
  opt.order(0);
  
  int nOrigine=readN(opt); // number of points
  vector< vector<double> > a(nOrigine); // matrix  attribute   original
  vector<int> order(nOrigine); // order[i] is the index of the point at rank i
  vector<int> rorder(nOrigine); // rorder[i] gives the rank of the point i
  
  readAndOrderData(opt, nOrigine, a, order, rorder);
  
  vector<double>* ddFull = new vector<double>[nOrigine];
  for (int i=0; i<nOrigine; i++) {
    for (int j=0; j<nOrigine; j++) {
      if (i<=j) {
        ddFull[i].push_back(distSquare(a[i],a[j]));
      } else
        ddFull[i].push_back(ddFull[j][i]);
    }
  }
      
  printAMAT(nOrigine, ddFull);
}