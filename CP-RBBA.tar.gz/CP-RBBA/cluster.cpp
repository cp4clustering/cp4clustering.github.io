#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"
#include "wcssRBBA.h"
#include "branchDiameter.h"
#include "cluster.h"

using namespace Gecode;
using namespace std; 


void Cluster::postConstraints
  (int ubFlag, 
   vector< vector<double> >& dd,
   vector<double>& bestVal,
   vector<int>& finalClass,
   vector<int>& orderSP, vector<int>& rorderSP, 
   vector<int>& sizePart,
   vector< vector<int> >& clgraph, vector< vector<int> >& cc,
   vector<int>& rorder, vector<int>& ccindex,
   vector< vector<double> >& attrMat)
{
  int nOrigine = attrMat.size();
  int nSP = orderSP.size();
  int n = G.size();
  // PRECEDE 
  IntArgs t(options.k()); // array [0..k-1]
  for (int i = 0; i < options.k(); i++)
    t[i] = i;
  if (ubFlag==0)
    precede(*this, G, t);
  else  // extend partial solution
    for (int i=1; i<n; i++)
      rel(*this, G[i], IRT_EQ, finalClass[i]);
  
  // User-constraints: ONLY on the last level
  if (n == nSP) {
    // size constraint
    if ((options.sizeMin() || options.sizeMax()) ) { 
      IntVarArgs totalG(nOrigine);
      int ip=0;
      for (int i=0; i<nSP; i++)
        for (unsigned j=0; j<cc[orderSP[i]].size(); j++)
	  totalG[ip++] = G[i];
      
      if (options.sizeMin())
        for (int c = 0; c < options.k(); c++)
	  count(*this, totalG, c, IRT_GQ, options.sizeMin());

      if (options.sizeMax())
        for (int c = 0; c < options.k(); c++) 
	  count(*this, totalG, c, IRT_LQ, options.sizeMax());
    }

    // density constraint
    if (options.epsilon() * options.minpoint() > 0) {
      // compute all neighbors for all points
      vector< vector<int> > neighbor(nOrigine);
      for (int i=0; i<nOrigine; i++)
	for (int j=i+1; j<nOrigine; j++)
	  if (dist(attrMat[rorder[i]],attrMat[rorder[j]])<=options.epsilon()) {
	    neighbor[i].push_back(j);
	    neighbor[j].push_back(i);
	  }
      // then put constraints for points
      cout << "DENSITY CONSTRAINT" << endl;
      for (int i=0; i<nOrigine; i++) {
	cout << "neighbor size : " << neighbor[i].size();
	IntVarArgs nearPoints(neighbor[i].size());
        for (unsigned j=0; j<neighbor[i].size(); j++) {
	  int point=neighbor[i][j];
	  nearPoints[j] = G[rorderSP[ccindex[point]]];
	}
	count(*this, nearPoints, G[rorderSP[ccindex[i]]], IRT_GQ, options.minpoint()*neighbor[i].size());
      }
    }
   // end of density constraint     
  } //end of posting cluster-level constraints
 
  
  
  // ML constraints have been handled by super-points
  // need to put only CL constraints
  for (int i=0; i<n; i++) {
    int iSP=orderSP[i+nSP-n];
    for (unsigned j=0; j<clgraph[iSP].size(); j++) {
      int jSP = clgraph[iSP][j];
      int l = rorderSP[jSP]-rorderSP[iSP];
      if (l>0) { // super-point jSP is also used 
	int x = n+rorderSP[iSP]-nSP; // position of iSP in this step
	int y = n+rorderSP[jSP]-nSP; 
	rel(*this, G[x], IRT_NQ, G[y]);
      }
    }
    
  }
    
  if (bestVal[n] > 0)
      rel(*this, objVar, FRT_LE, bestVal[n]*1.00000001);

  if (options.obj() == 1) // WCSS criterion
    wcssRBBA(*this, G, objVar,options.k(),dd,bestVal,sizePart);

  if (options.verbose() >= 2) {
      // print nr of variables after first prop
      this->status();
      int varsset = 0;
      for (int i = 0; i < n; i++)
	varsset += G[i].assigned();
      cout << "in root node, " << (n - varsset) << "/" << n << " unassigned\n";
  }

}

void Cluster::postBranch(vector< vector<double> >& dd,
			 vector<double>& bestVal) {
  // value orderings
  switch(options.searchstrategy()) {
  case 1:
    // val_min
    branch(*this, G, INT_VAR_NONE(), INT_VAL_MIN());
    break;
  case 2:
    // values_min, because points must sequential
    branch(*this, G, INT_VAR_NONE(), INT_VALUES_MIN());
    break;
  case 3:
    // values_max
    branch(*this, G, INT_VAR_NONE(), INT_VALUES_MAX());
    break;
  case 4:
    // closest furthest point
    branchDiameter::post(*this, G, dd,options.k(), true, false);
    break;
  case 5:
    // closest closest point
    branchDiameter::post(*this, G, dd,options.k(), true, true);
    break;
  case 6:
    // furthest closest point
    branchDiameter::post(*this, G, dd,options.k(), false, true);
    break;
  case 7:
    // furthest furthest point
    branchDiameter::post(*this, G, dd,options.k(), false, false);
    break;
  case 0:
  default:
    // the one used up to now
    if (bestVal[G.size()] > 0)
      branch(*this, G, INT_VAR_NONE(), INT_VAL_MIN());
    else // if no upper bound exists use another strategy on value
      branchDiameter::post(*this, G, dd,options.k());
    break;
  }
}
 
void Cluster::print() const {
    cout << G << endl;
    cout << "___________________________________________________" << endl;
    cout << "Obj Value: " << objVar.min() << " " << objVar.max() << endl;
}

void Cluster::saveSolution(vector<int>& finalClass, vector<double>& bestVal)
{
  int n=G.size();
  if (G[n-1].assigned()) {
    // fixed var order, so means solution is fixed
    bestVal[n] = objVar.min();
    for (int i = 0; i < n; i++) {
      finalClass[i] = G[i].val();
    }
  }
}

double Cluster::objVal() {
  return objVar.min();
}


void Cluster::savePartitionFile(string filename, vector< vector<double> >& attrMat,
				vector<int>& rorder, vector<int>& ccindex, vector<int> rorderSP) {
  ofstream f(filename.c_str(),ios::out);        
  if (!f.good()) {
    cerr << "Error: could not open file " << filename << endl;
    exit(EXIT_FAILURE);
  }
  // save in file points in the same order such as in input file
  int nOrigine = attrMat.size();
  for (int i=0; i<nOrigine; i++) {
    // attributes of i-th point
    int rank=rorder[i];
    for (int j=0; j<attrMat[rank].size(); j++)
      f << attrMat[rank][j] << " ";
    // number of cluster
    int iSP = ccindex[i];
    f<< G[rorderSP[iSP]].val()+1 << endl;
  }
  f.close();
}

double Cluster::computeSplit(vector< vector<double> >& attrMat, vector<int>& rorder,
			     vector<int>& ccindex, vector<int> rorderSP) {
  double splitMin = INT_MAX;
  int nOrigine = attrMat.size();
  for (int i=0; i<nOrigine; i++)
    for (int j=i+1; j<nOrigine; j++)    
      if (G[rorderSP[ccindex[i]]].assigned() && G[rorderSP[ccindex[j]]].assigned() &&
	  G[rorderSP[ccindex[i]]].val() != G[rorderSP[ccindex[j]]].val()) {
	double split = dist(attrMat[rorder[i]],attrMat[rorder[j]]);
	if (split < splitMin) 
	  splitMin = split;
      }
  return splitMin;
}

double Cluster::computeDiameter(vector< vector<double> >& attrMat, vector<int>& rorder,
				vector<int>& ccindex, vector<int> rorderSP) {
  double diam = 0;
  int nOrigine = attrMat.size();
  for (int i=0; i<nOrigine; i++)
    for (int j=i+1; j<nOrigine; j++)    
      if (G[rorderSP[ccindex[i]]].assigned() && G[rorderSP[ccindex[j]]].assigned() &&
	  G[rorderSP[ccindex[i]]].val() == G[rorderSP[ccindex[j]]].val()) {
	double d = dist(attrMat[rorder[i]],attrMat[rorder[j]]);
	if (diam < d) 
	  diam = d;
      }
  return diam;
}
