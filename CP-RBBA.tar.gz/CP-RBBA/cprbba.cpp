#include <gecode/driver.hh>
#include <gecode/search.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"
#include "cluster.h"
#include "clusterFull.h"
#include "initFunctions.h"

using namespace Gecode;
using namespace std;

void cprbba_local(const ClusterOptions& opt, int nOrigine, int nSP,
		  vector< vector<double> >& attrMat,
		  vector< vector<int> >& cc, vector<int>& ccindex,
		  vector< vector<int> >& clgraph, vector<int>& order, vector<int>& rorder,
		  vector<int>& orderSP, vector<int>& rorderSP,
		  vector< vector<double> >& ddFull,
		  vector<double>& bestVal, vector<int>& finalClass, int start2);

void cprbba_full(const ClusterOptions& opt, int nOrigine, int nSP,
		 vector< vector<double> >& attrMat,
		 vector< vector<int> >& cc, vector<int>& ccindex,
		 vector< vector<int> >& clgraph, vector<int>& order, vector<int>& rorder,
		 vector<int>& orderSP, vector<int>& rorderSP,
		 vector< vector<double> >& ddFull,
		 vector<double>& bestVal, vector<int>& finalClass, int start2);



int main(int argc, char* argv[]) {
  double startAll=give_time();
  ClusterOptions opt;
  opt.solutions(0);
  opt.parse(argc,argv);
  opt.c_d(1); 
  opt.a_d(1);  // No recomputation, we save all nodes' information
  //        opt.time(2000); // Time limit is 10 minutes
  if (opt.verbose() == 0) {
    opt.out_file("/dev/null");
    opt.log_file("/dev/null");
  }

  int nOrigine=0; // number of points
  int nSP=0; // number of super-points

  nOrigine = readN(opt);
  vector< vector<double> > attrMat(nOrigine); // matrix  attribute   original
  vector<int> order(nOrigine,0); // order[i] is the index of the point at rank i
  vector<int> rorder(nOrigine,0);// rorder[i] gives the rank of the point i
  vector< vector<int> > cc(nOrigine); // connected components of ML graph
  vector<int> ccindex(nOrigine); // ccindex[i]: index of the component containing i
  
  readAndOrderData(opt, nOrigine, attrMat, order, rorder);

  // construct ML-blocks and CL graph
  nSP=constructCC(opt, nOrigine, attrMat, rorder, cc, ccindex); 
  vector< vector<int> > clgraph(nSP);  // graph for CL constraints
  buildCLGraph(opt, nOrigine, attrMat, rorder, nSP, ccindex, clgraph);

  if (opt.verbose() >= 0)
    cout << "number of super-points: " << nSP << endl;

  // build order on super-points
  vector<int> orderSP(nSP,0); // orderSP[i]=j means G[i] corresponds to super-point j
  vector<int> rorderSP(nSP,0); // rorderSP[i]=j means G[j] corresponds to super-point i
  buildOrderSP(nOrigine,order,nSP,orderSP,rorderSP,ccindex,opt.verbose());

  // compute distances for super-points
  vector< vector<double> > ddFull(nSP); // distance matrice for super-points
  computeSS(opt, nOrigine, nSP, attrMat, cc, rorder, orderSP, ddFull);

  // best value (wcss/wcsd) computed by RBBA steps
  vector<double> bestVal(nSP+1,0); 
  vector<int> finalClass(nSP,0);

  // choice of CPRBBA model
  double start2 = give_time();
  if (opt.model().compare("full")==0 ) {
    if (opt.verbose() >= 0)
        cout << "Full model" << endl;
    cprbba_full(opt, nOrigine, nSP, attrMat, cc, ccindex, clgraph,
		order, rorder, orderSP, rorderSP, ddFull, bestVal, finalClass, start2);
  } else {
    if (opt.verbose() >= 0)
        cout << "LOCAL model" << endl;
    cprbba_local(opt, nOrigine, nSP, attrMat, cc, ccindex, clgraph,
		 order, rorder, orderSP, rorderSP, ddFull, bestVal, finalClass, start2);
  }

  // output
  if (opt.verbose() >= 0) {
    cout << "Found clustering with WCSS: " << bestVal[nSP] << "\n";
    cout << "Cluster sizes: ";
    vector<int> sizes(opt.k());
    for (int i=0; i!=nSP; i++) {
        int iSP = orderSP[i];
        sizes[finalClass[i]] += cc[iSP].size();
    }
    cout << "0: "<<sizes[0];
    for (int i=1; i!=opt.k(); i++)
        cout << ", " << i <<": "<< sizes[i];
    cout << "\n";

    cout << "SEARCHING TIME : " << give_time() - start2 << endl;
    cout << "TOTAL TIME : " << give_time() - startAll << endl;
  } else {
    // verbose < 0: csv output
    if (opt.model().compare("full")==0 )
      cout << "CPRBBA-full;";
    else
      cout << "CPRBBA-local;";
    cout << opt.f().c_str() << ";"; // data file
    cout << opt.c().c_str() << ";"; // constraints file
    cout << opt.k() << ";"; // k
    cout << bestVal[nSP] << ";"; // score
    cout << (give_time() - startAll) << "\n";
  }

  return 0;
}



void cprbba_local
(const ClusterOptions& opt, int nOrigine, int nSP,
 vector< vector<double> >& attrMat,
 vector< vector<int> >& cc, vector<int>& ccindex,
 vector< vector<int> >& clgraph, vector<int>& order, vector<int>& rorder,
 vector<int>& orderSP, vector<int>& rorderSP,
 vector< vector<double> >& ddFull,
 vector<double>& bestVal, vector<int>& finalClass, int start2)
{
  int k=opt.k();
  int cl=0;
  if (!opt.c().empty() || opt.diam()>0)  // there are CL constraints
    cl=1;

  // init RBBA-specific vars
  vector< vector<double> > dd(nSP); // partial distance matrice for RBBA
  for (int i=0; i<nSP; i++)
    dd[i] = vector<double>(nSP,0);
  vector<int> sizePart(nSP,0); // partial size for RBBA
  
  // set values for the last k super-points
  for (int i=0; i<k; i++) {
    int iSP = orderSP[nSP+i-k];
    sizePart[i] = cc[iSP].size();
    finalClass[i]=i;
  }
  
  // for BAB<> (must be _Search::_Options)
  Search::Options sopt;
  sopt.threads = opt.threads();
  sopt.c_d = opt.c_d();
  sopt.a_d = opt.a_d();
  sopt.nogoods_limit = opt.nogoods_limit();

  // Steps of RBBA
  for (int n = k+1; n <= nSP; n++) {
    int iSP_0 = orderSP[nSP-n]; // new added super-point
    if (opt.verbose() >= 1)
      cout << "new super-point " << iSP_0 << endl;

    // copy relevant part of distance matrix
    for (int i = 0; i < n; i++) {
      for (int j = i; j < n; j++) {
        dd[i][j] = ddFull[i+nSP-n][j+nSP-n]; 
        dd[j][i] = dd[i][j];
      }
    }
      
    // shift finalClass by one because of added point 
    //(first elem will be set later)
    for (int i = n-1; i > 0; i--) {
      finalClass[i] = finalClass[i-1];
      sizePart[i] = sizePart[i-1];
    }
    sizePart[0] = cc[iSP_0].size();
      
    // sumdist way: precompute for previous points
    vector<int> sumsize(k, 0);
    vector<double> sumdist(k, 0); // sum of all dist in that clus

    for (int i = 1; i < n; i++) { // i=1!!! previous points
      int c = finalClass[i];
      int iSP = orderSP[i+nSP-n]; // iSP: the corresponding super-point
      sumsize[c] += cc[iSP].size();
      for (int j = i; j < n; j++) {
        if (finalClass[j] == c)
          sumdist[c] += dd[i][j];
      }
    }
      
    // try adding point '0' to each cluster and keep lowest wcss/wcsd 
    // bestVal[n] found is a new upper bound
    bestVal[n] = INT_MAX;
    if (n<nSP) {
      for (int c = 0; c < k; c++) {
	int ok=1;
	if (cl==1) // there are CL constraints
	  // see if point iSP_0 can be added to cluster c
	  // look at all super-points that are in clgraph[iSP_0]
          for (unsigned i=0; i<clgraph[iSP_0].size() && ok; i++) {
	    int iSP = clgraph[iSP_0][i];  
	    int j = rorderSP[iSP]-rorderSP[iSP_0]; // j is the rank of iSP in RBBA step
	    if (j>0 && finalClass[j]==c) {
	      ok=0;
	      if (opt.verbose() >= 2)
		cout << "UB comp: conflict with " << iSP << "/" 
		     << finalClass[j]<< endl;
	    }
	  }
	if (ok==1) { // super-point iSP_0 can be added to cluster c
	  double valSol = 0;
	  for (int sc=0; sc!=k; sc++) {
	    if (sc != c) {
	      // standard contribution
	      if (opt.obj() == 1) // WCSS criterion
		valSol += (sumdist[sc]/sumsize[sc]);
	      else // WCSD criterion
		valSol += sumdist[sc];
	    } else {
	      // extended contribution
	      double sumpoint = 0;
	      for (int j = 1; j < n; j++) {
		if (finalClass[j] == sc)
		  sumpoint += dd[0][j]; // for point 0 (i=0)
	      }
	      if (opt.obj() == 1) // WCSS criterion
		valSol += (sumdist[sc] + sumpoint + dd[0][0])/
		  (cc[iSP_0].size()+sumsize[sc]);
	      else // WCSD criterion
		valSol += (sumdist[sc] + sumpoint + dd[0][0]);
	    }
	  }
	  // objval if add iSP_0 to cluster c is better
	  if (bestVal[n] > valSol) {
	    finalClass[0] = c;
	    bestVal[n] = valSol;
	  }
	}
      }
    } else { // at the last step, need to put all constraints for upper bound
      // use therefore CP model
      Cluster* ubm=new Cluster(opt, n, 1, dd, bestVal, finalClass,
			       orderSP, rorderSP, sizePart, clgraph,
			       cc, rorder, ccindex, attrMat);
      BAB<Cluster> e(ubm,sopt);
      delete ubm;
      int ubsols=0;
      while (Cluster* s=e.next()) {
	ubsols++;
	if (opt.verbose() >=2)
	  s->print();
	bestVal[n]=s->objVal();
	delete s;
      }
    }

    // no direct extension 
    if (bestVal[n] == INT_MAX) {
      if (opt.verbose() >= 2)
	cout << "no upper bound" << endl;
      bestVal[n] = 0; // in class Cluster 0 will not be taken as an upper bound
    }
   

    double ub = bestVal[n];
    // call CP model for n points
    Cluster* m = new Cluster(opt, n, 0, dd, bestVal, finalClass,
			     orderSP, rorderSP, sizePart, clgraph,
			     cc, rorder, ccindex, attrMat);
    BAB<Cluster> e(m,sopt);
    delete m;
    int sols=0;
    Cluster* best=NULL;
    while (Cluster* s = e.next()) {
      sols++;
      if (best) // delete previous solution
	delete best;
      best = s;
      if (opt.verbose() >= 1)
        s->print();
      s->saveSolution(finalClass,bestVal);
    }
    if (best && n==nSP && !opt.output().empty()) { // save partition into file
      best->savePartitionFile(opt.output(), attrMat, rorder, ccindex, rorderSP);
    }
    Search::Statistics stats = e.statistics();
    if (opt.verbose() >= 0) {
        cout << "Objs: " << n << "  \tZ = " << bestVal[n] << " " << ub 
             << " \t(time: " << give_time() - start2 << " s/f: " 
	     << sols << "/" << stats.fail << " nodes: " << stats.node 
	     << ")\n"; //" props: " << stats.propagate <<
    }
  }
}

void cprbba_full
( const ClusterOptions& opt, int nOrigine, int nSP,
  vector< vector<double> >& attrMat,
  vector< vector<int> >& cc, vector<int>& ccindex,
  vector< vector<int> >& clgraph, vector<int>& order, vector<int>& rorder,
  vector<int>& orderSP, vector<int>& rorderSP,
  vector< vector<double> >& ddFull,
  vector<double>& bestVal, vector<int>& finalClass, int start2)
{
  int k=opt.k();

  // init RBBA-specific vars
  vector< vector<double> > dd(nSP);
  for (int i=0; i<nSP; i++)
    dd[i] = vector<double>(nSP,0);

  vector<int> sizePart(nSP,0); // partial size for RBBA
  
  // set values for the last k super-points
  for (int i=0; i<k; i++) {
    int iSP = orderSP[nSP+i-k];
    sizePart[i] = cc[iSP].size();
    finalClass[i]=i;
  }
  
  // for BAB<> (must be _Search::_Options)
  Search::Options sopt;
  sopt.threads = opt.threads();
  sopt.c_d = opt.c_d();
  sopt.a_d = opt.a_d();
  sopt.nogoods_limit = opt.nogoods_limit();
  

  // Steps of RBBA
  for (int n = k+1; n <= nSP; n++) {
    int iSP_0 = orderSP[nSP-n]; // new added super-point
    if (opt.verbose() >= 1)
      cout << "new super-point " << iSP_0 << endl;

    // copy relevant part of distance matrix
    for (int i = 0; i < n; i++) {
      for (int j = i; j < n; j++) {
	// indices in ddFull follow orderSP
        dd[i][j] = ddFull[i+nSP-n][j+nSP-n]; 
        dd[j][i] = dd[i][j];
      }
    }
      
    // shift finalClass by one because of added point 
    //(first elem will be set later)
    for (int i = n-1; i > 0; i--) {
      finalClass[i] = finalClass[i-1];
      sizePart[i] = sizePart[i-1];
    }
    sizePart[0] = cc[iSP_0].size();
      
    // try adding point '0' to each cluster and keep lowest wcss as new upper bound (put in wcss[n])
    bestVal[n] = INT_MAX;
    // use CP to compute an upper bound
    ClusterFull* ubm;
    ubm = new ClusterFull(opt, n, nSP, 1, dd, bestVal, finalClass,
			  orderSP, rorderSP, sizePart, clgraph,
			  cc, rorder, ccindex, attrMat); 
    BAB<ClusterFull> ube(ubm,sopt);
    delete ubm;
    int ubsols=0;
    while (ClusterFull* s = ube.next()) {
      ubsols++;
      if (opt.verbose() >= 2)
        s->print();
      bestVal[n]=s->objVal();
      delete s;
    }

    // no direct extension 
    if (bestVal[n] == INT_MAX) {
      if (opt.verbose() >= 2)
	cout << "no upper bound" << endl;
      bestVal[n] = 0; // in class Cluster 0 will not be taken as an upper bound
    }
   

    double ub = bestVal[n];
    // call CP model for n points
    ClusterFull* m = new ClusterFull(opt, n, nSP, 0, dd, bestVal, finalClass,
			     orderSP, rorderSP, sizePart, clgraph,
			     cc, rorder, ccindex, attrMat);
    BAB<ClusterFull> e(m,sopt);
    delete m;
    int sols=0;
    ClusterFull* best=NULL;
    while (ClusterFull* s = e.next()) {
      sols++;
      if (best) // delete previous solution
	delete best;
      best = s;
      if (opt.verbose() >= 1)
        s->print();
      s->saveSolution(finalClass,bestVal);
    }

    if (best && n==nSP && !opt.output().empty()) { // save partition into file
      best->savePartitionFile(opt.output(), attrMat, rorder, ccindex, rorderSP);
    }
    
    Search::Statistics stats = e.statistics();
    if (opt.verbose() >= 0) {
        cout << "Objs: " << n << "  \tZ = " << bestVal[n] << " " << ub 
             << " \t(time: " << give_time() - start2 << " s/f: " 
	     << sols << "/" << stats.fail << " nodes: " << stats.node 
	     << ")\n"; //" props: " << stats.propagate <<
    }
  }
}

