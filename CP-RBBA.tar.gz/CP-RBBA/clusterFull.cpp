#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 
#include "clusterOptions.h"
#include "commonFunction.h"
#include "wcssRBBA.h"
#include "branchDiameter.h"
#include "clusterFull.h"

using namespace Gecode;
using namespace std;

void ClusterFull::postConstraints
  (int ubFlag,  vector< vector<double> >& dd,
   vector<double>& bestVal,
   vector<int>& finalClass, vector<int>& orderSP, vector<int>& rorderSP, 
   vector<int>& sizePart,
   vector< vector<int> >& clgraph, vector< vector<int> >& cc,
   vector<int>& rorder, vector<int>& ccindex,
   vector< vector<double> >& attrMat)
{
  // PRECEDE 
  int nSP=G.size();
  int nOrigine = attrMat.size();
  IntVarArgs subG(np);
  for (int i=0; i<np; i++)
    subG[i]=G[i+nSP-np];
  if (ubFlag==0) {
    IntArgs t(options.k()); // array [0..k-1]
    for (int i = 0; i < options.k(); i++)
      t[i] = i;
    precede(*this, subG, t);
  } else { // extend partial solution
    for (int i=1; i<np; i++)
      rel(*this, subG[i], IRT_EQ, finalClass[i]);
  }


  // size constraint
  if ((options.sizeMin() || options.sizeMax()) ) { 
    IntVarArgs totalG(nOrigine);
    int ip=0;
    for (int i=0; i<nSP; i++)
      for (unsigned j=0; j<cc[orderSP[i]].size(); j++)
	totalG[ip++] = G[i];
    
    if (options.sizeMin())
      for (int c = 0; c < options.k(); c++)
	count(*this, totalG, c, IRT_GQ, options.sizeMin());

    if (options.sizeMax())
      for (int c = 0; c < options.k(); c++) 
	count(*this, totalG, c, IRT_LQ, options.sizeMax());
  }


   // density constraint
  if (options.epsilon() * options.minpoint() > 0) {
      // compute all neighbors for all points
    vector< vector<int> > neighbor(nOrigine);
      for (int i=0; i<nOrigine; i++)
	for (int j=i+1; j<nOrigine; j++)
	  if (dist(attrMat[rorder[i]],attrMat[rorder[j]])<=options.epsilon()) {
	    neighbor[i].push_back(j);
	    neighbor[j].push_back(i);
	  }
      // then put constraints for points
      for (int i=0; i<nOrigine; i++) {
	IntVarArgs nearPoints(neighbor[i].size());
	for (unsigned j=0; j<neighbor[i].size(); j++) {
	  int point=neighbor[i][j];
	  nearPoints[j] = G[rorderSP[ccindex[point]]];
	}
	count(*this, nearPoints, G[rorderSP[ccindex[i]]], IRT_GQ, options.minpoint()*neighbor[i].size());
      }
  }
  // end of density constraint     
 
  if (!options.c().empty() || options.diam() > 0) {
    // ML constraints have been handled by super-points
    // need to put only CL constraints
    // put ALL the CL constraints
    for (int iSP=0; iSP<nSP; iSP++) {
      int x = rorderSP[iSP]; // position of iSP over all the  points
      for (unsigned j=0; j<clgraph[iSP].size(); j++) {
	int jSP = clgraph[iSP][j];
	int y = rorderSP[jSP]; 
	rel(*this, G[x], IRT_NQ, G[y]);
      }
    }
  }
    
  if (bestVal[np] > 0)
      //rel(*this, objVar, FRT_LE, bestVal[n]+0.00000001);
      rel(*this, objVar, FRT_LE, bestVal[np]*1.00000001);

  if (options.obj() == 1) // WCSS criterion
    wcssRBBA(*this, subG, objVar,options.k(),dd,bestVal,sizePart);

  if (options.verbose() >= 2) {
      // print nr of variables after first prop
      this->status();
      int varsset = 0;
      for (int i = 0; i < np; i++)
	varsset += G[nSP+i-np].assigned();
      cout << "in root node, " << (np - varsset) << "/" << np << " unassigned\n";
  }

}

void ClusterFull::postBranch( vector< vector<double> >& dd, vector<double>& bestVal) {
  int nSP=G.size();
  IntVarArgs subG(np);
  for (int i=0; i<np; i++)
    subG[i]=G[i+nSP-np];

  // value orderings
  switch(options.searchstrategy()) {
  case 1:
    // val_min
    branch(*this, subG, INT_VAR_NONE(), INT_VAL_MIN());
    break;
  case 2:
    // values_min, because points must sequential
    branch(*this, subG, INT_VAR_NONE(), INT_VALUES_MIN());
    break;
  case 3:
    // values_max
    branch(*this, subG, INT_VAR_NONE(), INT_VALUES_MAX());
    break;
  case 4:
    // closest furthest point
    branchDiameter::post(*this, subG, dd,options.k(), true, false);
    break;
  case 5:
    // closest closest point
    branchDiameter::post(*this, subG, dd,options.k(), true, true);
    break;
  case 6:
    // furthest closest point
    branchDiameter::post(*this, subG, dd,options.k(), false, true);
    break;
  case 7:
    // furthest furthest point
    branchDiameter::post(*this, subG, dd,options.k(), false, false);
    break;
  case 0:
  default:
    // the one used up to now
    if (bestVal[np] > 0)
      branch(*this, subG, INT_VAR_NONE(), INT_VAL_MIN());
    else // if no upper bound exists use another strategy on value
      branchDiameter::post(*this, subG, dd,options.k());
    break;
  }
}

void ClusterFull::print() const {    
    for (int i = 0; i < np; i++)
      cout << G[i+G.size()-np] << ",";
    cout << "___________________________________________________" << endl;
    cout << "Obj Value: " << objVar.min() << " " << objVar.max() << endl;
}

void ClusterFull::saveSolution(vector<int>& finalClass, vector<double>& bestVal)
{
  if (G[G.size()-1].assigned()) {
    // fixed var order, so means solution is fixed
    bestVal[np] = objVar.min();
    for (int i = 0; i < np; i++) {
      finalClass[i] = G[i+G.size()-np].val();
    }
  }
}

double ClusterFull::objVal() {
  return objVar.min();
}

void ClusterFull::savePartitionFile(string filename, vector< vector<double> >& attrMat,
				vector<int>& rorder, vector<int>& ccindex, vector<int> rorderSP) {
  ofstream f(filename.c_str(),ios::out);        
  if (!f.good()) {
    cerr << "Error: could not open file " << filename << endl;
    exit(EXIT_FAILURE);
  }
  // save in file points in the same order such as in input file
  int nOrigine = attrMat.size();
  for (int i=0; i<nOrigine; i++) {
    // attributes of i-th point
    int rank=rorder[i];
    for (int j=0; j<attrMat[rank].size(); j++)
      f << attrMat[rank][j] << " ";
    // number of cluster
    int iSP = ccindex[i];
    f<< G[rorderSP[iSP]].val()+1 << endl;
  }
  f.close();
}
