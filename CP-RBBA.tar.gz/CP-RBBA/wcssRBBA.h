#ifndef WCSS_RBBA
#define WCSS_RBBA

#include <gecode/kernel.hh>
#include <gecode/driver.hh>
#include <gecode/int.hh>
#include <gecode/float.hh>
#include <gecode/set.hh>
#include <gecode/minimodel.hh>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <sys/resource.h>
#include <vector>
#include <math.h>
#include <algorithm> 


using namespace Gecode;
using namespace std;


class WcssRBBA : public Propagator {
protected:
  ViewArray<Int::IntView> x;
  Float::FloatView y;
  
  // state
  int k;
  vector< vector<double> >& dd;
  vector<double>& wcss;
  vector<int>& sizePart;
  int assigned; // last known assigned one
  int* clus_sizes;
  double* clus_sums;

public:
  // posting
  WcssRBBA(Space& home, ViewArray<Int::IntView>& x0, Float::FloatView y0,
	   int kc, vector< vector<double> >&  mat, vector<double>& wcss1, vector<int>& s):
    // maybe we use ADVISOR to reduce number of propagation
  Propagator(home), x(x0), y(y0), 
    k(kc), dd(mat), wcss(wcss1), sizePart(s),
    assigned(-1) {
    home.notice(*this,AP_DISPOSE); // so that the vectors are properly disposed
    x.subscribe(home,*this,Int::PC_INT_VAL);
    clus_sizes = new int[kc];
    clus_sums = new double[kc];
    for (int i=0; i!=kc; i++) {
      clus_sizes[i] = 0;
      clus_sums[i] = 0;
    }
  }
  static ExecStatus post
    (Space& home, 
     ViewArray<Int::IntView>& x0, Float::FloatView y0,
     int k, vector< vector<double> >&  dd, vector<double>& wcss, vector<int>& s)
  {
    (void) new (home) WcssRBBA(home,x0,y0,k,dd,wcss,s);
    return ES_OK;
  }
  // disposal
  size_t dispose(Space& home) {
    home.ignore(*this,AP_DISPOSE); // this should work!?
    x.cancel(home,*this,Int::PC_INT_VAL);
    delete[] clus_sizes;
    delete[] clus_sums;

    (void) Propagator::dispose(home);
    return sizeof(*this);
  }
  // copying
  WcssRBBA(Space& home, bool share, WcssRBBA& p) 
    : Propagator(home,share,p),
    k(p.k), dd(p.dd), wcss(p.wcss), sizePart(p.sizePart),
    assigned(p.assigned) {
    x.update(home, share, p.x);
    y.update(home, share, p.y);
    clus_sizes = new int[k];
    clus_sums = new double[k];
    for (int i=0; i!=k; i++) {
      clus_sizes[i] = p.clus_sizes[i];
      clus_sums[i] = p.clus_sums[i];
    }
  }
  virtual Propagator* copy(Space& home, bool share) {
    return new (home) WcssRBBA(home,share,*this);
  }
  // cost computation
  virtual PropCost cost(const Space&, const ModEventDelta&) const {
    return PropCost::binary(PropCost::HI);
  }
  // propagation
  virtual ExecStatus propagate(Space& home, const ModEventDelta&);

};

void wcssRBBA(Space& home, IntVarArgs x, FloatVar y, 
	      int k, vector< vector<double> >&  dd, vector<double>& wcss, vector<int>& s);

#endif
